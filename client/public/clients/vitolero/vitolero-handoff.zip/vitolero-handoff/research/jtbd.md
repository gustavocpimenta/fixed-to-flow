# Vitolero: jobs to be done by persona and journey stage

**Purpose:** Map each persona's jobs across their relationship with the app. Tagged for MVP vs. post-MVP coverage.
**Method:** Synthesized from community-mined personas, PRD use cases, and product design decisions.

---

## MVP vs. post-MVP at a glance

The MVP delivers three features: Snap & Share with filters, one-directional Pairing, and Journal. The job map reflects that scope. Dave (Weekend Ritualist) is the MVP-primary persona; his MVP jobs are the design target.

**MVP-active jobs (served at launch):**

| Job | Statement | MVP Feature |
|---|---|---|
| **Identify** | "Tell me what this is." Photo in, brand + line out (no vitola). | Cigar Identification (scoped) |
| **Enhance** | "Make my cigar photo look worth sharing." | Photo Filters (3 to 5 overlays) |
| **Share** | "Show what I'm smoking." Filter + overlay + deep link. | Snap & Share |
| **Pair** | "What goes with this cigar?" 3 food + 3 drink, one-way. | Pairing |
| **Remember (shallow)** | "Keep my cigar photos somewhere I can find them." Pinterest-style gallery. | Journal |

**Post-MVP jobs (deferred):**

| Job | Statement | Feature That Unlocks It |
|---|---|---|
| **Choose** | "Help me choose from what's in front of me." | In-store Recommendation |
| **Discover** | "Find great cigars new to me." | Discovery Feed |
| **Remember (deep)** | "Know my palate well enough to predict what I'll like." | Signature Taste Profile + Recommendation Engine |
| **Pair (reverse)** | "I have a drink, what cigar goes with it?" | Bi-directional Pairing |
| **Pair (menu-aware)** | "Here's the menu, pick a pairing from what's available." | Menu-aware Pairing |
| **Diagnose** | "Something is wrong with this cigar, what is it?" | Cigar Doctor |
| **Verify** | "Is this cigar authentic?" | Cigar Authentication (blocked on tech feasibility) |

Each persona section below is annotated with which of its jobs land in MVP and which wait for post-MVP. The research underneath each persona is unchanged.

---

## Approach

This document uses a JTBD x Journey Stage matrix. Each persona has different jobs at different stages of their relationship with the app. A Collector-Connoisseur and a Curious Newcomer might both be first-time app users, but their jobs are fundamentally different.

**JTBD format used throughout:**
> When [situation], I want to [motivation], so I can [expected outcome].

This format captures the functional job. Each persona section also addresses the emotional and social dimensions of the job.

---

## Journey stages

The four stages describe the user's relationship with Vitolero, not their cigar expertise.

### Stage 1: First Encounter
**Definition:** The user has never used the app, or just opened it for the first time.
**Trigger to enter:** Sees the app mentioned online, gets a recommendation from a friend, or searches for cigar help.
**Progression trigger:** Completes onboarding and gets a first useful result.

### Stage 2: Early Use
**Definition:** 1 to 3 sessions. Building an initial profile. Testing whether the app delivers value.
**Trigger to enter:** Got a result they found useful in their first session.
**Progression trigger:** Returns to the app voluntarily (not prompted by a notification) for a second distinct use case.

### Stage 3: Regular Use
**Definition:** Weekly or monthly usage. Established preferences. The app is part of their cigar routine.
**Trigger to enter:** The app has become the default action before or during a cigar purchase or smoking session.
**Progression trigger:** Begins using features beyond identification/recommendation (pairing, collection, sharing).

### Stage 4: Power Use
**Definition:** Deeply invested. Uses multiple features. Collection management. May influence others to use the app.
**Trigger to enter:** The app holds meaningful personal data (taste history, collection, pairing history) that the user would miss if lost.
**Progression trigger:** N/A (terminal stage).

---

## Persona 1: The Curious Newcomer

### Core JTBD

> When I'm curious about cigars but don't know where to start, I want someone to guide me without making me feel stupid, so I can try something I'll actually enjoy.

**Emotional dimension:** Reduce intimidation. Cigars feel like an exclusive club with a vocabulary barrier.
**Social dimension:** Fit in at social occasions involving cigars. Not look lost.

**Community voice:** "I can't name a single note, or discern a cheap cigar from a Cuban, but I enjoy the way a cigar makes me enjoy a moment." (1,800 upvotes, r/cigars)

### Journey Stage Matrix

| Stage | Primary Job | Supporting Quote |
|---|---|---|
| **First Encounter** | "When I walk into a cigar shop for the first time, I want to know what to buy without having to explain what I like, so I can avoid wasting money on something I'll hate." | "I'm a full time smoker and just getting into cigars recently. I've had a few before (don't know the names)" |
| **Early Use** | "When I've smoked a cigar I liked, I want to find more like it using just a photo of the band, so I can build on what works without needing cigar vocabulary." | "I just put that one down in my notes to order next time" |
| **Regular Use** | "When I'm starting to develop preferences, I want the app to tell me what I like in words I understand, so I can talk about cigars with more confidence." | "I know what I like, but I can't tell you what it is" (160 upvotes) |
| **Power Use** | Unlikely to reach this stage as a Newcomer. They either graduate to Weekend Ritualist or stop smoking cigars. | -- |

### Entry Scenario
Someone at a wedding hands them a cigar. They enjoy it but have no idea what it was. They search for "cigar app" or a friend who uses Vitolero says "just take a photo of it." They open the app, photograph a cigar band they saved, and get an identification with flavor description in plain language.

### Success Metric
They buy a cigar on their own for the first time and enjoy it. The app gave them the confidence to choose.

### Churn Risk by Stage

| Stage | Risk Level | Why They Leave |
|---|---|---|
| First Encounter | **High** | Onboarding asks for knowledge they don't have. Output uses jargon. Too many options presented. |
| Early Use | **Medium** | Second result isn't as good as the first. App feels like it's for experts. |
| Regular Use | **Low** | At this point they're transitioning to Weekend Ritualist persona. |

### PRD Coverage
- UC 1.2 (onboarding via photo of 3 cigars): directly serves the "no vocabulary required" job
- UC 2.3 (photo identification): core job at First Encounter and Early Use
- UC 2.1 (in-store recommendation): primary job at First Encounter

---

## Persona 2: The Weekend Ritualist

### Core JTBD

> When I want to enjoy a cigar moment, I want quick, reliable guidance without having to become a cigar expert, so I can enhance the experience without it becoming homework.

**Emotional dimension:** Preserve the ritual. Cigars are about slowing down, not optimizing.
**Social dimension:** Share moments with friends. Have a good pairing when entertaining.

**Community voice:** "It's for the meditative moment by myself or a new hobby to share with loved ones."

### Journey Stage Matrix

| Stage | Primary Job | Supporting Quote |
|---|---|---|
| **First Encounter** | "When I'm in a cigar shop and can't describe what I like to the staff, I want to show the app my past favorites and get a recommendation from what's available, so I can stop relying on hit-or-miss shopkeeper suggestions." | "If I like one, I save the label and just ask the guy in the cigar shop for similar cigars in a similar price range" |
| **Early Use** | "When I'm having a cigar with a drink, I want to know what pairs well without reading a guide, so I can elevate the moment without effort." | "Sounds like you just have to try all the cigars and whiskey you can get your hands on!" |
| **Regular Use** | "When I've been using the app for a while, I want it to remember what I like without me logging every smoke, so I can get better recommendations passively." | "They taste like cigars. Some are harsher than others. They're all enjoyable to me." |
| **Power Use** | "When I want to look back on great cigar moments, I want a journal of what I smoked and where, so I can relive those experiences and share them." | "One of the best things about smoking a cigar is it's a great way to relax and kill an hour or so" |

### Entry Scenario
They're at a cigar lounge with friends. Someone pulls out their phone, photographs the humidor display, and gets three ranked recommendations in seconds. The Weekend Ritualist asks "what app is that?" and downloads it on the spot. First action: photographs a cigar they're currently smoking to identify it and add it to their profile.

### Success Metric
They use the app in-store at least twice. The recommendation is something they enjoy. The app knows their taste better than they can articulate it themselves.

### Churn Risk by Stage

| Stage | Risk Level | Why They Leave |
|---|---|---|
| First Encounter | **Medium** | App demands too much input upfront. Feels like work. |
| Early Use | **Medium** | Recommendations miss the mark. Pairing feels generic. |
| Regular Use | **Low** | The app has become the "label-saving" replacement. Passive value. |
| Power Use | **Low** | Only if the journal/moment-capture feels like inventory management. |

### PRD Coverage
- UC 2.1 (in-store recommendation): the hero job for this persona
- UC 3.2 (photo of drinks menu for pairing): directly maps to the Early Use job
- UC 3.1 (cigar-to-drink recommendation): serves the pairing moment
- UC 1.2 (onboarding via 3 cigars): low-friction profile building

---

## Persona 3: The Deepening Enthusiast

### Core JTBD

> When I know what I like but want to go deeper, I want precise recommendations that account for my specific preferences and exclusions, so I can discover cigars that genuinely surprise me.

**Emotional dimension:** The thrill of discovery. Finding a "sleeper" nobody else knows about.
**Social dimension:** Build credibility in cigar communities. Give informed recommendations to others.

**Community voice:** "I really like strong flavors and high nicotine, but there is just some kind of taste in every Maduro that I have had that I just don't care for."

### Journey Stage Matrix

| Stage | Primary Job | Supporting Quote |
|---|---|---|
| **First Encounter** | "When I've tried every cigar app and been disappointed, I want to see immediately that this one understands nuance (not just 'mild vs strong'), so I can decide if it's worth investing my data." | "No app connects tasting notes to future recommendations" |
| **Early Use** | "When I rate a cigar, I want those ratings to visibly improve my next recommendation, so I can see that the app is learning my palate." | "Find a sweet spot routine that works 99 out of 100 for that smoking experience you prefer" |
| **Regular Use** | "When I'm at a shop with 50+ options, I want the app to rank them against my precise preferences (including what I dislike), so I can skip the trial-and-error." | "Is it worth buying or buy Padron or Davidoff?" |
| **Power Use** | "When I've built a detailed taste profile, I want to compare any new cigar against my established preferences, so I can make confident purchase decisions on expensive sticks." | "Wasn't expecting so much flavor and complexity" |

### Entry Scenario
They read about Vitolero in a cigar subreddit or see it mentioned in a Facebook group. They're skeptical (they've tried Cigar Scanner, My Humidor, others). They test the identification accuracy first: photograph a cigar they already know well and check if the app gets it right. If it does, they add their collection. If it doesn't, they leave immediately.

### Success Metric
The app recommends a cigar they haven't tried that they rate 8+/10. The recommendation was specific enough that a generic "top cigars" list would not have surfaced it.

### Churn Risk by Stage

| Stage | Risk Level | Why They Leave |
|---|---|---|
| First Encounter | **Very High** | Database missing cigars they search for. Identification wrong on a cigar they know. |
| Early Use | **High** | Recommendations feel generic. No visible difference between "I like X" and "I like X but not Y." |
| Regular Use | **Medium** | Database gaps accumulate. A cigar they bought based on recommendation disappoints. |
| Power Use | **Low** | They've invested data. Switching cost is real. But they'll leave if a better app appears. |

### PRD Coverage
- UC 2.1 (in-store recommendation with filters): the core job at Regular and Power Use
- UC 2.2 (shortlist recommendation by criterion): serves the comparison job
- UC 2.3 (identification): the trust-building first interaction
- UC 5.x (browsing and discovery): serves the "find sleepers" job
- UC 3.x (pairing): secondary but valued

---

## Persona 4: The Collector-Connoisseur

### Core JTBD

> When I've smoked through the mainstream catalog, I want a tool that matches my depth of knowledge and helps me manage what I have, so I can focus on the edges: rare finds, aging experiments, and sharing knowledge.

**Emotional dimension:** Respect for expertise. The app should never condescend or oversimplify.
**Social dimension:** Be the trusted source for others. Guide newbies. Validate their deep investment.

**Community voice:** "I tried to keep an inventory, but it doesn't work very well. Soon as I get them entered, I've gotta go delete the ones I smoked. It's too much like balancing my checkbook."

### Journey Stage Matrix

| Stage | Primary Job | Supporting Quote |
|---|---|---|
| **First Encounter** | "When I hear about a new cigar app, I want to stress-test the database against obscure cigars I own, so I can assess if the data is trustworthy enough to bother with." | "The database has (almost) everything... every vitola, of every line, of every mainstream brand" |
| **Early Use** | "When I'm cataloging my collection (200+ cigars), I want to photograph boxes and have the app auto-catalog them, so I can replace my spreadsheet without doing data entry." | "Once or twice a year I will export the list to a spreadsheet then go through my cooler and cross them off" |
| **Regular Use** | "When I'm at a lounge scanning the humidor, I want instant identification of everything on the shelf with details I can't see from the band alone (blend, factory, aging potential), so I can spot the hidden gems." | "Prior Casdagli rep that knows the industry well. Makes very interesting blends with plenty of complexities." |
| **Power Use** | "When I'm aging cigars across multiple humidors, I want to track purchase dates, box codes, and how the same cigar tasted at different ages, so I can optimize my aging strategy." | "Two hour plus smoke, and the profile becomes somewhat boring down the line" |

### Entry Scenario
They see someone in a cigar Facebook group mention Vitolero. They download it with low expectations (they've seen apps come and go). They test it by photographing a boutique cigar with a small production run. If the app identifies it correctly, they're intrigued. If not, they post "another app that can't even identify [obscure brand]" and uninstall.

### Success Metric
The app replaces their spreadsheet. They can scan a box, add it to their collection, and track it over time with less effort than manual entry.

### Churn Risk by Stage

| Stage | Risk Level | Why They Leave |
|---|---|---|
| First Encounter | **Very High** | Database missing boutique brands. Wrong vitola attribution. Any inaccuracy is a dealbreaker. |
| Early Use | **High** | Bulk cataloging is too slow or manual. App can't handle 500+ cigar collections. |
| Regular Use | **Medium** | Performance degrades with large collections. No export/backup option. |
| Power Use | **Low** | Deeply invested. But they'll leave if data loss occurs (a known fear from competitor apps). |

### PRD Coverage
- UC 2.3 (identification): the trust test at First Encounter
- UC 5.x (browsing and discovery): serves the "find rare gems" job
- UC 2.1 (in-store/lounge recommendation): useful but not primary
- Collection management: the most critical gap for this persona, not yet covered by a formal use case

---

## Persona 5a: The Celebratory Occasional

### Core JTBD

> When I'm celebrating a milestone with a cigar, I want to know exactly what I'm smoking, so I can appreciate the moment fully and talk about it with confidence.

**Emotional dimension:** The cigar marks the occasion. Getting it right matters because the moment matters.
**Social dimension:** Cigars are a celebration prop and a gift. Occasion-matching is the primary filter.

**Community voice:** "Hard work pays off! Had my first Cohiba tonight!" (6,613 upvotes)

### Journey Stage Matrix

| Stage | Primary Job | Supporting Quote |
|---|---|---|
| **First Encounter** | "When someone gives me a cigar at a celebration, I want to photograph it and instantly know what it is, so I can appreciate (and talk about) what I'm smoking." | "Are these real Cohibas?" (2,794 upvotes) |
| **Early Use** | "When I'm choosing a cigar for a special occasion, I want occasion-based recommendations ('What cigar for a promotion?'), so I can match the cigar to the moment." | "Celebrating my son's graduation with one of my favorite stogies" (15,887 upvotes) |
| **Regular Use** | "When I'm hosting or gifting cigars, I want to give an informed answer quickly without hours of research, so I can be the knowledgeable friend in my circle." | "What should I buy for $50?" (recurring gift-giving question) |
| **Power Use** | Unlikely for most. A subset converts to Weekend Ritualist or Deepening Enthusiast once they discover the hobby. | -- |

### Entry Scenario
They receive a box of cigars as a gift. They want to know what they're worth. They search for "cigar identification app" and find Vitolero. They photograph the cigars, get an identification with context, and feel reassured. They might not open the app again for weeks until the next occasion.

### Success Metric
They use the app at a celebratory event and it gives them something to say about the cigar beyond the brand name. "This is actually a 2019 blend from the Padron family reserve line" makes them look knowledgeable.

### Churn Risk by Stage

| Stage | Risk Level | Why They Leave |
|---|---|---|
| First Encounter | **Medium** | App doesn't feel premium. Output is too technical. |
| Early Use | **High** | They only smoke occasionally. If the app doesn't provide value in the 2 to 3 week gap between sessions, they forget about it. |
| Regular Use | **Medium** | No occasion-based recommendation path. App treats every query as a flavor optimization problem. |

### PRD Coverage
- UC 2.3 (identification): the core job at First Encounter
- UC 2.1 (in-store recommendation): serves the "choose confidently" job
- UC 3.x (pairing): supports social hosting scenarios
- Occasion-based recommendation: a gap in the current PRD. All recommendations are framed around flavor matching; this persona's primary filter is occasion and social context.

---

## Persona 5b: The Lounge Social

### Core JTBD

> When I'm at a cigar lounge with others, I want to hold my own in the conversation and look like I know what I'm doing, so I can enjoy the social experience without feeling out of my depth.

**Emotional dimension:** Confidence in a social setting. Cigars are a shared ritual here, and being visibly knowledgeable is part of the enjoyment.
**Social dimension:** This is the primary dimension. The lounge is a social stage. The app is a confidence tool used in real time.

**Community voice:** "First time at a lounge, any tips?"

### Journey Stage Matrix

| Stage | Primary Job | Supporting Quote |
|---|---|---|
| **First Encounter** | "When I'm at a cigar lounge for the first time, I want to quickly learn enough about what's available to choose confidently, so I can look like I belong." | "First time at a lounge, any tips?" |
| **Early Use** | "When I'm photographing what I'm smoking, I want to capture enough context to share it with my crew, so I can build a record of what we smoked together." | "Hard work pays off! Had my first Cohiba tonight!" (6,613 upvotes) |
| **Regular Use** | "When someone at the lounge asks me about a cigar, I want to pull up the details instantly, so I can be the person with the answers." | -- |
| **Power Use** | "When someone asks me for a recommendation or gift suggestion, I want to give an informed answer quickly, so I can be the knowledgeable friend in my circle." | "What should I buy for $50?" (recurring gift-giving question) |

### Entry Scenario
They're at a lounge with a group. A regular at the bar pulls out their phone, photographs a cigar from the humidor display, and instantly starts talking about the blend. Jerome asks what app that is and downloads it on the spot. Their first action is photographing the cigar they're currently smoking to share in the group chat.

### Success Metric
They use the app at a lounge event and it gives them something to contribute to the conversation. The Snap & Share loop keeps them returning even between visits.

### Churn Risk by Stage

| Stage | Risk Level | Why They Leave |
|---|---|---|
| First Encounter | **Medium** | App doesn't feel like it belongs in a social context. Output too technical, not shareable. |
| Early Use | **High** | Gap between lounge visits is long. If the sharing loop doesn't pull them back, they forget the app. |
| Regular Use | **Low** | Social identity as "the cigar person" keeps them engaged. |

### PRD Coverage
- UC 2.3 (identification): core at First Encounter
- Snap & Share: the hook that drives re-engagement for this persona
- UC 2.1 (in-store recommendation): useful at the lounge
- Occasion-based framing: partially covered, but social context is not a first-class filter in the current PRD

---

## Cross-persona insights

### Universal jobs (every persona, every stage)

1. **"Tell me what this is."** Identification is the universal entry point and the first value delivered. Every persona's first interaction is a photo and a question. (UC 2.3)
2. **"Help me choose."** The in-store recommendation job. Contextual: user has options in front of them and needs guidance. The depth of the answer varies, not the job itself. (UC 2.1, 2.2)
3. **"Find great cigars for me."** The discovery job. Drives retention across all personas. (Feature alignment: Cigar Discovery / Recommendation Feed)
4. **"Remember what I like."** No persona wants to re-explain their preferences. The profile-building job is universal, but tolerance for active input varies dramatically (Deepening Enthusiast will rate; Weekend Ritualist won't). Photo import addresses the cold-start problem: users who already have cigar photos on their phone can build a taste profile in a single session instead of weeks of organic snapping. The Signature Taste Profile is the hidden engine behind this job. (UC 1.1, 1.2)
5. **"Show what I'm smoking."** When I'm enjoying a cigar, I want to capture and share the moment with context, so I can look knowledgeable and build a record of what I smoke. Prompted after value delivery, not before. (Feature alignment: Snap & Share)

### Persona-specific jobs

| Job | Primary Persona | Why It's Specific |
|---|---|---|
| "Enhance my ritual" | Weekend Ritualist | Better cigars, better pairings, better tools. The ritual itself is the product. |
| "Share my ritual" | Weekend Ritualist | Share photos, share moments. Less frequent: meetups and events. |
| "Improve my experience" | Deepening Enthusiast | Better recommendations, account for dislikes not just likes. |
| "Expand my coverage" | Deepening Enthusiast | Knowledge, cigar collection, accessories, community connections. |
| "Educate me without condescension" | Curious Newcomer | Other personas already have the vocabulary or don't care about learning it |
| "Pair my cigar with a drink" | Weekend Ritualist | Most frequent pairing scenario. Enthusiasts pair by knowledge, Connoisseurs by experience |
| "Help me manage a large collection" | Collector-Connoisseur | Other personas have 5 to 20 cigars, not 200+ |
| "Match the cigar to the occasion" | Celebratory Occasional | Other personas choose by flavor, not by social context |
| "Help me look knowledgeable at the lounge" | Lounge Social | Other personas are there for the cigar; this persona is partly there for the social performance |

**Note on authenticity verification:** "Verify authenticity" (Celebratory Occasional) is excluded from v1. Cigar authentication is not yet technically feasible. This is a deep, multi-layered process that cannot be solved with current capabilities. Revisit in future versions.

### Jobs not covered by current PRD

| Missing Job | Persona | Gap |
|---|---|---|
| Occasion-based recommendation ("What cigar for a promotion?") | Celebratory Occasional | PRD assumes flavor-based queries only |
| Collection management at scale (bulk scan, auto-decrement) | Collector-Connoisseur | No formal use case for collection management |
| Taste profile feedback ("You seem to like milder cigars") | Curious Newcomer, Weekend Ritualist | Recommendations exist but no mechanism to explain why something was recommended |
| Aging tracking (purchase date, box code, taste evolution) | Collector-Connoisseur | Mentioned in app reviews but absent from PRD |

---

## Design implications

### 1. Output depth must scale with the user, not the feature

The same identification result should show different levels of detail:
- **Newcomer:** "This is a Montecristo No. 4. Mild, creamy, great for beginners. You'll probably like it based on your profile."
- **Deepening Enthusiast:** "Montecristo No. 4. Cuban, Habano wrapper, petit corona vitola. Medium body. Notes: cedar, coffee, light pepper. Similar to the Hoyo de Monterrey Epicure No. 2 you rated highly."
- **Collector-Connoisseur:** Full technical details, production year if detectable, aging notes, community rating distribution.

This maps to the PRD's "sense and respond" principle (see strategy/prd.md) but needs to be operationalized at the output layer.

### 2. First Encounter must deliver perceived value in under 10 seconds

Every persona's First Encounter job is high-stakes and impatient. The app gets one chance:
- **Photo in, perceived value out.** The sommelier narrative starts within 2 seconds of capture. The user sees the AI working immediately. Full identification takes roughly 10 seconds, but the experience of value begins at second 2.
- No wizard, no account creation required, no feature tour.
- The onboarding flow (UC 1.x) should happen after the first useful result, not before it.
- "What is this cigar?" is the universal entry job. Make it the zero-friction first experience.

### 3. The app needs two modes, not six personas

The journey stage matrix reveals that jobs cluster into two interaction patterns:

**Quick mode** (in the moment, at the shop, at the lounge):
- Identify this cigar
- Recommend from what's here
- Pair with this drink
- Share this moment

**Reflective mode** (at home, between smokes):
- Browse recommendations
- Manage collection
- Review past smokes
- Track aging

All six personas use Quick mode. Only Deepening Enthusiasts, Collector-Connoisseurs, and some Celebratory Occasionals use Reflective mode. The interface should make Quick mode instant and Reflective mode available but never in the way.

Passive profile building happens through the Snap & Share loop. Every photo captured and shared is a data point. The Lounge Social and Weekend Ritualist build their profiles without ever entering a rating.

### 4. Passive profile building is non-negotiable

Three of six personas (Newcomer, Weekend Ritualist, Lounge Social) will not actively rate, log, or journal their smokes. The app must build their profile from:
- What they photograph (even if they don't save it)
- What they ask about
- What they return to
- What they skip in recommendations

Active input (ratings, tasting notes, manual collection management) is a power feature for Deepening Enthusiasts and Collector-Connoisseurs. It should exist but never be required.

### 5. Churn follows a predictable pattern

Across all personas, the highest churn risk is at First Encounter and Early Use. The pattern:

1. **First Encounter:** Does the app understand me? (Newcomer: "Does it speak my language?" Collector-Connoisseur: "Does it know my cigars?")
2. **Early Use:** Does the app remember me? (All personas: "Is it better the second time?")
3. **Regular Use:** Low churn. The app has proven itself.
4. **Power Use:** Churn only from data loss, performance degradation, or a better competitor.

Retention strategy should focus almost entirely on the First Encounter to Early Use transition.

---

*Sources: research/personas.md (community-mined research), strategy/prd.md, research/feature-drilldown.md*
