# Vitolero: Onboarding Angles

## Context

Vitolero needs an onboarding flow that works across personas with wildly different motivations (curiosity, ritual, discovery, collection management, status). The previous native app failed because it asked users to pick from brand lists. The current webapp asks for 3 cigar names/photos upfront. Research shows: perceived value must arrive in under 10 seconds, the vocabulary gap is universal, and app fatigue is real.

The product's chosen MVP onboarding approach is Angle 7 below. Angles 1 through 6 are alternative designs considered during product development. They are not killed; they inform how future onboarding paths might evolve once recommendations and taste profile ship post-MVP.

---

## Angle 7: First 30 Seconds (MVP approach)

**Concept:** The app itself is the onboarding. In the first 30 seconds the user goes from camera to a filtered, branded cigar photo they can share. No account, no questions, no wizard. Account creation is deferred until the user opens the Journal for the first time.

**Flow (5 screens, first 30 seconds):**

1. **Camera.** App opens to a full-screen camera. One line of instruction: "Photograph any cigar." Gallery upload is available as a secondary option.
2. **Filter Preview.** User captures the photo. A curated filter is applied automatically. Before-and-after swipe visible. Other filter options are one tap away (3 to 5 overlays total).
3. **Identification.** Brand and line appear as a composited overlay on the filtered photo (not a separate screen). Target latency: under 10 seconds.
4. **Share Prompt.** "Share to Facebook." The primary button. Secondary actions visible but not hero: Pair, Save, Retake.
5. **Post-share or Save.** If user shares: they leave the app (technical constraint; reacquisition path under investigation). If user taps Save: the photo enters the Journal. First Journal access triggers social-login (Google) account creation.

**Why it works for the MVP:**
- Maps directly to Dave (Weekend Ritualist, US, solo smoker, Facebook sharer): he photographs cigars already, so the app is enhancing behavior he has, not inventing new behavior.
- The filter is the value the user can see and feel in under 5 seconds. Identification is the substance underneath.
- No vocabulary required. No expertise implied. Dave would not use a form; he uses a camera.
- Account creation is deferred. The user experiences value before being asked for anything, and the filter-plus-share loop is complete without auth.
- Returning users open to the last photo taken, not the camera. This is the product decision for MVP and differs from every pre-pivot angle.

**Risks / open questions:**
- If Dave does not care about photo quality, filters are not enough value. This is the team's own internal debate. The MVP is effectively a test of this assumption.
- Post-share reacquisition is unsolved (Fabio's action item). If users leave and never return, the Journal account-creation trigger never fires.
- Filter variety: 3 to 5 overlays may feel thin. More is not necessarily better; needs user testing during MVP.

**What Angle 7 replaces:**
- Angle 6 ("Trust Gateway") is the closest earlier angle. Angle 7 borrows its "earn-attention-first" principle but swaps the sommelier-narrative-heavy reveal for a filter-and-ID reveal that fits the brand-plus-line identification speed.
- The "Snap 3 cigars to unlock your taste profile" proposition is removed entirely. The Journal stores photos; it does not unlock anything behavioral.

**Best for:** Dave (Weekend Ritualist), the sole MVP-primary persona. Indirectly usable by Curious Newcomer (Tyler) and Celebratory Occasional (Mark) because the flow requires no vocabulary.

**Open actions:**
- Wireframes for the 5 screens (see wireframes/*.html)
- Contract a photographer for the 3 to 5 initial filter overlays
- Define the filter-to-ID composition spec (brand name and line placement, Vitolero mark location)
- Instrument share rate, Save rate, and post-share return so the MVP produces signal on the filter-value hypothesis

---

## Angle 1: "Scan First, Ask Later" (Deferred Onboarding)

**Concept:** No onboarding at all. The app opens directly to the camera. The user's first action IS the product. Profile builds silently from behavior.

**Flow:**
1. App opens. Full-screen camera with one line: "Photograph any cigar."
2. User snaps a photo. Gets identification + flavor summary instantly.
3. After the first result, a soft prompt: "Want recommendations tailored to you? Add 2 more cigars you've enjoyed." (photo or name)
4. Profile builds progressively from every interaction. No explicit onboarding step ever.

**Why it works:**
- Maps to the universal first job: "Tell me what this is" (every persona, every stage)
- Delivers value before asking for anything
- The Curious Newcomer isn't intimidated. The Collector-Connoisseur tests accuracy immediately. The Celebratory Occasional verifies authenticity.
- Sidesteps the vocabulary gap entirely

**Risk:** Without any profile, the first recommendation can't be personalized. The app is purely reactive until 3+ interactions accumulate.

**Best for:** Curious Newcomer, Celebratory Occasional (both want instant value, minimal commitment)

---

## Angle 2: "What Brings You Here?" (Moment-Based Routing)

**Concept:** One question that sorts users by intent, not expertise. Routes to a tailored first experience.

**Flow:**
1. App opens with 3-4 visual cards (no text-heavy options):
   - "I'm at a shop" (photo of humidor display)
   - "I have a cigar" (photo of single cigar in hand)
   - "I'm celebrating" (photo of cigar + drink setting)
   - "Just browsing" (discovery/explore icon)
2. Each card leads to a different first action:
   - Shop: camera opens for shelf scan, returns ranked recommendations
   - Have a cigar: camera opens for identification
   - Celebrating: asks "What's the occasion?" then suggests a cigar + pairing
   - Browsing: shows a curated "Top 10 for beginners" or trending cigars
3. After the first result, profile capture happens naturally ("Save this to your collection?")

**Why it works:**
- Captures motivation without asking "what's your experience level?" (which feels like a test)
- Each path delivers value immediately through a different use case
- Celebratory Occasionals self-select into the celebration path. Newcomers into "I'm at a shop." Collector-Connoisseurs into "I have a cigar."
- The moment IS the onboarding signal

**Risk:** 4 options on first screen adds friction vs. Angle 1's zero-friction approach. Some users may not fit neatly into one moment.

**Best for:** Weekend Ritualist, Celebratory Occasional (both are moment-driven)

---

## Angle 3: "The Taste Swipe" (Passive Profile Building)

**Concept:** Instead of asking users to name cigars they like (vocabulary problem), show them cigars and let them react. Tinder-style: like, skip, or "never tried."

**Flow:**
1. App shows 8-10 well-known cigars one at a time, with a photo of the band + one-line flavor description ("Rich, earthy, full-bodied" / "Light, creamy, smooth")
2. User swipes: "I like this" / "Not for me" / "Never tried" (3 options max)
3. After 5-6 reactions, the app says: "Got it. You lean toward [profile summary]. Here's your first recommendation."
4. Camera unlocks for identification and in-store use.

**Why it works:**
- No vocabulary required. Reacting is easier than describing.
- Builds a usable taste profile from relative preferences (like vs. not like), not absolute knowledge
- The Newcomer can honestly say "never tried" on most and still get a useful profile from the 2-3 they recognize
- The Deepening Enthusiast enjoys engaging with cigars they know and feels the app "gets" them quickly
- Generates immediate signal for the recommendation engine

**Risk:** Feels like a quiz (the exact thing research says users reject). Must be fast (under 30 seconds total) or it becomes homework. Collector-Connoisseurs may find it patronizing.

**Best for:** Deepening Enthusiast, Weekend Ritualist (both have enough experience to react meaningfully)

---

## Angle 4: "One Photo, Full Profile" (The Shelf Scan)

**Concept:** Take one photo of whatever cigars you have (humidor, a few sticks on a table, a shop shelf) and the AI builds your entire starting profile from that single image.

**Flow:**
1. App opens: "Show us your cigars. One photo is all we need."
2. User photographs their small collection (even 2-3 cigars on a table)
3. AI identifies all visible cigars, infers taste profile (flavor range, strength preference, price point, origin preference)
4. App presents: "Based on what you smoke, you prefer [summary]. Here are 3 cigars you'd love."
5. User can adjust ("Actually, I didn't like that one") to refine.

**Why it works:**
- One action, full profile. Minimum possible friction after Angle 1.
- Works across personas: Newcomer photographs the 2 cigars they were given. Collector-Connoisseur photographs a shelf of their humidor. Celebratory Occasional photographs the box they received as a gift.
- Leverages Vitolero's core strength (photo identification) as the onboarding mechanism itself
- Natural: people already take photos of their cigars (community behavior confirmed in research/market-research.md)

**Risk:** Requires good photo identification accuracy from day one (the 80% current accuracy may produce a wrong profile). Users who don't have cigars at hand can't use this path.

**Best for:** Collector-Connoisseur, Deepening Enthusiast (both have cigars readily available)

---

## Angle 5: "The Story Entry" (Narrative Onboarding)

**Concept:** Instead of structured input, let the user talk or type naturally. The AI extracts everything it needs from unstructured input.

**Flow:**
1. App opens with a simple prompt: "Tell us about your cigar life." (text or voice)
2. Examples shown as placeholders:
   - "I smoke maybe once a month, usually Padron or whatever the shop recommends"
   - "I just had my first cigar at a wedding and loved it"
   - "I've been smoking for 10 years, mostly Cubans, 200+ cigars in my humidor"
3. AI parses the narrative and extracts: experience level, brands mentioned, frequency, motivation, context
4. App responds conversationally: "Sounds like you know your way around a humidor. Let me find some cigars you haven't tried yet."
5. Transitions to camera/core features.

**Why it works:**
- Zero vocabulary barrier. Users describe themselves in their own words, at their own level.
- The AI does the translation work (unstructured input to structured profile), which is already a core Vitolero capability
- Captures motivation naturally ("I smoke to celebrate" vs "I'm trying to build my palate")
- Feels like talking to a knowledgeable friend, not filling out a form
- Voice input makes this feel natural in a lounge setting

**Risk:** Cold start problem: users might not know what to say. The placeholder examples do heavy lifting. Text input feels more effortful than a photo. Some users (especially Newcomers) might write very little ("I don't know anything about cigars"), producing a thin profile.

**Best for:** Weekend Ritualist, Curious Newcomer (both benefit from the low-pressure, conversational format)

---

## Comparison Matrix

| Criteria | Scan First | Moment-Based | Taste Swipe | Shelf Scan | Story Entry |
|---|---|---|---|---|---|
| Time to value | ~10s | ~20s | ~45s | ~15s | ~30s |
| Friction | None | Low | Medium | Low | Medium |
| Profile quality at start | None | Intent only | Good | Good | Variable |
| Vocabulary required | None | None | None | None | None |
| Works without cigars in hand | No | Partial | Yes | No | Yes |
| Newcomer fit | Strong | Strong | Medium | Weak | Strong |
| Ritualist fit | Strong | Strong | Strong | Medium | Strong |
| Enthusiast fit | Strong | Medium | Strong | Strong | Medium |
| Connoisseur fit | Strong | Weak | Weak | Strong | Medium |
| Occasional fit | Strong | Strong | Medium | Medium | Medium |
| Aligns with "photo first" principle | Yes | Yes | No | Yes | No |
| Aligns with "value first" principle | Yes | N/A | N/A | Yes | N/A |

---

## Angle 6: "The Trust Gateway" (Value-First Progressive)

**Source:** Dimitar's LLM-generated onboarding concept. Marked as draft. The timing assumptions are optimistic, but the core insight (deliver value before asking for share behavior) is sound and informed the final MVP approach.

**Concept:** Camera permission earned through a single compelling promise. Immediate identification value. Profile building happens as a stealth byproduct of saving. Share is prompted only after value is delivered. The entire sequence aims to feel like magic, not like onboarding.

**The key design shift:** The primary call to action is "Snap 3 cigars to unlock your personalized flavor profile and next-buy recommendations." This gives the user a reason to take 3 photos. Sharing is prompted after value delivery, not before.

**Flow:**

**Step 1: The Trust Gateway (Seconds 0-2)**
Because Vitolero is a PWA running in the browser, the biggest friction point is asking for camera permissions out of nowhere. The permission must be earned instantly.

The UI: A clean, immersive, full-screen view. The background is a slightly blurred, high-quality, atmospheric video loop (smoke rising off an ashtray, or a slow pan over a humidor).

The copy: Giant, elegant typography: "Point your camera at a cigar. We'll tell you the rest."

The CTA: A large button: "Open Scanner" (tapping triggers the browser's native camera permission prompt).

The escape hatch (crucial for the data flywheel): Below the button, a subtle text link: "Don't have a cigar right now? Import photos to build your taste profile." This satisfies the user who opened the app from their couch and doesn't have a cigar in front of them.

**Step 2: The Blank Canvas (Seconds 2-4)**
The camera opens. This is Quick Mode. No menus, no navigation bars, no clutter. Just the live camera feed.

The overlay: A subtle, AR-style targeting bracket in the center of the screen, sized for a cigar band.

The prompt: Floating text above the bracket reads: "Frame a cigar, a humidor shelf, or a menu." This quietly educates the user on the app's capabilities without a tutorial.

The action: The user frames a cigar and taps the shutter.

**Step 3: The Sommelier Narrative (Seconds 4-7)**
This is where the app wins or loses both Dave and Carlos. A spinning loading wheel will make Carlos think it's a cheap OCR text-scanner, and Dave will get bored.

The photo freezes. A subtle light sweep moves across the image. The AI narrative unfolds in real time:
- 0.5s: "Scanning image..."
- 1.5s: "I see a dark wrapper with an oily sheen..."
- 2.5s: "The band suggests a Padron family..."
- 3.5s: "Checking the vitola proportions..."

Why it works for Dave (Ritualist): It feels like magic. It's engaging and confirms the app is doing something sophisticated. Why it works for Carlos (Enthusiast): It proves domain expertise. The app isn't just reading the word "Padron" off the label. It's analyzing the wrapper shade and vitola.

**Step 4: The Revelation (Seconds 7-10)**
The scan finishes. The result slides up from the bottom. This UI adheres to the principle: "One answer, scaled to depth."

The top level (for Dave): Bold title: Padron 3000 Maduro. 3 clear flavor icons (dark chocolate, earth, espresso). Strength meter: "Full Bodied." Dave has his answer in 10 seconds.

The deep dive (for Carlos): Below the fold, clean typography: Origin: Nicaragua. Wrapper: Nicaraguan Maduro. Binder/Filler: Nicaraguan. Est. Smoke Time: 60 mins. Carlos gets precise data.

**Step 5: The Stealth Onboarding and Hook**
Now that value has been delivered, the app asks for the behavior that drives product goals: logging the cigar to build the taste profile.

Two CTAs: "Save to My Humidor" (primary). "Pair with a Drink" (secondary).

The user taps "Save." A micro-animation plays. A notification: "Saved! We've started mapping your palate. You lean toward Nicaraguan Maduros. Save 2 more cigars to unlock AI recommendations."

Why this works:
- Zero input: The user didn't type a word, didn't create a password, didn't fill out a flavor quiz.
- Immediate reward: They gave a photo; they got a polished, informative breakdown.
- The hook is set: The app is already learning their palate. Both Dave and Carlos will want to scan their next cigar to see how their profile changes.
- Natural transition to share: Once they hit "Save," an elegant prompt: "Looks like a great smoke. Generate a share card for Facebook?"

**Assessment:**

The timing assumptions (0-10 seconds end to end) are optimistic given current processing speeds (approximately 10 seconds for identification alone). The sommelier narrative is already part of the concept framework (State 2). The real contribution of this angle is the sequencing: value, then save, then share. This aligns with the MVP "earn-attention-first" approach.

| Criteria | Trust Gateway |
|---|---|
| Time to value | ~10s (optimistic) |
| Friction | Low (camera permission is the main gate) |
| Profile quality at start | None, builds after 3 snaps |
| Vocabulary required | None |
| Works without cigars in hand | Yes (import fallback) |
| Newcomer fit | Strong |
| Ritualist fit | Strong |
| Enthusiast fit | Strong |
| Connoisseur fit | Medium (will test accuracy first) |
| Occasional fit | Strong |
| Aligns with "photo first" principle | Yes |
| Aligns with "value first" principle | Yes |

---

## Design Rationale: Why Angle 7

**What survives from earlier angles into Angle 7:**
- **Angle 1's camera-first entry:** preserved. The app opens to the camera on a fresh open. Returning users open to their last photo instead (MVP product decision).
- **Angle 6's earn-attention-first principle:** preserved. Value arrives before any account or questionnaire.
- **Angle 3's passive profile building:** preserved for post-MVP. The Journal stores the raw photo and brand-plus-line data so the future recommendation engine has a cold start already warmed.
- **Angle 5 / voice and text fallback:** not in MVP. Revisit post-MVP.
- **Angle 2's moment detection:** not in MVP. The "photo, filter, ID, share" flow is one path, not four.

**What is explicitly dropped:**
- Angle 6's "Snap 3 cigars to unlock your taste profile" copy is retired; there is no taste profile unlock in the MVP.
- The sommelier narrative is trimmed to match the brand-plus-line identification speed (seconds, not 10-plus).

The core insight holds in a narrower form: the onboarding IS the product. The user's first snap is not a step before the product. It IS the product delivering value, via a filter that makes the photo look worth sharing.
