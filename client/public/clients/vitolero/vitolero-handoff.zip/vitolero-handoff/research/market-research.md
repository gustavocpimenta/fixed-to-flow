# Vitolero: Cigar Market Research

---

## Table of Contents

1. [Global Cigar Market](#1-global-cigar-market)
2. [Existing Cigar Apps and Digital Tools](#2-existing-cigar-apps-and-digital-tools)
3. [Online Community Landscape](#3-online-community-landscape)
4. [AI in the Cigar Industry](#4-ai-in-the-cigar-industry)
5. [Competitive Landscape](#5-competitive-landscape)
6. [Regulatory Landscape](#6-regulatory-landscape)
7. [Chinese Cigar Market](#7-chinese-cigar-market)
8. [Comparable Niche Hobby Apps](#8-comparable-niche-hobby-apps)
9. [Blue Ocean Analysis](#9-blue-ocean-analysis)

---

## 1. Global Cigar Market

### Market Size

Market sizing varies by methodology and segment definition, but the broad picture is consistent: cigars are a large, growing, globally distributed market with a strong premiumization trend.

- **Total cigar market (global, 2024):** Estimated USD $54.79-$62 billion depending on the source and whether cigarillos are included ([Grand View Research](https://www.grandviewresearch.com/industry-analysis/cigar-cigarillos-market), [Straits Research](https://straitsresearch.com/report/cigar-market))
- **Projected market (2033):** USD $102-$160 billion, with CAGR estimates ranging from 4% to 11.9%
- **Premium cigar segment (2025):** ~USD $1.43 billion at import level in the US alone ([Cigar Association of America](https://cigarsusa.org/))
- **Luxury cigar market (2024):** USD $15.34 billion, projected CAGR 7.5% through 2034 ([Polaris Market Research](https://www.polarismarketresearch.com/industry-analysis/luxury-cigar-market))

### US Market (Most Relevant for Vitolero)

The US is the world's largest premium cigar import market and the most digitally sophisticated consumer base.

- **2023 US premium cigar imports:** 467.6 million units (0.7% YoY increase)
- **2024 US premium cigar imports:** 430 million units (0.9% increase vs. 2023 in value terms), with total import **value** climbing to **$1.43 billion**, meaning volumes slightly eased but prices rose
- Average import value per 1,000 cigars rose 3% in 2024
- Nicaragua remains the top supplier, growing 2.7% to add 6.8 million cigars
- Online cigar sales in the US exceeded **$700 million** in 2024 ([Renegade Cigars data](https://renegadecigars.com/blogs/news/key-cigar-statistics-on-sales-imports-and-consumer-behavior))
- Offline retail still dominates at 83.3% of sales, though online is growing fast

### Key Trends

**Premiumization.** The defining trend across all markets. Consumers are buying fewer but more expensive cigars, prioritizing hand-rolled long-fillers, specific growing regions (Nicaragua, Cuba, Dominican Republic), limited editions, and artisan blends. Volume declining slightly while value holds or grows is the signature of this trend.

**Post-pandemic normalization.** The cigar market saw a boom during COVID (home consumption, premiumization of leisure). The 2023-2024 period represents stabilization after that spike, not decline.

**Growing enthusiast culture.** The hobbyist segment (people who track, journal, learn, and discuss cigars) is expanding. This is Vitolero's target market. It overlaps heavily with the wine connoisseur and whiskey enthusiast demographics.

**Demographic shifts.** Premium cigar users skew:
- Heavily male (37% of men use tobacco broadly vs. 7.7% women)
- High-income (41.1% of premium cigar users are high-income earners)
- Adult (not a youth product; premium cigars have negligible youth use, which is relevant for regulatory purposes)
- Urban and professional

**Digital engagement rising.** Younger premium cigar consumers are more digitally active, seeking apps, forums, and digital tools to support their hobby.

---

## 2. Existing Cigar Apps and Digital Tools

### Platform Distribution Reality

The most important structural fact shaping this market: **Apple's App Store and Google Play have banned most tobacco-related apps**, forcing the entire category toward Progressive Web Apps (PWAs). This is both a barrier and an opportunity: Vitolero's PWA-first approach is not a compromise. It is the industry-standard workaround that the most sophisticated players have already adopted.

### Currently Active Platforms

#### Boxpressd (boxpressd.com)
The most comprehensive cigar social platform currently operating. Relevant as both a competitor and a market validation signal.

- **Format:** PWA, bypasses app store restrictions entirely
- **Features:** Virtual humidor, cigar journal, ratings and reviews, drink pairings, flavor notes, AI-powered recommendations, nearby cigar shop finder, social feed ("what others are smoking")
- **Business model:** Freemium; premium "Cigar Journal" app as paid tier
- **Strategic innovation:** Built the [Cigar Apps Store](https://appstore.boxpressd.com/), a dedicated PWA directory for cigar apps, filling the vacuum left by Apple/Google banning tobacco apps
- **Weakness:** Described by users as glitchy, lacks polish, social features feel underdeveloped; the database is not marketed as comprehensive or definitive

#### Cigar Sense (cigarsense.com)
The most sophisticated recommendation engine in the category, but not an app in the consumer sense.

- **Format:** Mobile-responsive website, no native app (explicitly due to app store restrictions)
- **Technology:** Expert system (not ML/AI), uses 100+ attributes per cigar from blind panelist testing, matched against user preference profiles
- **Business model:** Independent, funded by memberships only, no advertising or investor money, no data sold to brands. Positioned as a trustworthy neutral party.
- **Free tier:** Basic recommendations from thousands of cigars
- **Paid tiers:** Premium access (exact pricing not publicly disclosed)
- **Key limitation:** Complex to use, academic in tone, requires significant user input to work well; not a discovery or social platform

#### Cigar Dojo / Dojoverse (dojoverse.com)
Pioneer that was forced to rebuild as a PWA.

- **History:** Founded 2012 as a native iOS/Android app; eventually removed from both stores due to anti-tobacco policies; rebuilt as PWA "Dojoverse" from scratch over 18+ months
- **Features:** Check-ins, badges for smoking preferences, reviews, ratings, editorial content
- **Current status:** Active as a PWA
- **Business model:** Media and community (primary revenue appears to be cigar brand partnerships and editorial sponsorships)

#### Cigar Scanner (cigarscanner.com)
The closest thing to a photo-identification competitor.

- **Format:** Available on Google Play; iOS status uncertain (app store restrictions)
- **Core feature:** Photo recognition. Take a picture of a cigar and match it against a database.
- **Database size:** ~13,000 premium cigar references
- **Latest version:** 41.1.5 (released Feb 2026, suggesting active development)
- **Weakness:** Database significantly smaller than what Vitolero is building; no AI recommendations, no social features, no drink pairing

#### Unwrappd (apps.apple.com)
- Social-first cigar journal app
- Combines cigar logging with social sharing
- Available on Apple App Store (suggesting compliance-focused approach, likely by avoiding tobacco "promotion" framing)
- Positioned as journal + social network

#### Stogie Match (stogiematch.com)
- AI-powered recommendation engine
- Database of cigars with personalized suggestions
- Relatively new entrant; limited publicly available information about scale or traction

#### Cigaro
- Humidor management focused
- Database of ~11,000 references including Cuban cigars, limited and regional editions
- Niche positioning around inventory management rather than discovery

### Discontinued or Removed Apps

| App | Platform | Status | Reason |
|-----|---------|--------|--------|
| Where to Smoke (Cigar Aficionado) | iOS | Removed Oct 30, 2017 | Apple policy violation: "promotes tobacco products" |
| Cigar Dojo (native) | iOS + Android | Migrated to PWA | Banned from both stores due to anti-tobacco guidelines |
| Multiple trading/sales apps | Facebook | Removed Jul 2019 | Facebook/Instagram ban on tobacco product sales |
| Various early cigar apps | iOS | Removed various | Apple's sweeping tobacco policy enforcement |

### Key Insight

No existing platform combines all three core Vitolero propositions (**photo identification + AI recommendation + drink pairing**) at scale with a comprehensive database. The market is fragmented between a humidor tracker (Cigaro), a recommendation engine (Cigar Sense), a social network (Boxpressd/Unwrappd), and a scanner (Cigar Scanner). The integrated, database-first vision Vitolero is pursuing has no direct equivalent.

---

## 3. Online Community Landscape

### Facebook Groups

Facebook remains the primary community hub for cigar enthusiasts despite ongoing policy conflicts. The platform's 2019 ban on tobacco product sales/transfers fragmented the community but did not eliminate it. Groups shifted from commerce to discussion, or migrated to niche platforms.

**Key groups:**
- **Cigar Cartel:** ~21,000 members; origin of the "'eBay of cigars' on Facebook" model; survived Facebook's temporary closure of several cigar groups
- **C.A.T.S. (Cigar Aficionado Trades and Sales):** ~12,709 members (2016 figure; likely larger now); operates as a secret group; focused on trades and sales despite official restrictions
- **Habana Hideaway, The Cigar Syndicate:** Significant groups that were temporarily shut down and restored
- **Total Facebook cigar group audience:** Estimated tens of thousands across all groups

**Platform history:** On July 24, 2019, Facebook and Instagram formalized bans on tobacco product sales. Groups scrambled to adapt: some went private/secret, some migrated to MeWe, some pivoted to pure discussion. The enforcement was inconsistent, creating ongoing uncertainty. Several groups were closed and then restored "in error" in one incident ([halfwheel.com](https://halfwheel.com/facebook-closes-then-restores-several-cigar-groups/112765/)).

**Behavioral pattern:** Facebook cigar groups are where enthusiasts gather to show off, trade, discuss scores, share "herf" (smoking session) photos, and access peer knowledge. The showing-off and social validation dynamic is strong. Pictures of impressive humidors and rare finds generate high engagement.

### Reddit (r/cigars)

- Described as "one of the largest cigar smoking forums in the world," with membership estimated at 40k+ subscribers (2017 figure; current numbers likely significantly higher)
- Most popular discussion type: information sharing (75.72% of posts)
- 27.17% of posts share taste experiences
- 18.99% discuss affordability/value
- Academic research ([PMC, 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10327260/)) has studied the community, validating its cultural significance
- Characterized by peer education, brand discussions, "BOTL" (Brothers of the Leaf) culture, and newbie-friendly onboarding

### Other Community Platforms

- **BOTL.org (Brothers of the Leaf):** Dedicated cigar forum, buy/sell/trade sections, long-standing community
- **Cigar Asylum:** Described as "the fastest growing and most active cigar forum"
- **FOH (Friends of el Habano):** Cuban cigar specialist community; home of FOH Auctions (Cuban cigar auction platform that emerged as a Facebook alternative)
- **MeWe:** Migration destination for groups banned from Facebook; smaller but more tolerant of tobacco content
- **CigarPass:** Active forum with humidor tracking and trading sections
- **Telegram groups:** Emerging for deals and trades, less regulated

### Behavioral Insights for Product Strategy

1. **Photo sharing is native to the culture.** Enthusiasts already photograph their cigars for social validation. A photo-identification feature meets behavior already happening.
2. **Trust is earned through accuracy.** Communities are sophisticated and quickly dismiss tools with inaccurate data. The database quality is the moat.
3. **Trading is a core behavior.** Box passes, group trades, and single-stick trades create need for inventory tracking and valuation tools.
4. **Newbie onboarding is a pain point.** A large share of community content is answering "what should I smoke" questions. AI recommendations directly solve this.
5. **Show-off culture is strong.** Humidor photos, rare finds, and impressive smokes drive social posting. A sharing-optimized app experience aligns with this.

---

## 4. AI in the Cigar Industry

### Current Applications

**Recommendation engines** are the most mature AI application in the space:
- Cigar Sense uses an expert system (rules-based, not ML) to match user preferences to cigar profiles
- Boxpressd claims ML-based recommendations that improve with user input ("the more you smoke and rate, the better your recommendations become")
- Stogie Match is positioned explicitly as AI-powered
- GPT-based cigar advisors exist as ChatGPT custom GPTs (informal, no dedicated app)

**Photo identification** exists but is primitive:
- Cigar Scanner (13,000 references) uses image matching against a database
- No computer vision model specifically trained on cigar identification at scale has been publicly announced
- The problem space is distinct from wine label recognition (which is solved): cigars lack standardized machine-readable labels, and identification must handle band variations, lighting, angles, and regional editions

**Broader industry AI applications:**
- Manufacturing quality control (tobacco blending consistency)
- "Tobacco Titan": an LLM for the tobacco industry announced by Generative AI Solutions Corp (Oct 2023), aimed at industry operators rather than consumers
- Academic research: AI in tobacco control (public health surveillance, anti-smoking applications, distinct from consumer apps)

### Market Context

The "AI in tobacco industry" market is projected to reach $1.2 billion by 2025, though this figure spans manufacturing, quality control, regulatory compliance, and consumer-facing applications. It cannot be attributed to consumer apps alone.

70% of premium cigar brands are reportedly considering AI for flavor profile analysis ([wifitalents.com](https://wifitalents.com/ai-in-the-cigar-industry-statistics/)), signaling B2B opportunities alongside B2C.

### The Identification Gap

The core insight for Vitolero: **no one has built a well-trained, comprehensive cigar visual identification model**. The Vivino analogy is instructive: Vivino solved wine label recognition with OCR + image matching, growing to 10 million wines in its database. Cigars present a harder technical problem (bands vary, lighting is difficult, many cigars look similar) but also a clearer consumer pain point (enthusiasts regularly receive or buy cigars they cannot identify).

---

## 5. Competitive Landscape

### Direct Competitors (Cigar-Specific Apps)

| Competitor | Core Feature | Database Size | AI? | PWA? | Business Model | Weakness |
|-----------|-------------|--------------|-----|------|----------------|----------|
| Boxpressd | Social + Humidor | Unknown | Yes (recommendations) | Yes | Freemium | Glitchy, fragmented, weak database marketing |
| Cigar Sense | Recommendations | 100+ attributes/cigar | No (expert system) | No (website) | Membership | Complex UX, no photo ID, no social |
| Cigar Scanner | Photo ID | 13,000 refs | No | No (Android only) | Unknown | Small database, no recommendations, no social |
| Cigar Dojo/Dojoverse | Community + Reviews | Editorial | No | Yes | Media/partnerships | Not a utility app, no personal tracking |
| Unwrappd | Social Journal | Unknown | No | No (native iOS) | Unknown | Limited to iOS, no identification |
| Stogie Match | AI Recommendations | Unknown | Yes | Unknown | Unknown | Low visibility, limited traction data |

### Indirect Competitors

**Facebook groups:** Still the dominant community hub. They don't offer apps or tools, but they capture the daily active attention of enthusiasts. Vitolero needs to be the utility layer that complements rather than replaces these communities.

**Cigar Aficionado (cigaraficionado.com):** The industry's editorial authority. Their ratings are the de facto standard for quality signals. They have a database, reviews, and scores, but no app (their "Where to Smoke" app was removed by Apple). They are a potential partner or acquirer, not just a competitor.

**Traditional cigar retailers (Famous Smoke, CI, Cigars International):** Have large product databases and recommendation features on their e-commerce sites, but these are shopping tools, not hobbyist utilities. No social or identification features.

**WhatsApp and private groups:** Informal community channels where enthusiasts share recommendations peer-to-peer. Not a product, but captures the same behavioral need.

### Competitive Positioning Summary

The market has several point solutions (scan a cigar; get recommendations; track your humidor; join a social network) but no integrated platform that does all of these well. Vitolero's opportunity is the **convergence play**: build the world's most comprehensive cigar database and layer photo identification, AI recommendations, and drink pairing on top of it.

The closest analogy is Vivino's early days. Before it owned the category, the wine app space was also fragmented into individual tools.

---

## 6. Regulatory Landscape

### Apple App Store

Apple has the most restrictive tobacco policy in the digital distribution ecosystem.

**Policy language:** Apps that "encourage consumption of tobacco and vape products" are not permitted. Apps that "promote the use of tobacco or nicotine-related paraphernalia, including but not limited to cigars, cigarettes, pipes, hookahs, vaping products or e-cigarettes" are explicitly banned.

**Real enforcement examples:**
- Cigar Aficionado's "Where to Smoke" (a venue finder, not a sales tool) was removed October 30, 2017
- Multiple cigar apps removed over 2017-2020 period
- Cigar Dojo's native app effectively forced to migrate to PWA
- The rule applies broadly. Even companion apps for legal tobacco products have been removed.

**Key inconsistency (noted by industry):** Marijuana apps (Weedmaps, Leafly) remained available for years despite cannabis being federally illegal in the US, while fully legal cigar apps were banned. This inconsistency has not been resolved.

**Implication for Vitolero:** A native iOS app is essentially impossible without stripping all cigar-specific language and functionality. The PWA approach is not just a technical preference. It is a **structural necessity**.

### Google Play Store

More permissive than Apple but tightening.

**Current policy:** Apps facilitating the sale of tobacco, or that encourage irresponsible use, are not permitted. Direct sales are banned.

**2024 update (July):** Policy scope was extended to cover "all products containing nicotine" including nicotine pouches. An exception was created for nicotine cessation aids with age gating.

**Practical status:** Cigar Scanner remains on Google Play as of 2026. Some cigar apps survive by framing themselves as educational tools, avoiding sales functionality, and implementing age verification. Survival on Google Play is possible but requires careful compliance work.

**Implication for Vitolero:** A Google Play app may be feasible as a secondary distribution channel with careful framing, but the PWA should remain the primary surface.

### EU Tobacco Advertising Regulations

The EU operates one of the strictest tobacco advertising regimes globally, with direct implications for any digital marketing Vitolero might do.

**Framework:** EU Directive 2003/33/EC (and subsequent updates) bans cross-border tobacco advertising across print media, radio, and information society services (which includes websites and apps). Directive 2014/40/EU extended some rules to electronic cigarettes.

**Digital gap:** Current EU regulations have not kept pace with social media. The EU's own experts rate "social media advertising more clearly covered by regulation" as the #1 policy priority (97% of experts surveyed). This creates a grey zone where enforcement is inconsistent.

**Practical implications for Vitolero:**
- Cannot run paid ads promoting cigar use in EU markets (Google Ads, Meta Ads will reject tobacco-related ad creative anyway)
- App-store SEO and organic content marketing are the primary available channels
- Email marketing to opted-in users is generally permissible
- Partnerships with cigar retailers and brands require legal review by market
- Age verification within the app is important for compliance posture

**Key nuance:** Vitolero is a cigar identification and recommendation tool, not an advertising or sales platform. This framing may provide regulatory flexibility: helping enthusiasts understand what they're already smoking is different from encouraging smoking initiation. This distinction should be built into the product's legal posture.

### US Regulatory Environment (FDA)

**Major 2024 development:** The FDA's Deeming Rule, which sought to regulate premium cigars with the same authority as cigarettes and e-cigarettes, was **vacated by the DC Circuit Court of Appeals** in 2024. This is a significant industry win:

- Premium cigars are no longer subject to FDA health warning requirements
- No products can be arbitrarily pulled from retail based on the Deeming Rule
- The ruling has settled regulatory uncertainty that hung over the industry for nearly a decade

**Implication for Vitolero:** The US regulatory environment for premium cigars is now more stable and favorable than at any point since 2016. This reduces risk for brand partnerships, retailer integrations, and any future marketplace features.

### VC / Investor Landscape

Beyond app store and advertising restrictions, the sin industry creates **investor barriers**:
- ESG-focused VCs and institutional funds explicitly exclude tobacco companies from their mandates
- Most traditional VC funds have tobacco exclusion clauses
- This means Vitolero's capital path is likely: bootstrapping, angel investors without ESG restrictions, strategic industry investors (cigar brands, retailers), or revenue-based financing
- The bootstrapped, PWA-first, pre-seed positioning is not just a resource constraint. It is arguably the only viable path given investor restrictions

---

## 7. Chinese Cigar Market

### Size and Growth

China is now the world's largest market for Cuban cigars by revenue, a seismic shift that occurred gradually through the 2010s and became official in 2020 when China displaced Spain from the top position.

- **Market size (2023):** USD $4.63 billion ([Grand View Research China Horizon data](https://www.grandviewresearch.com/horizon/outlook/cigar-and-cigarillos-market/china))
- **Projected size (2030):** USD $7.08 billion, CAGR ~6.2%
- **Annual mainland consumption:** 8-10 million cigars (official estimate, likely understated due to grey market)
- **Annual growth rate:** ~15% for mainland sales as of 2020 ([cigars-connect.com](https://www.cigars-connect.com/en/china-1-billion-cigar-lovers/))
- **Dominant brands:** Cohiba and Davidoff dominate luxury positioning; younger consumers exploring Nicaraguan and Dominican varieties

### How China Became #1

The ascent was structural, not accidental:
1. **2017:** Habanos S.A. signed a distribution contract with China National Tobacco Corporation, the world's largest tobacco company, legitimizing premium imports
2. **Expanding middle and upper class** with disposable income seeking status-linked luxury goods
3. **Post-pandemic luxury spending boom:** Sales of luxury products in China jumped 48% in 2020; cigars benefited directly as "luxury goods par excellence"
4. **Social media acceleration:** WeChat, Weibo, and Douyin enabled luxury goods discovery and social signaling at scale

### Consumer Psychology: Status Over Flavor

This is the defining characteristic that differentiates Chinese cigar consumers from Western enthusiasts, and it has major product implications.

**Key dynamics:**

- **Gifting culture is central.** Cigars (especially Cohiba and other Cuban brands) are luxury gifts for important occasions: business negotiations, celebrations, relationship building (guanxi). A box of Cohiba Esplendidos communicates wealth and respect in a way few other portable luxury objects can.
- **Scarcity and brand drive purchase, not flavor.** Unlike Western enthusiasts who develop palates and explore varietals, Chinese consumers (particularly first-generation luxury buyers) prioritize brand recognition and rarity signals. A Cohiba Behike 56 is valuable because everyone knows it is expensive and scarce, not because the consumer can taste the difference from a Cohiba Siglo VI.
- **Showing off is the use case.** Photos of cigar collections and rare finds circulate on WeChat groups and Moments as social capital. The visual, displayable nature of cigars (especially Cuban cigars in distinctive packaging) serves social media-native status signaling.
- **Counterfeit problem is severe.** Fake Cohibas and Montecristos proliferate. Sophisticated packaging is manufactured domestically. This undermines consumer confidence and creates a strong consumer need for **authentication tools**, a direct Vitolero use case.

### Distribution Reality

The official retail infrastructure is extremely thin:
- Only 2 Casa del Habano locations in mainland China
- Only 5 Davidoff stores
- Official import quota is approximately 1.3 million cigars annually (much smaller than actual consumption)

This scarcity drives a substantial parallel/grey market through Hong Kong and duty-free channels. It also means the app opportunity is not primarily about finding local stock. It is about discovery, validation, authentication, and social sharing.

### Implication for Vitolero

The Chinese market presents a compelling medium-term opportunity, but requires localization that goes beyond translation:
- **Authentication / anti-counterfeit** is a killer feature for this market. The ability to photograph a cigar and verify its authenticity against a database would command premium pricing in China.
- **WeChat integration** or a WeChat Mini Program would be more natural than a PWA for Chinese users.
- **Gifting workflows:** suggesting what to give someone of a certain status, with shareable "gift recommendations," could be a unique feature.
- **Brand and scarcity signals** matter more than flavor taxonomy for initial recommendation logic.
- Geographic and regulatory complexity is high: China National Tobacco Corporation controls all domestic tobacco sales; international players must navigate its monopoly.

---

## 8. Comparable Niche Hobby Apps

### Vivino (Wine)

The canonical reference case for Vitolero's product thesis. It is not just analogous: it is the template.

**What Vivino built:**
- **Technology:** Photo label recognition using Vuforia Cloud Recognition (image matching) + ABBYY OCR for wine lists
- **Database:** 10 million wines, 200 million reviews, 1.5 billion label scans
- **User base:** 50 million users (2021 data); 20,000 new downloads per day
- **AI layer:** Personalized match scores for every user/wine pair, built on top of review and profile data
- **Growth path:** Community data contribution created a flywheel: more users meant more scans, better database, better recommendations, more users

**Business model:**
- E-commerce marketplace (55% of revenue): takes a commission on wine sold through the app
- Subscriptions (20%): premium features, exclusive offers
- Advertising to wineries (15%)
- Data services to wineries (10%)
- Wine Club subscription: $120 (annual)

**Funding:** Raised $155 million in February 2021 ([TechCrunch](https://techcrunch.com/2021/02/03/vivino-raises-155-million-for-wine-recommendation-and-marketplace-app/)); previously raised $128.8M in 2019

**Key lesson for Vitolero:** Vivino's moat was the database built through user-generated scans. Every scan improved the product. The recommendation engine became more accurate as the user base grew. This is the exact flywheel Vitolero needs to engineer. The difference: wine was a larger total addressable market, and wine faces less distribution/regulatory friction in app stores.

**Note on regulatory friction:** Wine is also an alcohol product, but Apple and Google treat alcohol apps more permissively than tobacco apps. Vivino has no equivalent distribution problem. Vitolero's PWA approach is the necessary adaptation.

### Distiller (Whiskey/Spirits)

The most direct structural analog in the spirits space.

**What Distiller built:**
- 50,000+ spirits in database
- Flavor-tagged entries, star ratings averaged from millions of user reviews
- Bottle scanning feature (limited to Pro users)
- Expert reviews, weekly new release news, educational content
- Social features: follow other users, activity feeds

**Business model:**
- Freemium with Pro subscription
- **Pro pricing: $4.99/month or $48/year**
- Pro features: bottle scanning (unlimited), flavor-based search, custom lists, content export, first looks at upcoming releases

**Key lesson:** Distiller proved that a serious niche enthusiast community will pay for premium features. $4.99/month is a validated price point for this audience tier. The bottle scanning feature behind a paywall is particularly instructive for Vitolero's monetization thinking.

### Coffee Apps (BeanConqueror)

A counterpoint example of what not to do on monetization.

**BeanConqueror:** Open source, completely free, no subscription, no ads, no paywalls. Integrates with hardware (Acaia scales, Decent espresso machines). Strong community, but zero direct revenue.

**Lesson:** The coffee enthusiast market has bifurcated into:
- Hardware-focused (expensive equipment, app as accessory)
- Community-focused (free apps, monetization unclear)

The absence of a dominant paid coffee app suggests either the market is too hardware-fragmented or the willingness-to-pay is lower. Cigars are more like wine/whiskey (consumable goods with strong brand attachment) than coffee (equipment-dominated hobby). The Distiller/Vivino model is more applicable than the coffee app model.

### Freemium-to-Paid Conversion Benchmarks

From RevenueCat's State of Subscription Apps 2025 ([revenuecat.com](https://www.revenuecat.com/state-of-subscription-apps-2025/)):

| Scenario | Conversion Rate |
|---------|----------------|
| Freemium model (median) | 2.18% |
| Hard paywall (median) | 12.11% |
| Opt-out trial (card required) | 49-60% |
| Opt-in trial (no card) | 18-25% |
| Health & Fitness (category) | 4-12% |
| Good freemium result | 3-5% |
| Excellent freemium result | 6-8% |

**For Vitolero's planning:** At 2.18% median freemium conversion and a $4.99/month price point, reaching profitability requires a meaningful free user base (10,000 free users = ~218 paying subscribers = ~$1,100 MRR). Distiller's model suggests that enhancing features like scanning limits and advanced search behind a paywall creates natural conversion pressure.

---

## 9. Blue Ocean Analysis

### What Exists (The Red Ocean)

The current cigar app landscape competes along these dimensions:
- Humidor inventory tracking
- User ratings and reviews
- Editorial content and scores
- Basic social/community features
- Fragmented, low-quality databases

Nobody competes aggressively on database completeness, photo identification, AI recommendation quality, or cross-category pairing (cigars + drinks).

### Uncontested Market Spaces

#### 1. Comprehensive, Authoritative Database

No cigar database is marketed or perceived as definitive. Cigar Aficionado has authority but not a product. Cigar Scanner has 13,000 entries. Boxpressd has an unspecified database. The claim "world's largest cigar database" is both unoccupied and credible, because no competitor has staked it.

This is Vitolero's primary moat. A database advantage compounds over time: more entries attract more users, more users contribute more data, better data enables better recommendations.

#### 2. Photo Identification at Scale

Cigar Scanner exists, but with 13,000 references and no AI layer, it is more "lookup" than "recognition." True visual identification (handling varied lighting, angles, band variations, regional editions, vintage bands) is unsolved. This is a technically hard problem that becomes a durable competitive advantage once solved. First mover with the best model wins.

#### 3. Cross-Category Pairing Intelligence

"What drink goes with this cigar" is a question enthusiasts ask constantly. It sits at the intersection of cigar knowledge and spirits/wine/coffee knowledge. No platform has built a serious, data-driven pairing engine. This is a blue ocean feature with natural virality (shareable "I paired this Padron 1964 with a Glenfarclas 25" moments).

#### 4. Authentication for the Chinese Market

The counterfeit cigar problem in China is acute, well-documented, and unsolved. No digital tool addresses it. An authentication feature (photograph a cigar's band, packaging, and foot, verify against a database of known genuine examples) would be a premium, subscription-worthy feature with strong willingness-to-pay among Chinese luxury buyers.

#### 5. PWA-First Cigar App Store

Boxpressd has created a cigar PWA directory, but it is underdeveloped. Vitolero could position its app as the platform that aggregates the fragmented cigar app ecosystem, not just its own product. This is a platform play that could generate network effects beyond the core recommendation use case.

#### 6. Newbie-to-Enthusiast Journey

A structurally underserved segment: people who have just started smoking premium cigars and have no vocabulary, reference points, or community. The existing tools (Cigar Sense, Boxpressd, Cigar Scanner) require existing knowledge to use effectively. A "cigar learning journey" product (starting from "I just smoked my first cigar, it was this" and building a personalized flavor profile over time) has no dedicated solution.

#### 7. Retailer and Brand B2B Layer

Cigar Sense already shows this is viable: they sell analytics and recommendation APIs to cigar retailers and manufacturers. Vitolero's database, built for consumers, could power a B2B product: recommendation widgets for retailer websites, brand analytics, new release positioning. This B2B layer is a revenue diversification path that escapes both consumer acquisition challenges and investor ESG restrictions.

### Underserved Segments

| Segment | Current Pain | Vitolero Solution |
|---------|-------------|-----------------|
| New enthusiasts | Overwhelmed by choice, no vocabulary | Onboarding flow, simple first recommendations |
| Gifters | Don't know what to buy | "Gift this cigar" flows with status and occasion matching |
| Chinese luxury buyers | Counterfeit anxiety | Authentication feature |
| Humidor collectors | No valuation tool | Collection value tracking |
| Pairing seekers | No data-driven guidance | Drink pairing engine |
| Box pass participants | Tracking incoming/outgoing cigars | Box pass management feature |
| Retailer customers | Generic "top sellers" recs | Personalized recommendations at point of sale |

### The Vivino Parallel: And Where It Breaks

Vivino's flywheel was: scan a label, get a rating, the scan improves the database, better ratings bring more users, more scans. This flywheel is replicable for cigars with one major structural difference: **distribution**.

Vivino could live in the App Store. Vitolero cannot.

This means Vitolero's user acquisition funnel must bypass the App Store discovery mechanism that drove Vivino's early growth. The compensating strategies:
- **SEO-first content strategy** (ranking for "[cigar name] review", "what drink pairs with X cigar")
- **Community embeds** in Reddit, Facebook groups, BOTL communities: become the utility tool communities link to
- **QR codes in cigar shops and on bands:** physical-to-digital acquisition
- **Cigar retailer partnerships:** embedded as a recommendation tool on retailer sites
- **Social media-native features:** shareable "I just smoked" cards for Instagram/X that drive app installs

The inability to use paid advertising on major platforms (Google Ads, Meta) due to tobacco restrictions reinforces the need for a fundamentally organic, community-driven acquisition strategy.

---

## Summary: Key Strategic Implications

1. **The database is the moat.** No one has built the definitive cigar database. First-mover with the most comprehensive, well-structured data wins the long game.

2. **PWA is not a weakness.** It is the industry standard. Every sophisticated cigar digital product has moved or is moving to PWA. Vitolero's architecture matches the regulatory reality.

3. **The Vivino playbook applies with modifications.** Photo identification + database + AI recommendations is a proven formula. The adaptation needed is around distribution (no App Store) and community-driven growth (no paid advertising).

4. **China is a high-value, high-complexity opportunity.** The authentication use case is a potential premium feature that could command significantly higher willingness-to-pay than the Western market.

5. **Fragmented competitors create consolidation opportunity.** The incumbent landscape is fragmented, underfunded, and serving different point needs. An integrated platform with superior database coverage and UX can capture share across all of them.

6. **Investor path is non-traditional.** ESG restrictions eliminate most VC. Strategic investors (cigar brands, retailers, distributors) and revenue-based financing are the viable paths.

7. **Freemium with feature gating is the validated model.** Distiller at $4.99/month with scanning behind the paywall is the most directly applicable pricing precedent.

8. **B2B is the under-explored lever.** Cigar Sense validates the B2B API/analytics model. Vitolero's database, once comprehensive, could power retailer recommendation widgets and brand analytics, a revenue stream that does not require consumer subscription scale.

---

## Sources

- [Grand View Research: Cigar & Cigarillos Market](https://www.grandviewresearch.com/industry-analysis/cigar-cigarillos-market)
- [Straits Research: Cigar Market](https://straitsresearch.com/report/cigar-market)
- [Polaris Market Research: Luxury Cigar Market](https://www.polarismarketresearch.com/industry-analysis/luxury-cigar-market)
- [Cigar Association of America: 2024 Import Report](https://cigarsusa.org/)
- [Cigar Aficionado: Premium Cigar Imports 2023](https://www.cigaraficionado.com/article/premium-cigar-imports-to-the-united-states-reach-467-million-for-2023)
- [Cigar Aficionado: Apple's War on Cigars](https://www.cigaraficionado.com/article/apple-s-war-on-cigars)
- [Cigar Aficionado: Apple Removes Where to Smoke](https://www.cigaraficionado.com/article/apple-removes-where-to-smoke-from-its-app-store)
- [Cigar Aficionado: FDA Deeming Rule Vacated](https://www.cigaraficionado.com/article/fda-deeming-rule-fully-vacated-for-premium-cigars)
- [Renegade Cigars: Cigar Market Statistics](https://renegadecigars.com/blogs/news/key-cigar-statistics-on-sales-imports-and-consumer-behavior)
- [halfwheel: Facebook Closes Cigar Groups](https://halfwheel.com/facebook-closes-then-restores-several-cigar-groups/112765/)
- [Cigar Journal: Facebook Ban and Alternative Platforms](https://www.cigarjournal.com/new-online-platforms-the-way-forward-after-facebooks-cigar-sales-ban/)
- [Cigar Sense: Technology Explanation](https://www.cigarsense.com/is-cigar-sense-technology-ai-based/)
- [Boxpressd: Cigar Apps Store](https://appstore.boxpressd.com/)
- [Boxpressd Blog: PWA Solution to App Store Restrictions](https://blog.boxpressd.com/cigar-apps-store-by-boxpressd-a-thoughtful-solution-to-anti-tobacco-restrictions/)
- [Cigar Dojo: About the PWA Migration](https://cigardojo.com/app/)
- [Cigar Scanner: App Details](https://www.cigarscanner.com/)
- [PMC: Public Perceptions of Premium Cigars on Reddit](https://pmc.ncbi.nlm.nih.gov/articles/PMC10327260/)
- [Cigars Connect: China 1 Billion Cigar Lovers](https://www.cigars-connect.com/en/china-1-billion-cigar-lovers/)
- [Cigar Aficionado: China Becomes No. 1 Market](https://www.cigaraficionado.com/article/china-becomes-no-1-market-for-cuban-cigars)
- [Grand View Research: China Cigar Market](https://www.grandviewresearch.com/horizon/outlook/cigar-and-cigarillos-market/china)
- [Tobacco Asia: China Biggest Market for Cuban Cigars](https://www.tobaccoasia.com/news/china-now-biggest-market-for-cuban-cigars/)
- [EUR-Lex: EU Tobacco Advertising Directive](https://eur-lex.europa.eu/EN/legal-content/summary/tobacco-advertising-and-sponsorship.html)
- [EU Commission: Ban on Cross-Border Tobacco Advertising](https://health.ec.europa.eu/tobacco/ban-cross-border-tobacco-advertising-and-sponsorship_en)
- [Google Play: Tobacco Policy](https://support.google.com/googleplay/android-developer/answer/6161122?hl=en)
- [Apple Developer: App Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Vivino: PTC Case Study](https://www.ptc.com/en/case-studies/vivino)
- [ABBYY: Vivino OCR](https://www.abbyy.com/company/news/abbyys-ocr-helps-power-vivino-the-worlds-most-popular-wine-app/)
- [TechCrunch: Vivino $155M Raise](https://techcrunch.com/2021/02/03/vivino-raises-155-million-for-wine-recommendation-and-marketplace-app/)
- [Distiller: App Description](https://distiller.com/articles/everything-you-need-to-know-about-the-distiller-app)
- [RevenueCat: State of Subscription Apps 2025](https://www.revenuecat.com/state-of-subscription-apps-2025/)
- [Stogie Match: AI Recommendations](https://www.stogiematch.com/)
- [Tobacco Asia: AI Revolution in Tobacco](https://www.tobaccoasia.com/features/ai-ignites-a-tobacco-industry-revolution/)
- [Tobacco Law Blog: FDA Appeal](https://www.tobaccolawblog.com/2024/04/whats-at-stake-for-the-premium-cigar-industry-as-dc-circuit-considers-fda-appeal/)
