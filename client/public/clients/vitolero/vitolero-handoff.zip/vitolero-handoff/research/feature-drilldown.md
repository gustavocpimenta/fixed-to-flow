# Vitolero: Full Feature Drilldown

---

## MVP status

The product is scoped to three MVP features: Snap & Share with photo filters, one-directional Pairing, and Journal. Everything else is deferred. Use this table to read the feature drilldown below with the right lens.

| Feature | Status | Notes |
|---|---|---|
| **Snap & Share (with photo filters)** | **MVP** | Cigar-specific photo filters (3 to 5 overlays) are the core value. Brand and line overlay composited on the photo. Deep links only. |
| **Cigar Identification (brand + line)** | **MVP (scope reduced)** | Brand and line only. Vitola deferred. Target latency under 10s (vs. current 40-50s for full pipeline). |
| **Pairing (one-directional, 3+3)** | **MVP (scope reduced)** | Cigar to food and drink only. Exactly 6 items. Latency 10-15s. |
| **Journal (Pinterest-style gallery)** | **MVP** | Replaces Humidor/Cabinet as MVP collection surface. Account creation triggered by opening Journal. |
| **Onboarding** | **MVP (rewritten)** | First 30 seconds: photo, filter, ID, share. Account deferred to Journal access. |
| **In-store Recommendation (UC 2.1)** | Post-MVP | Depends on taste profile, which is post-MVP. |
| **Discovery Feed / Recommendations (browsing)** | Post-MVP | Depends on taste profile. |
| **Signature Taste Profile** | Post-MVP | Journal data can be shaped to support this from day 1 even without UI. |
| **Pairing (reverse: drink-to-cigar, UC 3.3)** | Post-MVP | Out of MVP scope. |
| **Pairing (menu-aware, UC 3.2 / 3.4)** | Post-MVP | Out of MVP scope. |
| **Vitola identification** | Post-MVP | Trimmed for speed. |
| **Cigar Doctor / Age & Restore** | Post-MVP (paywall candidate) | Post-MVP; good candidate for future paywall. |
| **Photo Import (camera roll / FB / IG)** | Post-MVP | Meta API blocked; camera-roll import viable but not MVP. |
| **Humidor / Watchlist (inventory)** | Killed for MVP | Journal replaces the "collection" surface. No inventory tracking. |
| **Cigar Authentication** | Killed (tech blocked) | Multi-layered process not yet feasible. |
| **Instagram browsing** | Killed for MVP | Low-priority feature. |
| **Global Concierge** | Post-MVP (premium add-on) | Placeholder. |
| **Offline AI (catalogue enrichment)** | Ongoing (infrastructure) | Not user-facing but feeds pairing quality. |

---

## 1. Onboarding

### What it does
Captures user profile and taste preferences with minimal friction. No wizard, no lengthy questionnaire.

### Steps (current webapp)
1. **Name your favourite cigars** (text input, placeholder: "Cohiba Behi")
2. **Add cigars to collection** (two paths: type cigar name OR take/upload cigar photo)
3. **Save your profile** (Sign in with Google OR skip with "Finish")

### What the system captures
- Experience level / user type (curious newbie, tried a few times, going deeper, mid level, veteran, show off)
- Taste preferences via at least 3 cigars they've enjoyed (photo or name)

### PRD requirements
- UC 1.1: Capture user profile (experience level, motivation)
- UC 1.2: Capture taste preferences via 3+ cigars
- UC 1.3: Inform user clearly what the app can do (critical: no analog product exists)
- UC 1.4: Language-agnostic. All UX, text, and content adapts to user's preferred language and region.

### Design context
- The first native app failed because onboarding asked users to select from brand lists. Users rejected it.
- Signal: users want to "pick it up, do whatever, say whatever, take a photo, and you should do the magic."
- 3 cigars is enough to build a preference profile (flavor, price index, strength, origin).

### Open questions
- How does the app detect motivation (flavor vs status vs social) without asking?
- No current mechanism in the webapp for experience level capture.
- Onboarding does not communicate what the app does (UC 1.3 gap).

---

## 2. Cigar Expert (Discover & Identify)

### What it does
Identifies cigars from photos and returns detailed information and/or personalized recommendations.

### Current webapp UI
- **Entry point:** "Discover & Identify" card on home screen, plus "Identify/Discover" button in bottom nav
- **Input options:** Capture Photo, Upload Photos, Record Voice, Comment (text)
- **Output:** Results list ("Ready to identify..." placeholder)

### AI Feature
| Field | Detail |
|---|---|
| User input | Photo and/or text description |
| What AI contributes | Identifies the cigar, explains its visual characteristics |
| Personalized? | No. Searches the full catalogue |

### Use cases (from PRD)
- **UC 2.1:** Photo of shop's full selection (50+ cigars) → personalized ranked recommendations based on profile, with optional filters (budget, time, mood)
- **UC 2.2:** Photo of a shortlist of cigars → recommendation based on specified criterion (rating, value, strength)
- **UC 2.3:** Photo of unidentified cigar(s) → identification with details (brand, line, flavor, origin, age)

### How identification works (technical)
- Accepts photo, text, or both simultaneously. Inputs processed in parallel, results merged into single live stream.
- Photos analyzed from multiple angles, including partially visible cigars at frame edges. Cigar band is primary visual signal.
- Sommelier-style narrative accompanies results (describes what AI sees: band design, wrapper color, shape) to keep user engaged during loading.
- Only results at 80%+ confidence surfaced. Lower-confidence matches silently filtered.
- Up to 3 catalogue matches per identified cigar.
- Duplicates suppressed across input sources.
- Results may vary between identical requests (non-deterministic confidence scoring).
- Optional second-pass refinement exists but disabled (would push response from ~10s to ~30s).

### Product decisions
- Cigar ID is pure identification only. No recommendation or preference adjustment in current implementation. Separate feature from recommendation.
- Target: 95%+ accuracy for production (currently ~80%).
- Response time: ~10 seconds per identification.

### Open questions
- UC 2.1 requires personalization but the AI feature itself is not personalized. How does the recommendation layer sit on top of identification?
- Voice input accuracy in noisy environments (cigar lounges)?
- What happens when identification fails (low confidence)? No visible error state in webapp.

---

## 3. Cigar Pairing (Perfect Pairing)

### What it does
Matches cigars with drinks and food based on flavor profiles.

### Current webapp UI
- **Entry point:** "Perfect Pairing" card on home screen, plus "Pair" button in bottom nav
- **Input:** Same input bar (photo, voice, text, gallery)

### AI Feature: Reverse Pairing
| Field | Detail |
|---|---|
| User input | Photo or description of food/drink |
| What AI contributes | Interprets the flavour profile of the food or drink |
| Personalized? | Yes. Only searches the user's cabinet |

### Use cases (from PRD)
- **UC 3.1:** User has a cigar, needs a drink recommendation (open-ended)
- **UC 3.2:** User has a cigar, photographs a drinks menu, gets pairing from that menu
- **UC 3.3:** User specifies a drink, needs a cigar recommendation (reverse pairing) **[ONLY ONE CURRENTLY IMPLEMENTED]**
- **UC 3.4:** User photographs multiple cigars and a menu, asks for optimal pairings

### How reverse pairing works (technical)
- User provides photo or text of food/drink.
- AI interprets flavour profile across four dimensions (not specified in PRD).
- Dimensions matched against each cigar's flavour notes, body strength, smoking duration using weighted deterministic scoring. AI contributes only food/drink interpretation. Ranking is deterministic.
- Results personalized to user's cabinet (saved cigars only).
- Returns top 5 recommendations with pairing score.
- Requires non-empty cabinet. Image quality affects accuracy.

### Gap identified in PRD
UC 3.1, 3.2, and 3.4 (cigar-to-drink direction) are not yet covered by a dedicated AI feature. Current implementation only supports reverse direction (drink/food-to-cigar). This is explicitly called out as a gap.

### Design note
From a user perspective, the distinction between "pairing" and "reverse pairing" is not meaningful. Users do not think in terms of direction. Merging both into a single unified feature is the recommended UI treatment.

---

## 4. Cigar Doctor (Age & Restore)

### What it does
Diagnoses cigar issues (damage, defects, flavor problems) and recommends solutions.

### Current webapp UI
- **Entry point:** "Age & Restore" card on home screen, plus "Restore" button in bottom nav
- **Description:** "Having trouble with a cigar? Suspicious blemishes or flavour loss? Let us identify the issue and get a solution."

### AI Feature
| Field | Detail |
|---|---|
| User input | Issue category + optional photo/description |
| What AI contributes | Diagnoses the issue and suggests causes and remedies |
| Personalized? | Yes. Tailored to the user's specific issue |

### Use cases (from PRD)
- **UC 4.1:** Photo of cigar with suspicious defect → identifies problem (mold vs. chlorophyll), explains cause, recommends action
- **UC 4.2:** User describes taste issue (harsh, flat) → diagnoses and recommends aging plan

### How it works (technical)
- User selects issue category from guided navigation menu, then optionally provides photo and/or text.
- Hybrid routing: common well-understood categories get pre-authored expert responses immediately (no AI call). Complex/open-ended issues go to AI for tailored diagnosis.
- Photo quality directly affects diagnosis depth.

### Product decision
This feature is deferred to post-MVP. Infrequent use case, pro-level feature. Good candidate for a future paywall. Evidence: Facebook group questions about damaged cigars exist but are infrequent.

---

## 5. Recommendations (Browsing & Discovery)

### What it does
Personalized cigar feed based on user profile. Browse through cigars pre-selected to match taste.

### Current webapp UI
- **Entry points:** "Recommendations" tab in collection area, "Unlock your Signature Taste" button
- Three collection tabs: Humidor, Watchlist, Recommendations

### AI Feature
| Field | Detail |
|---|---|
| User input | None at request time |
| What AI contributes | Enriches cigar attribute data offline (strength, flavour, body, etc.) |
| Personalized? | Yes. Scored against the user's taste profile |

### How it works (technical)
- Does not call AI at runtime. Fully deterministic scoring system.
- Builds taste profile from user's cabinet (averaging preferred strength, size, price range, most frequent flavour notes).
- Ranks full catalogue against profile using fixed weighted criteria.
- "Similar cigars" view uses the specific cigar being browsed as reference point (not overall profile), but same AI-enriched attributes drive matching.
- Requires non-empty cabinet. Scoring weights fixed and do not learn over time beyond cabinet composition changes.
- The cigar attributes used (strength, body, flavour notes, smoking duration) are AI-derived offline from aggregated product data and user reviews.

### PRD future items
- "You might also like" recommendations when browsing a specific cigar
- Location-aware purchase availability
- News, offers, events, history, media content

### Design notes
- An "Instagram-style browsing" experience is a desired direction for post-MVP.
- Collection/retention strategy: want users to build collection to stay invested. Avoid forcing engagement.

---

## 6. User Collections (Cabinet/Humidor)

### What it does
Personal cigar collection management. Stores cigars the user owns, wants, or has tried.

### Current webapp UI
Three tabs in collection area:
- **Humidor** (owned cigars)
- **Watchlist** (want to try)
- **Recommendations** (AI-suggested)

### Role in the system
- Cabinet is the backbone for personalization. Reverse pairing only searches the user's cabinet. Recommendations score against cabinet composition.
- Onboarding feeds into cabinet (3 initial cigars).

### Open questions
- How do cigars get added post-onboarding? Through identification results? Manual add?
- Is there a "tried it" / rating mechanism?
- Cabinet persistence across devices (PWA session management)?

---

## 7. Other Services / Global Concierge

### Current webapp UI
- **Entry point:** "Other Services" card, plus "More" button in bottom nav
- Contains: "Delete Account" button
- Label in nav: "Global Concierge"

### Product vision
- "Cigar concierge": advisor, buddy, and collection manager.
- Add-on service concept: concierge to find specific cigars (niche, premium).
- Placeholder for future features.

---

## 8. Input Layer (Cross-cutting)

### Current webapp input options
1. **Capture Photo** (camera)
2. **Upload Photos** (gallery)
3. **Record Voice** (microphone)
4. **Comment** (text input)
5. **Send** button to submit

### From PRD
- Photo-first. Camera is primary input. Voice or text is secondary and optional.
- All inputs processed in parallel and results merged.
- Voice: user talks naturally, LLM extracts rich context from unstructured speech.

### Design notes
- Voice is natural in cigar lounges but awkward in public settings. Context-aware input switching is a future possibility.
- Video + voice as input (recording video and talking over it) is a direction worth exploring post-MVP.
- Voice and text comment combined are among the most powerful input modalities.

---

## 9. App Shell & Navigation

### Current webapp structure
- **Top bar:** Install app button, Vitolero logo, Menu hamburger
- **Bottom nav:** Discover, Pair, Restore, More
- **Main regions:** Camera/input area, Results area, Collection area (with Humidor/Watchlist/Recommendations tabs), Feature cards area (Discover & Identify, Perfect Pairing, Age & Restore, Other Services)

### Platform
- Progressive Web App (PWA), installable on device
- Multi-device: phone, tablet, laptop
- No App Store dependency
- Mobile-first

### Design direction
- Split screen concept: browsing/collections at top, action area at bottom
- Current UI issues: too much on screen, green info overlay problematic, scrolling with info flashing, action buttons too condensed
- Smoke animation and 3D effects add noise
- Agreed direction: minimalistic

For the full navigation rules (camera pip, journal pip, account creation triggers), see strategy/navigation-plan.md.

---

## 10. Offline AI (Catalogue Enrichment)

### What it does
Background process that enriches the cigar database with AI-derived attributes.

### How it works
- Extracts flavor profiles from user reviews
- Computes smoking duration from community data
- Populates missing attributes from crowd data
- Sources that don't have specific info get it from aggregated sources

### Why it matters for UX
- All deterministic features (recommendations, pairing scoring) depend on the quality of this enrichment.
- Key dependency: if cigar attribute data is inaccurate or incomplete, scoring formulas produce poor results regardless of their own logic.

---

## Feature Priority Matrix

| Feature | MVP Status | Rationale |
|---|---|---|
| Cigar Identification | MVP (brand + line only) | Hero feature. Vitola deferred for speed. |
| In-store Recommendation | Post-MVP | Depends on taste profile, now post-MVP. |
| Pairing (unified bi-directional) | MVP (one-way only, 3+3 items) | High-value. One-directional in MVP. |
| Onboarding (progressive) | MVP (rewritten) | First 30 seconds flow. Account on Journal access. |
| Recommendations feed | Post-MVP | Depends on taste profile. |
| Cigar Doctor | Post-MVP (paywall candidate) | Post-MVP. |
| Instagram browsing | Killed for MVP | Low priority. |
| Global Concierge | Post-MVP | Premium add-on. |
| Photo Filters | MVP (core value) | 3-5 overlays. Core share-worthiness driver. |
| Journal | MVP | Replaces Humidor as MVP collection surface. |

---

## Design Principles

1. **Photo first.** The camera is the primary input.
2. **Minimal friction.** Zero or one tap to reach any core function.
3. **Sense and respond.** The app detects interaction type and adapts.
4. **Companion, not tool.** Learns and adapts over time.

---

## Three Tensions to Resolve

1. **Intelligence without interface.** The AI knows a lot. The interface must not get in the way.
2. **Future vs present.** Radical simplicity vision vs. users' traditional app expectations.
3. **Different people, different reasons.** Flavor, status, social, relaxation. One interface, multiple motivations.
