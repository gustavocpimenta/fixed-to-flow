# Vitolero: research-backed user personas

**Method:** Online community mining (Reddit, Facebook, app store reviews). No interviews.
**Sources:** r/cigars (240k+ members), r/cubancigars, r/CigarReview, 6 Facebook cigar groups, App Store/Google Play reviews for Cigar Scanner, Cigar Boss, My Humidor, Cigaro, HUMI, Cigarista, Cigarwell, and Vivino (wine analog).

---

## MVP prioritization

The MVP delivers three features: Snap & Share with photo filters, one-directional Pairing, and Journal. The only persona whose core jobs are fully served by those three features is **Dave, the Weekend Ritualist**. He is US-based, smokes alone, and already photographs and shares cigar moments on Facebook. The MVP's filter-powered share loop maps directly onto behavior he already has.

The other five personas remain relevant long-term but are not the MVP design target. A short summary of how each is served in MVP vs. post-MVP:

| Persona | MVP priority | How MVP serves them | Post-MVP unlock |
|---|---|---|---|
| **Dave (Weekend Ritualist)** | **MVP-Primary** | Filter + brand/line ID + share + pairing + journal all map to his ritual. | Recommendations deepen retention. |
| **Carlos (Deepening Enthusiast)** | Served post-MVP | Journal stores his snaps. Pairing output is shallow for his taste. | In-store rec + discovery feed + structured tasting notes. Brand and line ID accuracy on well-known cigars still matters in MVP because Carlos will find the app through Facebook groups and judge it publicly. |
| **Mark (Celebratory Occasional)** | Served post-MVP | Share card gives him something to say at a milestone. | Occasion-based recommendations. |
| **Tyler (Curious Newcomer)** | Served post-MVP | Photo-first sidesteps vocabulary gap; filter + ID works for him too. | Guided recommendations with plain-language output depth. |
| **Jerome (Lounge Social)** | Served post-MVP | Share card gives him something to say at the lounge. | Quick lookup and social-context recommendations. |
| **Richard (Collector-Connoisseur)** | Served post-MVP | Journal holds his scans but is not an inventory system. | Collection management at scale, aging tracking, export. |

The operational design principle: **build for Dave, design for Dave's Saturday-night solo smoke**. Carlos reclaims priority once recommendations ship.

---

## How to read this document

Each persona maps to a distinct user type, organized into three tiers: Primary (design for these), Secondary (acquisition funnel), and Tertiary (served indirectly). The research either validates, refines, or challenges each profile.

Each persona includes:

- **Who they are** (demographics, context, lifestyle)
- **Why they smoke** (motivation, emotional driver)
- **How they choose** (decision-making behavior)
- **Pain points** (frustrations, unmet needs)
- **Community language** (actual quotes from forums and groups)
- **What they'd want from Vitolero** (app expectations)
- **Vitolero fit assessment**

---

## The ritual lens

This document is organized around a single framing shift that Dimitar introduced: cigar smoking is a ritual, not a hobby.

The distinction matters for product design. Dimitar's argument: hobby implies something done out of passion but lacking structure, often temporary or a pastime. Cigar smokers call themselves aficionados and connoisseurs. The closest cultural analog is wine. Both require specific ritual: the tools, the setting, the process of engaging with the cigar or wine, the time dedicated to it.

A hobbyist might pick up and drop a pursuit. A ritualist builds a practice. The ritual has structure, cadence, and meaning. The gear matters. The moment matters. The sequence of lighting, smoking, pairing matters.

This reframe has direct product implications:

**Onboarding.** People don't join to track data. They join because a ritual matters to them and they want to do it better. Vitolero's entry point should feel like entering a practice, not registering for a database.

**Recommendations.** A ritual-aware recommendation considers context (when, where, with what, with whom), not just flavor preferences. "Pair this with bourbon on a Saturday evening" is a ritual-native recommendation. "This cigar scores 87 points" is not.

**Retention.** Hobbyists churn when they get bored. Ritualists return because the ritual recurs. The app that fits naturally into the smoking moment becomes part of the ritual itself.

**Depth gradient.** The six personas below represent different depths of ritual engagement, from someone building their first practice (Curious Newcomer) to someone whose ritual is a decades-long discipline (Collector-Connoisseur). Good UX adapts to the depth of the ritual without requiring anyone to declare which level they're at.

Every design decision should pass a ritual-lens test: does this feature serve the moment, or does it interrupt it?

---

## Persona tiers

**Long-term priority (full product, post-MVP):**

| Tier | Personas | Design priority |
|---|---|---|
| **Primary** | Weekend Ritualist, Deepening Enthusiast | Design for these two at the full product level. They represent 70-80% of active users by Facebook group observation. Highest engagement, strongest retention. |
| **Secondary** | Celebratory Occasional, Curious Newcomer | Acquisition funnel. Served by the same UX patterns designed for Primary. Lower complexity, lighter output. |
| **Tertiary** | Lounge Social, Collector-Connoisseur | Served indirectly. Lounge Social benefits from share card appeal and quick lookup. Collector-Connoisseur benefits from database depth and accuracy. Neither requires dedicated UX patterns. |

**MVP priority:** Dave (Weekend Ritualist) is the sole MVP-primary. Every other persona moves to "served post-MVP" until recommendations, in-store rec, discovery feed, and collection features ship. See the MVP Prioritization section above.

---

## Persona 1: The Weekend Ritualist

**Tier: PRIMARY**

**Name:** Dave
**Age:** 47
**Location:** Austin, Texas, USA
**Occupation:** Marketing director at a mid-size agency

**Spend:** $800-3,000/year
**Frequency:** 2-4 cigars/week
**Collection:** Desktop humidor, 15-40 cigars
**Primary need:** Discovery, simple recommendations, pairing guidance

### Who they are

Dave has been smoking cigars for 3 to 5 years. He smokes on weekends, usually on his back porch with bourbon. He owns a desktop humidor with around 20 cigars. Married, one kid, knows he likes Padron and Oliva but can't say exactly why. He's a corporate professional who values the "slowing down" moment. He's not a "cigar guy" by identity. He's a ritualist.

Dave is the MVP-primary persona. He smokes alone, shares individually, and is middle-aged US. He already photographs his cigar moments and posts them to Facebook groups. The MVP's filter-powered share loop maps directly onto behavior he already has, not behavior the app has to teach him. If Dave's share rate on filtered photos exceeds his share rate on raw phone photos, the MVP hypothesis is validated. If not, the MVP's anchor feature is wrong.

This is the person who has built a cigar practice as part of a weekly routine. Weekend evenings, post-work decompression, social gatherings with friends. The cigar is the anchor of the moment, not the subject of study. He smokes actively (multiple times per week) but has no ambition to become an expert. His collection is modest but intentional: a few favorites, a few things he wants to try.

Pairing is intuitive and culturally shaped. Default pairing varies by geography: bourbon and whiskey in the US, beer in Brazil ("cerveja e charuto, combinacao perfeita"), whisky in Bulgaria (the largest Bulgarian group is literally called "Whisky and cigars with friends"). Vitolero's pairing feature must not default to one culture.

### Why they smoke

The experience, not the product. This persona was captured in a post that earned 1,800+ upvotes: "I can't name a single note, or discern a cheap cigar from a Cuban, but I enjoy the way a cigar makes me enjoy a moment." The comment section was a wave of self-recognition:

- "It's for the meditative moment by myself or a new hobby to share with loved ones"
- "One of the best things about smoking a cigar is it's a great way to relax and kill an hour or so"

The cigar is a ritual object for slowing down. Pairing is intuitive: this feels right together, not systematically paired.

### How they choose

By brand familiarity and trusted recommendations. Three to five go-to brands (typically Padron, Oliva, Arturo Fuente, Romeo y Julieta) and occasionally tries something new when a friend or shop clerk suggests it. Labels get saved. One user's strategy: "If I like one, I save the label and just ask the guy in the cigar shop for similar cigars in a similar price range, and the rest is up to him."

**Behavioral patterns observed:**
- Posts smoking-moment photos (cigar + drink + setting)
- Engages with celebration posts (birthdays, milestones, weather)
- Describes flavor in broad strokes: "creamy," "sweet," "strong," "smooth"
- Values consistency over novelty
- Some are 3+ years in and still can't identify specific notes: "I dunno, 3+ years in now and I can't tell you much in the way of cigar notes"

### Pain points

1. **Can't articulate preferences to others.** When traveling and visiting a new shop, can't describe what they like. The knowledge is in their head but lacks the vocabulary to express it.
2. **Pairing is guesswork.** Pairs by feel. Would welcome guidance but doesn't want a lecture.
3. **App overload.** Existing cigar apps demand more engagement than the Weekend Ritualist wants to give. One reviewer: "Wait, you think I want to do inventory on my cigars?"
4. **Inconsistency between cigars.** Some cigars from the same box taste different. Humidity, storage, rolling variation. Quiet frustration with no outlet.
5. **Don't want to become "cigar guys."** Enjoys cigars but resists the identity. The community's deep knowledge can feel exclusive and unwelcoming.

### Community language

- "They taste like cigars. Some are harsher than others. They're all enjoyable to me."
- "Best I can do is creamy, sweet or strong as description"
- "I hadn't looked into it, but kinda taught myself how to retrohale. That was the moment it clicked!"
- "I know what I like, but I can't tell you what it is"
- "It's a great way to broaden your palate and try different things in a cost effective way"

### What they'd want from Vitolero

- **Remember preferences silently.** Build a taste profile from behavior, not questionnaires.
- **Pairing recommendations.** The "photo of menu + get a pairing" use case maps directly here. They'd actually use it.
- **Low maintenance.** Will not log every cigar smoked. The app needs to work with minimal input.
- **Social moments, not data.** If the app tracks anything, it should feel like a journal of moments, not an inventory system.

### Vitolero fit: Strong

This persona is the sweet spot for Vitolero's core use case (in-store recommendation, pairing). The risk is building features that feel like homework.

---

## Persona 2: The Deepening Enthusiast

**Tier: PRIMARY**

**Name:** Carlos
**Age:** 34
**Location:** London, UK
**Occupation:** Financial analyst

**Spend:** $2,000-6,000/year
**Frequency:** 3-5 cigars/week
**Collection:** Desktop humidor or cooler setup, buys boxes, 50-200+ cigars
**Primary need:** Precision recommendations, database depth, tasting note structure

### Who they are

Carlos has been smoking seriously for 2 to 5 years. He smokes several times a week and has a proper humidor. He knows wrapper types and understands fermentation and aging. He follows specific blenders (AJ Fernandez, Nick Melillo, Litto Gomez) and knows which factories produce which brands. He's active on r/cigars, posts reviews, posts HAUL photos. He's building a mental map of the cigar world and actively seeking to expand it.

This persona is in the process of becoming an expert and finds that process genuinely exciting. Cigars have become a practice with structure. He tracks what he smokes, knows what he likes and what he doesn't, and is willing to put in effort to get better recommendations. He's the person who leaves detailed reviews, asks highly specific questions, and notices when a database has a missing vitola.

### Why they smoke

Flavor exploration and deepening knowledge. The thrill is discovery: finding a new cigar that surprises them. Also the intellectual pleasure of building expertise. There's a satisfaction in knowing why something tastes the way it does.

### How they choose

By specific criteria. Unlike the Weekend Ritualist who says "something good," the Deepening Enthusiast articulates preferences precisely: "I really like strong flavors and high nicotine, but there is just some kind of taste in every Maduro that I have had that I just don't care for, including lots of leather." They seek recommendations that match precise parameters.

**Behavioral patterns observed:**
- Asks highly specific recommendation questions (wrapper preference + strength + excluding certain profiles)
- Discusses storage science (RH levels, dryboxing, temperature calibration)
- Tracks smoking experiences: "I'm about 8 months in and I've smoked around 50 different ones so far"
- Seeks "sleepers": underrated cigars that deliver disproportionate value
- Knows specific factories and blenders (AJ Fernandez, Nick Melillo, Litto Gomez)
- Discusses construction details: draw resistance, burn rate, wrapper integrity
- Engages in detailed Q&A about technique (retrohaling, draw pacing)
- Posts HAUL photos with commentary on what they're looking forward to trying

### Pain points

1. **Recommendation precision.** Generic "best cigars" lists are useless. Needs recommendations that account for what they've already tried and specifically dislike.
2. **Storage complexity.** Humidity management is a constant conversation: "Does storage and humidity correlate to draw?" They troubleshoot variables obsessively (RH, temperature, cigar rest time, dryboxing duration).
3. **Inconsistent cigar quality.** "The first 5 pack had 3 delicious cigars that had a perfect draw. Two of the 5 were loose and tasted like crap." Understands this is inherent to handmade products but still frustrating.
4. **App limitations.** They've tried every cigar app and found all of them inadequate:
   - Cigar Scanner: slow with large collections, inventory management is manual and unintuitive
   - My Humidor: missing vitolas, no way to track what was smoked vs. what was reviewed
   - Rating systems too coarse (5-star scale can't distinguish between an 8/10 and 8.5/10 cigar)
   - No app connects tasting notes to future recommendations
5. **Value assessment.** At this level they're spending real money ($10 to $30 per cigar) and want to avoid disappointment.

### Community language

- "I really like strong flavors and high nicotine, but there is just some kind of taste in every Maduro that I have had that I just don't care for"
- "Wasn't expecting so much flavor and complexity"
- "Find a sweet spot routine that works 99 out of 100 for that smoking experience you prefer"
- "I wouldn't call that a sleeper, it's pretty well known. You might just be out of the loop."
- "Prior Casdagli rep that knows the industry well. Makes very interesting blends with plenty of complexities."
- "The LFD Maduro Cabinet No.6 is my go to LFD"

### What they'd want from Vitolero

- **Precise matching.** "I like X but not Y" should produce meaningfully different recommendations than "I like X."
- **Deep cigar data.** Wrapper origin, blend details, aging potential, flavor evolution across thirds. This persona reads it.
- **Comprehensive database.** Missing cigars is a dealbreaker. Every app review complaint from this user type mentions database gaps.
- **Tasting note framework.** Not a blank text field. Structured input (flavor wheel, strength slider, thirds tracking) that feeds back into profile refinement.
- **Comparative information.** "How does this compare to what I usually smoke?" Context makes information actionable.

### Vitolero fit: Strong (with caveats)

This persona will be the most demanding and the most engaged. They'll stress-test the database and recommendation accuracy. If the recommendations are good, they become advocates. If the database has gaps, they leave.

---

## Persona 3: The Celebratory Occasional

**Tier: SECONDARY**

**Name:** Mark
**Age:** 38
**Location:** New York, USA
**Occupation:** Senior account executive

**Spend:** $60-160/year
**Frequency:** 4-8 cigars/year
**Collection:** None. No humidor.
**Primary need:** Confidence in the shop, occasion-based guidance

### Who they are

Mark smokes cigars at milestones. Birth of a child, promotion, retirement party, wedding. He might go months without picking one up and then reach for one on a meaningful day. He has no humidor. He's not intimidated by tobacco shops exactly, but he's intimidated enough to sometimes just point at something that looks expensive rather than ask for help.

This persona is largely event-driven. The cigar is a prop in a larger narrative. The community data consistently shows this: the most upvoted posts in r/cigars are almost exclusively celebration posts. This is where most people start with cigars, and for many it's where they stay.

### Why they smoke

Ritual, celebration, and identity. The cigar marks a moment. It's a physical object that anchors memory.

The most upvoted posts in r/cigars are almost exclusively celebration posts:
- "Celebrating my son's graduation with one of my favorite stogies" (15,887 upvotes, top post of all time)
- "Hard work pays off! Had my first Cohiba tonight!" (6,613 upvotes)
- "Today I retired from Ford Motor Co after 37.5 years" (2,821 upvotes)
- "Got Engaged. Smoked Cigars." (1,518 upvotes)

The cigar brand choice is a statement: Cohiba, Davidoff, Padron 1926, and Opus X are milestone markers. In Portuguese communities: "primeiro charuto" (first cigar) posts are common and warmly celebrated by the entire community.

### How they choose

By brand reputation and social proof. They know the "trophy" brands and reach for them on special occasions. For less significant occasions they rely on whatever looks good in the humidor or what the lounge recommends. Brand-loyal but not brand-deep. They know Cohiba is prestigious but may not know the difference between a Siglo II and a Siglo VI.

**Behavioral patterns observed:**
- "Are these real Cohibas?" posts are extremely common (2,794 upvotes for one). Authenticity anxiety is a core concern.
- Often asks "what should I bring to a celebration?" or "what's a good gift cigar under $50?"
- First lounge visit posts: excitement mixed with etiquette anxiety
- Gift-giving paralysis: the person others ask for cigar recommendations, which is uncomfortable
- The most upvoted "PSA for newbies" post (2,775 upvotes) was essentially a cigar lounge etiquette guide

### Pain points

1. **Authenticity anxiety.** "Are these real?" is the constant question. Spends premium prices and needs confidence in the genuine article. Fake Cuban cigars are endemic (beach sellers, tourist traps, questionable online vendors).
2. **Intimidated at the shop.** Walking into a B&M (brick-and-mortar) with 50+ options and no vocabulary to express preferences. One user described relying on saving cigar labels and showing them to shop staff to get similar ones.
3. **Can't justify the price gap.** Knows Cohiba costs 3x a Monte No. 4, but can't articulate why.
4. **Gift-giving paralysis.** Often the person others ask for cigar recommendations. Doesn't feel confident making those calls.
5. **Etiquette uncertainty.** Wants to look knowledgeable. First lounge visits generate genuine anxiety.

### Community language

- "Hard work pays off! Had my first Cohiba tonight!"
- "Celebrating [milestone] with [premium brand]"
- "Are these real?"
- "First time at a lounge, any tips?"
- "What's the hype about [premium brand]?"
- "My wife gave me permission"
- "Light one for [person] if you get the chance" (memorial smoking)
- PT: "primeiro charuto" (first cigar)

### What they'd want from Vitolero

- **Occasion-based recommendations.** "I'm celebrating a promotion, what should I smoke?" is a query this persona would actually make.
- **Confidence in the shop.** Quick access to information about whatever they're holding. Scan the band, get context. "This is a 2019 Padron Family Reserve, one of their most acclaimed blends."
- **Gift mode.** "My friend likes cigars, what should I buy for $50?"
- **Shareable moments.** If the app generates a clean summary of what they smoked, paired with what, and where, they'd share it.

### Vitolero fit: Strong (for specific use cases)

The occasion-based use case could drive adoption. The risk is infrequency: Celebratory Occasional users smoke 4-8 cigars a year, so unless the app gives them a reason to open it more often, retention is weak. Secondary tier is the right designation. Serve them well without over-designing for them.

---

## Persona 4: The Curious Newcomer

**Tier: SECONDARY**

**Name:** Tyler
**Age:** 28
**Location:** Lisbon, Portugal
**Occupation:** Junior product manager at a tech company

**Spend:** $100-300/year
**Frequency:** 1-2 cigars/month
**Collection:** None, or a few cigars in a plastic bag. No humidor yet.
**Primary need:** Guidance, low intimidation, simple first moves

### Who they are

Tyler is just getting started. He got his first cigar at a friend's wedding a few months ago, or crossed over from craft beer or whiskey culture and was curious. He smokes cigarettes occasionally but has no cigar vocabulary. He's digitally active, uses Reddit and Instagram, and is the kind of person who reads reviews before buying anything.

This persona often crosses over from adjacent cultures: craft beer, whiskey, coffee. They share a sensibility around quality, complexity, and ritual objects. The cigar appeals as an extension of that sensibility. They're explorers, not collectors yet.

In Portuguese-speaking communities (Clube do Charuto, 13K members), "primeiro charuto" (first cigar) posts are common and warmly celebrated. The community actively nurtures newcomers. There's no equivalent warmth in the US communities, which skew more expertise-forward.

### Why they smoke

Curiosity and occasion. The first cigar is almost always social or celebratory. Tyler doesn't yet have a stable "why" beyond trying something new. Testing whether cigars could become part of their life.

### How they choose

They don't choose. They ask. The decision process is fully outsourced to whoever is nearest: a shop clerk, a Reddit thread, a friend. Their posts follow a consistent pattern: buy something, photograph it, ask the community to validate or guide them.

**Behavioral patterns observed:**
- Posts photos of first purchases with "How'd I do?" framing
- Asks single-brand questions ("Would Montecristo No 4 be a good first choice?")
- Keeps handwritten notes or mental lists of recommendations
- Gravitates toward sampler packs and variety bundles
- Relies heavily on Cigar of the Month subscriptions for discovery
- Equipment anxiety is an early concern: "Qual cortador comprar?" (Which cutter to buy?), troubleshooting basics like "my cigar went out" or "it's bitter"

### Pain points

1. **Vocabulary gap.** No language to describe what they want. One user captured this in a post with 1,800 upvotes: "I can't name a single note, or discern a cheap cigar from a Cuban, but I enjoy the way a cigar makes me enjoy a moment." Top comment (160 upvotes): "Same boat. I know what I like, but I can't tell you what it is."
2. **Intimidation at the shop.** Walking into a B&M with 50+ options and no vocabulary to express preferences. Users describe relying on saving cigar labels to show shop staff.
3. **Information overload.** Cigar content online assumes baseline knowledge (wrapper types, ring gauge, vitola names). Newcomers bounce off this wall.
4. **Storage anxiety.** "How long does a cigar last not stored in a proper place?" is a recurring question. No humidor yet.
5. **Fear of wasting money.** Buying a premium cigar and not appreciating it, or buying a bad cigar and concluding all cigars taste like that.

### Community language

- "I have no idea what to expect from these new ones"
- "I'm a full time smoker and just getting into cigars recently. I've had a few before (don't know the names)"
- "How'd I do?"
- "Would this be a good first choice for someone who is new?"
- "I just put that one down in my notes to order next time"
- PT: "Pessoal, sou iniciante..." (Folks, I'm a beginner...)
- PT: "Podem me ajudar?" (Can you help me?)

### What they'd want from Vitolero

- **No vocabulary required.** Photo input is exactly right for this persona. They can show what they have rather than describe what they want.
- **Simple, confident output.** "Try this one" is better than a ranked list with flavor wheels. They need one clear recommendation, not five options with scores.
- **Education through action.** Don't teach them about wrappers up front. After they smoke a cigar and rate it, tell them: "You seem to prefer milder cigars with creamy notes. Here's why."
- **Zero judgment.** The app should never assume knowledge. No jargon in the interface.

### Vitolero fit: Strong

Validates the photo-first, minimal-friction approach. The biggest risk is overwhelming them with too much information in the output layer. Secondary tier is right: serve them with the same UX built for Weekend Ritualists. Lighter output depth, same input mechanics.

---

## Persona 5: The Lounge Social

**Tier: TERTIARY**

**Name:** Jerome
**Age:** 42
**Location:** Miami, Florida, USA
**Occupation:** Real estate investment manager

**Spend:** $1,500-4,500/year
**Frequency:** 1-3 cigars/week, primarily at lounges
**Collection:** Moderate personal collection, buys as needed
**Primary need:** Confidence in social settings, shareable moments, quick information lookup

### Who they are

Jerome smokes primarily at cigar lounges. The lounge is the product as much as the cigar. It's where he networks, has conversations, builds relationships. He's Instagram-active and posts cigar moments in social contexts. He has moderate cigar knowledge but is not obsessed with deepening it. He values the room, the company, and the status dimension of the ritual.

This persona is frequently a professional (finance, law, real estate, entrepreneurship) for whom cigars are part of a lifestyle image. The social dimension of smoking consistently outweighs the product dimension.

Status display varies by culture: luxury home setups in the US, organized brand events in Bulgaria, social gatherings in Brazil. In Bulgarian groups, the community actively resists pretension. A post joking "you look like villagers with cigars" earned the highest engagement, suggesting self-aware humor about cigar status.

### Why they smoke

Ritual, networking, and identity. Cigars signal something in certain social contexts. A lounge is a particular kind of room with particular social dynamics. Jerome values being part of that room. The cigar anchors the social ritual.

### How they choose

By what looks right in the context. Premium spirits pairing is consistent: Macallan, Pappy Van Winkle, Hennessy. What other people at the lounge are smoking matters. The tobacconist's recommendation matters. He wants to make a good choice without having studied for it.

**Behavioral patterns observed:**
- "First time at a lounge, any tips?" posts reveal genuine etiquette anxiety
- "Cigar Date Night Anyone?" frames the cigar as part of a social occasion
- Lounge and cigar room setup posts consistently earn high engagement
- Pairing with premium spirits features prominently
- Instagram-centric documentation of the experience

### Pain points

1. **Etiquette uncertainty.** Wants to appear knowledgeable without deep study. The most upvoted PSA for newbies (2,775 upvotes) was a cigar lounge etiquette guide. This anxiety doesn't disappear with experience.
2. **Can't justify the price gap.** Knows Cohiba costs more. Can't articulate why to others at the table.
3. **Social vocabulary gap.** Wants to describe what they're smoking beyond the brand name. "Notes of leather, earth and spice on the retrohale" reads like poetry to them but they'd like to be able to say something meaningful.
4. **Authenticity anxiety.** Similar to Celebratory Occasional. Spending premium prices and needing confidence in what they have.

### Community language

- "Cigar Date Night Anyone?"
- "First time at a lounge, any tips?"
- "Not too shabby"
- "Kid is asleep, wife is on a work trip"
- "What's the hype about [premium brand]?"
- "Are these real?"
- BG: Community actively resists pretension ("you look like villagers with cigars" got the highest engagement)

### What they'd want from Vitolero

- **Scan and get talking points.** Quick band scan that surfaces a sentence or two they can say about what they're holding. Not a lecture. Just enough to engage.
- **Shareable moments.** A clean share card that documents the experience. What they smoked, where, paired with what.
- **Pairing suggestions.** "I'm drinking Macallan 18. What should I order from this humidor?"
- **Authenticity confirmation.** Photo ID that confirms the cigar is genuine.

### Vitolero fit: Moderate

The Lounge Social benefits from Vitolero's core features without needing dedicated design for them. Share card functionality and quick band identification serve this persona directly. Design for Primary personas and this persona benefits automatically.

---

## Persona 6: The Collector-Connoisseur

**Tier: TERTIARY**

**Name:** Richard
**Age:** 58
**Location:** Sao Paulo, Brazil
**Occupation:** Retired logistics executive

**Spend:** $5,000-15,000+/year
**Frequency:** 5-7 cigars/week
**Collection:** Walk-in humidor, 500-2,000+ cigars. Buys from factories.
**Primary need:** Database accuracy, collection management at scale, aging tracking

### Who they are

Richard has been smoking for 20+ years. He has a walk-in humidor with 500+ cigars and has visited factories in Nicaragua and Cuba. He's a regular at his local lounge where he mentors newcomers. He currently tracks his collection in a spreadsheet after losing data on Cigar Scanner. He knows which factories produce which brands, which blenders have moved companies, and which tobacco crops from which years were exceptional.

This persona has arrived at the expert end of the ritual spectrum. The practice is decades-old, deeply ingrained, and highly structured. They're not looking to learn; they're looking for better tools to manage what they already know. The database is the product for them. Everything else is secondary.

### Why they smoke

Precision and novelty. They've smoked through the mainstream catalog and now seek the edges: limited editions, regional exclusives, aged stock, boutique blenders nobody else knows about. The thrill is finding something new that surprises a refined palate. Also ritual and tradition: the daily smoke is a fixed anchor in the day.

In Bulgarian groups, organized blind tasting events are a veteran-driven cultural phenomenon. Refined palate development is valued as a community activity, not just a solitary one.

### How they choose

By deep knowledge and informed experimentation. They know which factories produce which brands, which blenders have moved companies, and which tobacco crops from which years were exceptional. Their recommendations come with citations and context. They evaluate cigars with historical context: "The blend has been worse and worse as the years go on."

**Behavioral patterns observed:**
- Extensive collection management: "Once or twice a year I will export the list to a spreadsheet then go through my cooler and cross them off as I go"
- Separate genuine knowledge from hype: "One good rating and now it's an over-hyped monster"
- Guide newcomers with patience and specific, actionable advice
- Strong opinions on factory quality trends, brand consistency, and value propositions
- Detailed reviews with thirds analysis: "notes of earth, leather and spice on the retrohale with a medium full body"
- Aging as investment: specific box codes and production dates matter
- "Two hour plus smoke, and the profile becomes somewhat boring down the line"

### Pain points

1. **Collection management at scale.** No app handles 500+ cigars well. Cigar Scanner becomes "so slow that the OS asks to wait or quit." Most resort to spreadsheets.
2. **Database accuracy.** At this level, wrong information is worse than no information. They know when a database has the wrong vitola listed or the wrong wrapper attribution. "The database has (almost) everything... every vitola, of every line, of every mainstream brand" is the standard they're holding apps to.
3. **No aging tracking.** They buy boxes and age them for years. No app tracks purchase date, box code, aging time, and connects that to taste evolution.
4. **Data loss fear.** Multiple app users reported losing years of logged data. This drives veterans to manual tracking or spreadsheets they control.
5. **Platform risk.** Apple banned Cigar Scanner from the App Store for "promoting tobacco use." Collector-Connoisseurs are aware that any app-based system can disappear. Vitolero's PWA approach directly addresses this.
6. **Subscription pricing resistance.** Cigarwell launched at $129/year for 500+ cigars. Community response: "No thanks and hard pass. Buy cigars. Smoke cigars. Repeat. No data collection needed."
7. **The "Vivino gap."** Veterans who also drink wine know what Vivino delivers and are frustrated that no cigar equivalent exists. Community-driven ratings, friend activity, retailer integration, purchase history.

### Community language

- "Two hour plus smoke, and the profile becomes somewhat boring down the line"
- "Once or twice a year I will export the list to a spreadsheet then go through my cooler and cross them off"
- "The database has (almost) everything... every vitola, of every line, of every mainstream brand"
- "One good rating and now it's an over-hyped monster"
- "Initially it was a better more interesting smoke. I am guessing they ran out of that level of tobacco yet still make it."
- "Popular enough where if one is into the hobby, at some point one should try it, but not an essential"
- "No thanks and hard pass" (on Cigarwell pricing)

### What they'd want from Vitolero

- **Database depth and accuracy.** If Vitolero claims the largest database, veterans will test that claim immediately. Missing boutique brands or incorrect attributions will kill credibility.
- **Effortless collection management.** Photo-based cataloguing (scan and add) that doesn't feel like data entry.
- **Aging and history tracking.** When did I buy this? What box code? How long has it been aging? What did I think of the same cigar 2 years ago?
- **Community validation, not algorithm worship.** Veterans trust crowd consensus and personal recommendations over automated scores. "1,200 users rated this 4.2/5" carries more weight than "our AI recommends this."
- **Export and ownership.** They want to own their data. Export to CSV, no lock-in. This directly addresses the data loss fear.

### Vitolero fit: Moderate

Collector-Connoisseurs are the hardest to win and the hardest to keep. They will ruthlessly evaluate database quality and recommendation accuracy. However, if Vitolero's identification accuracy is strong, the photo-first approach offers something no other app does: scan a lounge's humidor and instantly know what's worth trying. That's a use case veterans currently solve by walking into the humidor and reading every band manually. Tertiary designation is right: serve them through database quality and data ownership features. Don't design primary flows for them in v1.

---

## Cross-persona insights

### What the research reveals across all personas

**1. The vocabulary gap is universal.** From newcomers ("I can't name a single note") to Weekend Ritualists ("Best I can do is creamy, sweet or strong") to Deepening Enthusiasts ("I know what I don't like but can't describe what I do like"), the inability to translate taste experience into words is the most consistent pain point across all six personas. Vitolero's photo-first approach sidesteps this entirely. This is the product's single biggest structural advantage.

**2. Trust in people over algorithms.** Every persona trusts community consensus and personal recommendations over automated scores. The shop clerk's suggestion, a friend's recommendation, or a Reddit thread with 50 upvotes carries more weight than any algorithm. Vitolero's recommendation engine should surface social proof alongside AI scores.

**3. The celebration cigar is the gateway.** Most people's entry point to cigars is a celebration (birth, graduation, wedding, promotion, retirement). The Celebratory Occasional persona is not a niche edge case. It's often the first chapter of every person's cigar story. The app's onboarding should recognize and welcome celebration-driven first-timers without making them feel like beginners forever.

**4. Existing apps fail at the extremes.** Apps work acceptably for the Deepening Enthusiast (the power user). They overwhelm Curious Newcomers and Celebratory Occasionals, and underwhelm Collector-Connoisseurs. Vitolero's opportunity is to be the first app that adapts its depth based on who's using it. This maps directly to the PRD's "sense and respond" principle (see strategy/prd.md).

**5. App fatigue is real.** Multiple users expressed resistance to tracking and inventory: "Wait, you think I want to do inventory on my cigars?" and "No data collection needed." Vitolero must deliver value on the first interaction (photo in, recommendation out) without requiring ongoing maintenance. Retention comes from usefulness, not from building a collection the user feels obligated to maintain.

**6. The "Vivino gap" is confirmed.** Wine has Vivino (70M users). Cigars have nothing equivalent. Every enthusiast who also drinks wine feels this absence. The opportunity is real, but the comparison sets high expectations. Vivino's key features that cigar users want: instant label scan, personalized recommendations, community ratings, friend activity, retailer integration, food and drink pairing.

**7. Culture shapes the experience more than knowledge level.** Facebook group research across 6 groups (English, Portuguese, Bulgarian) reveals that pairing culture, social norms, and community tone vary significantly by region. Brazilian groups are warmer to beginners. Bulgarian groups value organized tastings and resist pretension. US groups emphasize individual expertise. Vitolero's language-agnostic design must extend beyond translation to cultural adaptation of tone and defaults.

**8. Apple's App Store ban creates a PWA advantage.** Cigar Scanner was banned from the App Store for "promoting tobacco." Multiple apps struggle with iOS distribution. Vitolero's PWA approach (already chosen) is strategically sound. This should be communicated as a feature, not a limitation.

### Persona prioritization

**Primary: Weekend Ritualist + Deepening Enthusiast**

Design for these two. Facebook group observation suggests they represent 70-80% of the active, engaged cigar community. They smoke multiple times per week, they return to apps when the app earns it, and they have the social influence to bring others in. The Weekend Ritualist validates the photo-first, low-friction approach. The Deepening Enthusiast stress-tests the database and recommendation engine. If both are satisfied, the product has legs.

**Secondary: Celebratory Occasional + Curious Newcomer**

These are the acquisition funnel. They often arrive at the same moments: a celebration, a first purchase, a social occasion. The UX patterns built for Primary personas serve them well with lighter output. Don't design separate flows. Let the same interface adapt: Weekend Ritualist gets a recommendation with context, Curious Newcomer gets a recommendation with simple guidance, Celebratory Occasional gets a recommendation with confidence signals.

**Tertiary: Lounge Social + Collector-Connoisseur**

Served indirectly. The Lounge Social benefits from share card appeal and quick band lookup, both of which are natural byproducts of features designed for Primary personas. The Collector-Connoisseur benefits from database depth and data ownership features, which are infrastructure decisions rather than UX decisions. Neither requires dedicated primary flows in v1.

| Priority | Persona | Design rationale |
|---|---|---|
| **Primary** | Weekend Ritualist | Largest addressable audience. Core use cases (in-store rec, pairing). Low expectations for depth. High weekly frequency. |
| **Primary** | Deepening Enthusiast | Most engaged. Will stress-test and validate the product. Vocal advocates if satisfied. |
| **Secondary** | Celebratory Occasional | High-value use case (occasion recs). Infrequent usage. Served by Primary UX patterns. |
| **Secondary** | Curious Newcomer | Important for growth. Served by Primary UX patterns with lighter output depth. |
| **Tertiary** | Lounge Social | Benefits from share cards and quick lookup. No dedicated v1 flows needed. |
| **Tertiary** | Collector-Connoisseur | Hardest to satisfy. Win through database quality, not UX. Defer collection management at scale to later versions. |

---

## Appendix: app review insights

Key findings from cigar app store reviews relevant to Vitolero's positioning:

| App | Strengths | Weaknesses | Vitolero lesson |
|---|---|---|---|
| **Cigar Scanner** | Large database (13,000+ cigars), 90% identification accuracy, community ratings | Slow with large collections, banned from iOS App Store, manual inventory management, data loss incidents | Database size matters. PWA avoids App Store risk. Photo ID is the must-have feature. |
| **My Humidor** | Privacy-first (offline), simple, 4.9-star rating | Missing vitolas, no "smoked" vs "reviewed" distinction, no aging tracking | Simplicity wins for casual users. But power users need more. |
| **HUMI** | AI identification (7/8 correct in user test), modern UX | New, small community, premium paywall for core features | AI identification excites users. Free tier must include core value. |
| **Cigarista** | AI taste analysis ("What I Like" feature), personalized recs | Subscription required for unlimited identifications | Taste profiling from behavior is desired. Paywalling identification kills adoption. |
| **Cigarwell** | Closest to "CellarTracker for cigars," comprehensive tracking | $129/year pricing rejected by community, iOS restrictions | Price sensitivity is high. Enthusiasts resist paying for tracking tools. |
| **Vivino** (wine analog) | 70M users, instant label scan, community ratings, friend activity, food pairing, retailer integration | Premium paywall for advanced features, some users dislike algorithm bias | The gold standard. Vitolero should study Vivino's onboarding and social features closely. |

### Top unmet needs from app reviews (across all apps)

1. **Intelligent inventory management.** Smoking a cigar should auto-decrement the collection. Moving between lists should be automatic (wishlist to humidor when purchased).
2. **Recommendation engine.** No cigar app successfully recommends based on taste history. This is the single most requested feature.
3. **100-point rating scale.** 5-star scales are too coarse. Cigar publications use 100-point scales. Users want parity.
4. **Structured tasting notes.** Flavor wheels, strength sliders, thirds tracking. Not blank text fields.
5. **Aging tracking.** Purchase date, box code, aging duration. Connect to taste evolution over time.
6. **Local retail integration.** Where can I buy this cigar near me? At what price? Is it in stock?
7. **Export and data ownership.** Users want CSV exports and local backups. Trust in cloud-only storage is low.

---

*Research method: Online community mining (no interviews)*
*Sources: Reddit (r/cigars, r/cubancigars, r/CigarReview), Facebook groups (Cigar Lounge, Clube do Charuto, Bulgarian Cigars Club, The Cigar Group, Cigar family), App Store and Google Play reviews*
