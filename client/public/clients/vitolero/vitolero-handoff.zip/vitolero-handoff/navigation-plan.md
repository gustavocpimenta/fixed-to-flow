# Vitolero Navigation Pattern: Camera-Anywhere, Conditional Journal, Deferred Account

## Overview

The MVP navigation uses a **two-pip chrome**:
- `chrome-tr` (top-right): Journal `J` button
- `chrome-br` (bottom-right): Camera circular button

The pips are applied conditionally across the 5 MVP flows. The rules below govern exactly when each pip appears, when account creation surfaces, and why.

Three coupled questions drive the design:

1. **Camera reachability.** Must be one tap from anywhere except (a) the camera itself and (b) screens where the camera is the next obvious step (filter preview, identification result, sharing).
2. **Journal reachability.** Must be one tap from most screens, but not before the user has anything to journal about.
3. **Account creation.** Anonymous-first, non-blocking, surfaces only at a value moment (first Journal tap, per PRD §6.3).

Open questions Q1 and Q3 in wireframes/vitolero-flow-wireframes-open-questions.html address this; the rules below answer them for MVP.

---

## State / Affordance Matrix

| User state | Camera pip | Journal pip | Account prompt |
|---|---|---|---|
| **First open, camera live, zero captures** | Hide (you're in camera) | **Hide** | Hide |
| Permission prompt | Hide | Hide | Hide |
| Identifying / identification result | Hide (camera is implicit "next") | Hide if 0 prior; Show if ≥1 prior | Hide |
| Filter preview | Hide | Show if ≥1 prior identification | Hide |
| Share screen | Hide | Show if ≥1 prior identification | Hide (share is the goal) |
| Pairing | **Show** | Show if ≥1 prior identification | Hide |
| **Journal (first tap)** | Show | Hide (you're in it) | **Show** (Google sign-in sheet) |
| Journal (signed in) | Show | Hide | Hide |
| Returning user (last-photo state) | **Show** | Show | Show as banner only if not signed in |
| Inside camera from any state | Hide | Show if ≥1 prior identification | Hide |

**Unlock trigger for Journal pip:** the moment the auto-save fires after the **first successful identification**. From that point on, the pip is permanent. Per PRD §4.3, auto-save happens on every identification, so this trigger is well-defined and earned (the journal is non-empty when it appears).

**Unlock trigger for account creation:** unchanged. First tap on the Journal pip (PRD §6.3). Also surfaces as a soft banner on the Returning User last-photo state if the user has ≥3 photos and is still anonymous (loss-aversion framing).

---

## Pattern Catalog (Real Precedents)

### Camera-as-primary-action

1. **Snapchat:** camera is the home, no tab bar at all, navigation by horizontal swipe. Maximally aligned with "no menu, no chrome." Risky for non-Snapchat-native users; secondary destinations get buried.
2. **Shazam:** single giant FAB on home, secondary tabs visually subordinate. Works because the product has exactly one primary action, the same shape as Vitolero's Snap.
3. **Yuka:** center-tab Scan opens camera instantly. Conventional, fast, but always lands on a tab bar, not the camera.
4. **Vivino:** camera entry both as a center "Scan" tab and a top-bar icon on every screen. Redundancy aids discoverability but adds chrome.
5. **Google Lens:** camera as a persistent icon in the search bar across screens. Frames the camera as a tool, not the app.

### Progressive / unlock-as-you-go nav

6. **Seek (iNaturalist):** Observations/journal tab is hidden until the first successful identification. Strongest precedent for the Journal rule. Cost: some users never realise the tab exists.
7. **Duolingo:** full tab bar appears only after the first lesson; Leaderboard becomes meaningful only after a streak. Earned reveal.
8. **Counter-pattern: Pinterest, Spotify:** show the empty Library/Saved tab from day one with an aspirational empty state. Works when imagining your future collection is part of the value prop.

### Anonymous-first → account upsell

9. **TikTok:** fully anonymous browsing, account modal triggers at first social action (like, comment, follow). Bottom sheet, not a redirect.
10. **Duolingo:** "don't lose your progress" prompt at the first natural checkpoint, plus a Profile tab slot that visibly doubles as the upsell surface.
11. **Pinterest (2012-14 era):** ghost-profile tab in the bar signaling "this is where you'll be once you sign up." Honest about the conditional destination.
12. **Yuka:** full anonymous use; account prompt only when you need cross-device sync. The Profile tab is the upsell surface pre-signup.

### Synthesis for Vitolero

**Seek + Yuka + Snapchat.** Seek for the journal unlock rule, Yuka for the anonymous-by-default account upsell pattern, Snapchat for the no-chrome camera-as-home posture.

---

## Recommendation: Refine the Two-Pip Chrome with a Seek-Style Unlock

Keep the existing two-pip system. Apply three changes:

### 1. Hide the Journal pip until first identification

The pip is gated by a single boolean: `hasIdentifiedAtLeastOnce` (persisted in localStorage). On the very first session, the camera is fully clean: no `J` in the corner, no chrome at all. After identification 1 lands and auto-saves to local Journal, the `J` appears on every non-Journal screen with a subtle pulse for the first 3 appearances (Duolingo-style "earned reveal").

This fixes the contradiction in the wireframes at lines 1838, 1868 (first-time camera and permission states should have no Journal pip).

### 2. Make the Camera pip rule mechanical and consistent

The Camera pip appears on every screen **except**:
- The camera viewfinder itself
- Screens where the camera is the implicit next action: identifying, identification result, filter preview, share screen

Concretely, this means the Camera pip should be **added** to:
- Pairing screens (currently lines 2304, 2341, 2371 already show camera in TR; keep but consider moving to BR for consistency with the rest of the app)
- Journal screens (already correct: lines 2479, 2544, 2585)
- Returning user last-photo state (already correct: line 2655)

And **removed** from:
- First-time camera (line 1838, already correct: no camera pip on camera)
- Filter preview, share, identification result (currently show camera in BR; remove them. Camera is the implicit "go again" via a "Snap another" CTA at end of share, not a corner pip while you're mid-flow)

### 3. Keep account creation deferred and contextual

Unchanged from PRD §6.3:
- First Journal tap → Google sign-in bottom sheet (not a full screen redirect, TikTok-style)
- After 3 identifications without sign-in, add a soft, dismissible banner on the Returning User last-photo state: "Sign in to keep your journal across devices." Loss-aversion framing, never blocks the flow.
- No "Profile" tab in MVP. The post-MVP four-tab model in the open-questions doc already plans for this.

### Why this synthesis works

- **Honest:** the journal only appears when there is something in it. Seek's logic.
- **Earned:** the user has experienced the value loop (snap, identify, save) before being asked to commit to anything.
- **Reversible:** the boolean is a local-storage flag; the layout doesn't depend on it structurally. Easy to A/B later.
- **Consistent with the concept's "no menu, no tabs, no chrome" stance** (see strategy/concept.md): chrome is added only where the user has earned it.
- **Answers Q1 and Q3** in the open-questions wireframe with a concrete rule, not a four-tab future.

---

## Alternative Considered

**Snapchat-style edge-swipe (no pips, swipe left for Journal, no Journal in MVP).** More radical, more "AI-native," fewer pixels of chrome. Rejected for MVP because:
- Dave (the MVP-primary persona) is a 50+ weekend ritualist. Edge-swipe is gesture-heavy and discoverability-poor for non-power-users.
- Pairing already needs an explicit way back to camera; with no pip and no swipe affordance shown, this gets confusing fast.
- Worth keeping as a Phase 2 candidate after the MVP validates the loop.

---

## Decisions

- **Journal unlock trigger:** first successful identification (auto-save fires → pip appears, same session). Seek pattern.

---

## Files to Update

| File | Change |
|---|---|
| `wireframes/vitolero-flow-wireframes.html` | Remove `J` pip from first-time camera screens (~lines 1838, 1868). Remove camera pip (BR) from filter preview and share screens, as camera is the implicit next action there. Annotate each flow's first identification step with "Journal pip unlocks here." |
| `wireframes/vitolero-flow-wireframes.html` | Add a "Navigation rules" callout near the top of the page (above the 5 flows) summarising the State/Affordance matrix. |
| `wireframes/vitolero-flow-wireframes-open-questions.html` | Mark Q1 Navigation and Q3 Mode Switch as **resolved for MVP** with a one-paragraph summary pointing back to the main wireframe page. Keep the four-tab Phase 2 model preserved as-is. |
| `strategy/concept.md` | Update the navigation paragraph (~line 180) to add the Journal-pip unlock rule and the Camera-pip rule. |

**Deferred to a later pass (not this round):** `strategy/prd.md` §4.3 / §6.3 rule additions.

---

## Verification Checklist

1. Open `wireframes/vitolero-flow-wireframes.html` in the browser. For each of the 5 flows, walk through the screens and confirm:
   - First-time flow: zero pips on the camera; no `J` until after the identification result auto-saves.
   - Snap & Share Hero: camera pip absent during filter/share; Journal pip starts appearing only post-identification 1 (annotate this).
   - Pairing: both pips present.
   - Journal: camera pip present; no Journal pip (you're in it).
   - Returning User: both pips present, plus the "≥3 captures, anonymous" banner annotation.
2. Open `wireframes/vitolero-flow-wireframes-open-questions.html`. Confirm Q1 and Q3 are marked resolved with a link back.
3. Spot-check `strategy/concept.md` for the new rules.
4. Cross-check that the Phase 2 four-tab model is still preserved in the open-questions doc as a future direction.

---

*Patterns referenced: Snapchat, Shazam, Yuka, Vivino, Google Lens, Seek, Duolingo, Pinterest, TikTok. Closest synthesis: Seek + Yuka + Snapchat.*
