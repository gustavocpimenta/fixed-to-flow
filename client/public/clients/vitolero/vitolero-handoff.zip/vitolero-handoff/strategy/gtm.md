# Vitolero: Go-to-Market Strategy

---

## 1. The Distribution Problem

Vitolero operates in one of the hardest distribution environments in consumer software.

- EU Tobacco Products Directive (EUTPD2) bans tobacco advertising across the bloc
- Facebook, Google, and Apple all block tobacco-related paid ads
- Apple removed Cigar Scanner from the App Store. The same risk applies to any native cigar app
- VC won't fund "sin industries" at pre-seed without substantial traction proof
- The PWA choice sidesteps App Store removal risk, but PWAs have no discovery channel of their own

The result: zero access to traditional paid acquisition. No ads, no app store ranking, no influencer sponsorships through major platforms. This is not a budget problem. It is a structural problem that money cannot solve.

The GTM strategy has to work around every one of these constraints simultaneously.

---

## 2. The Insight: Every Photo Is Marketing

Cigar communities already share millions of photos on social media every week.

Instagram alone has millions of posts under #cigarlife, #BOTL, #cigars, and #cigarsofinstagram. Facebook groups, Reddit, WhatsApp groups, Discord servers, and dedicated cigar forums all show the same pattern. The same question appears under almost every cigar photo: "What are you smoking?" It is the universal conversation opener. People want to know the brand, the origin, the flavor profile. And the person posting often does not know the full answer either.

This behavior is not confined to one platform. It happens wherever cigar enthusiasts gather. And every major platform (Instagram, Facebook, TikTok, X) bans paid tobacco advertising. This is not just a constraint. It is a structural advantage. No competitor can outspend Vitolero on paid acquisition because paid acquisition does not exist for tobacco products. The only viable growth model is organic. The share card flywheel is the only model that works.

Vitolero makes those photos better. The product locks in a specific mechanic: a cigar-specific photo filter (desaturate the background, keep the cigar saturated so it pops) plus an automatic brand-and-line identification overlay composited on the photo. The filter is what makes the photo worth sharing. The brand-and-line overlay is what makes the share credible. Together they answer "what are you smoking?" before anyone asks it.

Every shared photo carries the Vitolero overlay and, where the platform shows it, the domain. Instagram and WhatsApp receive the image file directly via Web Share API. Facebook receives a deep link (the Facebook API is unavailable due to tobacco restrictions); even so, the image itself carries Vitolero's visual signature.

The product is the marketing. Users distribute Vitolero because they want to share better cigar content, not because they are doing Vitolero a favor.

**MVP launch geography:** middle-aged US users who smoke alone and share photos individually. Other regions are served post-MVP (language-agnostic content and regional pairing defaults are deferred to a later release). This focus makes the Facebook-group admin partnership model tractable in one cultural context first.

---

## 3. The Growth Flywheel

**Growth is the only goal for v1.** Monetization and data flywheels are secondary concerns. The singular focus is getting users in, getting them to snap, and getting the share loop spinning. Everything else follows from growth.

### Two-Speed Flywheel

The growth engine has a fast front wheel and a slow back wheel.

**Front wheel (MVP, high-speed, everyone passes through):** Photo filter + brand-and-line identification + share. Every snap delivers a share-worthy artifact (the filtered, branded photo). The share prompt is the primary action after identification. This front wheel must be perfect because every user passes through it. Share-worthiness comes from the filter, not from a personalized recommendation unlock.

**Back wheel (post-MVP, retention, users branch out):** Journal (in MVP, as the photo collection surface), and then post-MVP, the Signature Taste Profile, discovery feed, and recommendations. Journal data collected in MVP is shaped to feed the taste profile when it ships, so the post-MVP retention engine starts with a warmed cold-start. Once the taste profile engine ships, the switching cost begins accruing (more data in the profile = harder to leave).

### The Distribution Loop

1. User photographs a cigar
2. A cigar-specific filter is applied automatically (with alternatives one tap away)
3. Brand and line are identified and composited as an overlay on the filtered photo
4. App prompts: "Share to Facebook" (primary action); Pair, Save, and Retake visible as secondary actions
5. User shares the filtered, branded photo to Facebook (deep link) or to other platforms via Web Share API
6. Friends see a photo that looks better than typical cigar content, with brand and line clearly labeled
7. Someone asks what filter/app it is, or curiosity drives a search for Vitolero
8. New user opens Vitolero, snaps their next cigar
9. Loop repeats

Each user becomes a distribution channel. The filter quality plus the overlay polish is what drives sharing motivation. If the filter makes the photo look genuinely good, sharing is self-motivated. If the filter is generic or the overlay looks cheap, people will skip the app and share directly from their camera roll.

The key structural advantage: users are sharing for themselves. The marketing is a byproduct of a behavior they already do.

**Open hypothesis:** filters alone may not be enough value if users do not care about photo quality. The counter-argument is that Instagram succeeded on effortless enhancement. The MVP launch is effectively a test of this hypothesis. Track share rate on filtered photos vs. share rate on raw phone photos; if filtered share rate is not meaningfully higher, the anchor value proposition needs a rethink.

---

## 4. Community Infiltration Strategy

The entry point is the communities where cigar conversation already happens. The channel landscape is broader than Facebook and Reddit. Each platform serves a different role in the acquisition funnel.

### Tier 1: High-Volume Photo Sharing

**Instagram (primary share card channel):**
Instagram is the dominant platform for cigar photo sharing. Key community hashtags include #cigarlife, #BOTL (Brothers of the Leaf), #SOTL (Sisters of the Leaf), #cigarsofinstagram, #nowsmoking, #cigaroftheday, and #cigarporn. Top cigar influencers reach 100K-210K followers. The share card format is native to Instagram. Users share image files directly via Web Share API, bypassing link preview restrictions. Instagram's ban on paid tobacco promotion means all cigar content is organic. This favors quality share cards over ad spend.

**Facebook groups (primary MVP channel):**
- Cigar Lounge
- Clube do Charuto
- Bulgarian Cigars Club
- The Cigar Group
- And other US-facing groups identified as launch targets

**Admin partnership model.** Facebook cigar groups are the primary distribution channel for MVP launch. The approach is partnership, not broadcast: identify the admins and moderators of the target groups, involve them as advisors, position them as part of the creative process, and potentially pay them to promote the app inside their communities.

**Timing gate (absolute).** Admin outreach begins only once the MVP is working. The first impression is one-shot. If admins try the app and it is broken, incomplete, or unpolished, the relationship is harder to rebuild than it was to start. Launch MVP as soon as possible after design sign-off, then begin admin outreach.

**Community research remains valid.** The groups and their norms documented in this section are the target. The MVP narrows to US-based users, which means the English-language and Spanish-language groups come first. Clube do Charuto (Portuguese, Brazil-heavy) and Bulgarian Cigars Club remain relevant for post-MVP expansion.

**Reddit:**
- r/cigars (240k+ members)
- r/cubancigars
- r/CigarReview

### Tier 2: Credibility and Influence

**YouTube (credibility channel):**
Top cigar YouTube creators are independent and reachable: Cigars Daily (~170K subscribers), Cigar Vixen (~100K), The Cigar Authority (~90K), halfwheel (~53K), Cigar Dojo (~54K). A product demo or early-access invite from one mid-tier channel delivers concentrated, high-intent reach. YouTube's Data API v3 is also a legitimate source for mining cigar names, brand mentions, and flavor language from video descriptions and comments. The goal is a genuine mention from a creator who finds the product useful.

**Cigar forums (high-trust seeding):**
BOTL.org, CigarPass, and Friends of el Habano (FOH) are the oldest and most trusted cigar communities online. Member populations are small (low tens of thousands each) and declining, but these users are heavy smokers with strong brand opinions, deep spend, and outsized influence. They map directly to the Carlos and Dave personas. A positive mention on BOTL or FOH carries credibility weight that Instagram cannot replicate. These forums are where early adopter seeding is highest-leverage.

**halfwheel and Cigar Aficionado (editorial credibility):**
halfwheel is the industry's most respected independent review site. Cigar Aficionado maintains a database of 23,000+ reviewed cigars. Neither offers user-generated content at scale, but both are credibility anchors. Getting a mention in halfwheel editorial or aligning Vitolero's identified cigars with their ratings signals quality to the enthusiast audience.

### Tier 3: Emerging Channels

**Discord (bot distribution opportunity):**
The Cigar Page Discord server has ~9,700 members. Several smaller servers exist (The Mancave Cigar Lounge, International Tobacco Community). Discord's Bot API is well-supported. A Vitolero bot that responds to cigar photos with identification and share cards would be genuinely useful to these communities, not marketing. This is technically feasible and represents an underexplored distribution surface.

**TikTok (awareness and discovery):**
The #cigar tag has hundreds of millions of views. #cigartok is a growing subcommunity. Top cigar TikTok influencers have 100K-145K followers (cigarpassion_klodian, dreamercigars, maduroaficionado.cigars). The audience skews younger and newer to cigars. The video-first format limits share card utility, but short demos of the snap-and-identify flow are naturally compelling content. TikTok is a discovery channel, not a retention channel.

**Twitter/X (brand signaling):**
Active but small cigar community. Cigar media outlets (halfwheel, Cigar Aficionado, Tobacconist University) maintain presences. Key hashtags: #cigar, #BOTL, #nowsmoking, #habanos. Useful for brand awareness signaling and industry conversation, not for photo-sharing flywheel.

### Competitive Landscape

Two existing apps validate the market without threatening the position:

- **Cigar Dojo / Dojoverse:** Self-described as the world's largest social cigar app, active since 2012. Gamification-oriented (belts, badges, Cigar Wars). Identification relies on manual search, not image recognition. No share card output. The fact that Dojo has existed for 14 years without dominating the market suggests the audience supports multiple tools but does not coalesce around one.
- **Cigar Scanner:** Photo-to-identification flow similar to Vitolero's core mechanic. Database lookup rather than AI-powered recognition. Social features exist but are basic. No share output.

Vitolero's differentiation is the combination of AI identification, contextual recommendation, and the share card as distribution mechanism. Neither competitor has this combination.

### Promotion Ban Reality

Most Facebook cigar groups ban promotions. The threshold varies across groups: some will trigger alarms, others will not. Share cards must fly below the radar as much as meaningfully possible. In the beginning, navigating the Facebook community landscape requires someone who knows the territory: an expert to identify which groups tolerate organic product content and which will flag it immediately.

The share card's strength is that it looks like organic content (a cigar enthusiast sharing their smoke), not like an app advertisement. But this only works if the card design is genuinely premium and the sharing behavior feels natural. Any hint of orchestrated promotion will backfire.

### Channel Prioritization

**Instagram is the primary channel.** It is where cigar photo-sharing behavior already lives at scale. Key community hashtags (#cigarlife, #BOTL, #SOTL, #cigarsofinstagram, #nowsmoking, #cigaroftheday) reach massive audiences. Top cigar influencers reach 100K-210K followers. The Web Share API image approach bypasses link preview restrictions entirely. Instagram's ban on paid tobacco promotion means all cigar content is organic. This favors quality share cards over ad spend.

**Tobacco ad bans across all platforms are a structural advantage.** Instagram, TikTok, and X all ban paid tobacco promotion. Vitolero's organic share-card model is the only legal growth model. Competitors cannot outspend Vitolero on paid acquisition because paid acquisition does not exist for tobacco products.

**Discord bot as distribution surface.** The Cigar Page Discord server (approximately 9,700 members) and other cigar Discord communities are underexplored. A Vitolero bot that responds to cigar photos with identification and share cards would be genuinely useful. Discord's Bot API is well-supported. Technically feasible and high-value for community integration.

**YouTube is the credibility unlock.** Top cigar YouTube creators are independent and reachable: Cigars Daily (approximately 170K subscribers), Cigar Vixen (approximately 100K), The Cigar Authority (approximately 90K), halfwheel (approximately 53K), Cigar Dojo (approximately 54K). A product demo or early-access invite from one mid-tier channel delivers concentrated, high-intent reach. The goal is a genuine mention from a creator who finds the product useful.

**Research TODO:** Additional social networks need investigation: WhatsApp cigar groups, Telegram cigar communities, TikTok #cigartok subcommunity (deeper analysis), Bluesky/Threads, and regional platforms (VK for Eastern Europe, WeChat for China).

### Community Approach

The approach is to become a credible member of each community, not to announce the product. Share cards that answer "what are you smoking?" are high-value content in these spaces. They are informative, well-formatted, and contribute to the conversation.

The community language matters. "BOTL" (Brothers of the Leaf) and "SOTL" (Sisters of the Leaf) are trust signals across Instagram, forums, and X. Using them naturally (not in branding) signals genuine membership. This is a credibility marker, not a marketing tactic.

**Competitive context.** Cigar Dojo has existed since 2012 without dominating the market. Users tolerate gamification friction (belts, badges, Cigar Wars) because nothing better exists. This validates the market without threatening Vitolero's position. The combination of AI identification + share card output is a genuine step change that no existing competitor offers.

Early adopters who post Vitolero share cards in these groups become credibility anchors. When someone asks what tool they used, they answer from genuine enthusiasm rather than promotion.

Content strategy to support community presence:
- Occasion-based guides: "5 best cigars for a new dad," "What to smoke on a long flight"
- Beginner-friendly content: "How to read a cigar label," "Wrapper colors explained"
- Pairing guides: cigars with whisky, with coffee, with specific occasions

No banners. No CTAs. No "download our app" language. The domain does the attribution work passively.

---

## 5. Launch Model: Free First

All features launch free, with no limitations.

The reasoning is straightforward. Before deciding what to charge, it is necessary to understand what users actually value. A paywall at launch would suppress the data needed to make that decision well.

What to watch during the free period:
- Which features drive return visits (snap frequency is the signal)
- What creates switching costs (the taste profile is the primary candidate)
- Where users drop off in the experience
- Which personas are more active and more retentive

The taste profile is the natural switching cost. A user who has logged 30+ cigars has a recommendation engine that knows their palate. That data does not transfer. The longer they use the product, the more expensive it becomes to leave.

When pricing is ready, start low. The $2.99 to $4.99 per month range minimizes friction and positions the product as an obvious purchase for anyone spending $800+ per year on cigars.

Premium candidates to evaluate based on usage data:
- Advanced palate analytics
- Drink pairing recommendations
- Collection export
- Priority identification speed
- Rare or vintage cigar database access

---

## 6. Post-MVP Product Roadmap

The product roadmap beyond MVP has three phases.

**Phase 2: recommendations.** Once the MVP is live, Journal data becomes the training substrate for the Signature Taste Profile and personalized recommendations. Shipping target: weeks after MVP, not months, because the Journal schema is shaped to support this from day one.

**Phase 3: advanced pairing.** Multiple cigars in one photo, social-context pairings (occasion-based, lounge settings), bi-directional and menu-aware pairings all land here. These unlock the full pairing surface that was out of scope for MVP.

**Phase 4: dedicated cigar social network.** The long-term product bet. Platforms like Facebook and Instagram are increasingly restricting tobacco-related content; the structural answer is to own the social surface. This phase requires $500K to $1M in funding because of US legal requirements around tobacco-adjacent platforms (content moderation, age verification, compliance infrastructure). The Journal, the user identity model, and the photo data architecture should all be designed with this phase in mind even during MVP build.

The roadmap is deliberately sequenced. Recommendations before advanced pairing, advanced pairing before social network. Each phase resolves a specific retention or engagement bottleneck of the one before it.

---

## 7. Data Flywheel

Every snap generates a labeled training pair: image + cigar_id.

Users build the ML training dataset through normal usage, at zero marginal cost. The manual identification workflow in v1 produces the training corpus.

After 10,000+ labeled snaps, there is a substantial foundation for automated band recognition in Phase 2. The transition from manual to automated identification becomes possible precisely because of the usage that preceded it.

The recommendation engine compounds the same way. Community ratings, tasting notes, and snap frequency data build a preference graph. More users produce more signal. Better signal produces better recommendations. Better recommendations retain users. The loop tightens over time.

Photo import accelerates this flywheel. Users who import existing cigar photos from their camera roll build a taste profile in minutes instead of weeks. Every imported photo also generates a labeled training pair, compressing the time to reach the 10,000-snap threshold for automated recognition. The cold-start problem disappears for users who already have a cigar photo history.

This is not a moat that can be bought. It accrues through use.

---

## 8. Metrics That Matter

| Metric | Definition | Target |
|---|---|---|
| Share rate | % of snaps that get shared | 40%+ |
| Viral coefficient | New users per share (1 in 10 viewers converts = 0.1) | 0.1+ |
| Snap frequency | Snaps per active user per week | Dave: 2-4 / Carlos: 3-5 |
| Profile depth | Cigars logged per user | Retention trigger at 10+, lock-in at 30+ |
| Community penetration | % of active community members using Vitolero | Track per group/server/forum |

Share rate and viral coefficient determine whether the flywheel is spinning. Snap frequency and profile depth determine whether it is sustainable. Community penetration shows whether the primary acquisition channel is working.

These five numbers tell the full story at this stage.

---

## 9. Risks and Mitigations

**Facebook restricts link previews from cigar-related domains**
The share card travels as an image file via Web Share API for Instagram and WhatsApp. Domain dependency is limited to Facebook link previews. Worst case: Facebook reach is reduced, other channels still work. Monitor early and adapt card format if needed.

**Low share rate if the card design is not compelling enough**
This is the highest-probability risk and the most controllable one. Card design should be treated as a product priority, not a finishing touch. Test multiple formats in the community during soft launch. Iterate based on what people actually share.

**Manual ID friction in Phase 1 deters casual users**
Provide a clear fuzzy search fallback. Allow "I don't know" as a valid answer that still generates a partial share card. Users should be able to share a photo even if identification is incomplete. Remove every point of friction between snap and share.

**Community rejects what reads as marketing**
No CTAs. No "download our app" copy anywhere near community content. The landing pages should be clean, informational, and fast. Let the domain carry the attribution. The moment a share card reads like an advertisement, the community will treat it like one.

**Instagram deprioritizes static image posts in favor of Reels**
The algorithm increasingly rewards video content. If static share cards lose organic reach, adapt the format: short video share cards (3-5 second animated reveals of cigar details), Reels-optimized templates, or story-format cards. The share card concept is format-agnostic. What matters is the content (cigar identification + beautiful presentation), not whether it is a static image or a short video.

**Platform tobacco content moderation tightens further**
Any single platform could restrict organic cigar content at any time. The multi-channel strategy (Instagram, Facebook, Reddit, Discord, forums, YouTube, TikTok, WhatsApp) provides resilience. The PWA model means Vitolero does not depend on any app store. Direct traffic via bookmarked PWA is the ultimate fallback. Diversification across channels is insurance, not optimization.
