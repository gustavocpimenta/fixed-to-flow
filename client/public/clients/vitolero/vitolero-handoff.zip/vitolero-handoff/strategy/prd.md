# Vitolero: Product Requirements Document

---

## 1. Product Vision

**One-liner:** The AI cigar companion that makes every cigar you smoke shareable.

Vitolero strips the product back to a single loop: photograph a cigar, get it identified instantly with a cigar-specific filter applied, and share it to social media in a way that looks magazine-quality. That share card carries the Vitolero domain into every Facebook group and Instagram feed where cigar photos travel. Over time, the Journal accumulates a personal photo history that powers the next phase of the product: taste-based recommendations.

The longer game is a dedicated social network for cigar enthusiasts. Facebook and Instagram increasingly restrict tobacco content. The communities that live there have no native home. Vitolero builds that home, starting with a distribution mechanism (the share card) that gets users in the door before the social layer exists.

---

## 2. Problem Statement

- **Choice paralysis.** Cigar smokers face 50+ options in any shop and no reliable way to choose beyond gut feeling or a shopkeeper's hit-or-miss suggestion.
- **Quality gap in cigar photography.** Most user-generated cigar photos are poorly composed and lack context. Users want to showcase the brand but their photos do not reflect the quality of what they are smoking. A well-formatted, filtered share card with brand and flavor info closes this gap with no skill required from the user.
- **Tobacco platform squeeze.** Meta, Google, and TikTok all restrict tobacco-related paid advertising and, increasingly, organic reach. Cigar communities have no native social platform. Their content is tolerated on existing platforms, not built for them.
- **Vocabulary gap.** "What are you smoking?" is the universal opener in every cigar community. Most users cannot answer it precisely. They know the brand, sometimes the line, rarely anything else. Instant identification with a tap closes that gap and makes every user look more knowledgeable than they are.

---

## 3. Target User (MVP)

**Dave the Weekend Ritualist** is the MVP target. Dave is approximately 47 years old, based in the US (Austin, New York, and similar metros), and smokes 2 to 4 cigars per week. He has been smoking for 3 to 5 years. He has a desktop humidor with 15 to 40 cigars. He already photographs his cigars and shares them to Facebook. He does not know the flavor profile or origin of most of what he smokes in sufficient detail to answer "what are you smoking?" confidently. He will use the app if it makes his existing photo-sharing habit better with minimal extra effort. He will not use it if it asks him to learn something or fill out forms.

Dave smokes alone most of the time. His share behavior is individual: one photo, one platform, usually Facebook. He is the growth engine because he reaches the groups where Vitolero needs to be discovered.

**Carlos, Mark, Tyler, Jerome, and Richard** are research-validated personas served post-MVP. See `research/personas.md` for full profiles. Carlos (Deepening Enthusiast) is the most likely early adopter beyond Dave and will encounter the product through Facebook groups even in the MVP window. Identification accuracy on well-known cigars must be production-grade at launch because Carlos will test it publicly.

---

## 4. MVP Scope

### 4.1 Snap and Share

The hero feature. Every interaction in the app starts here.

**Welcome screen (first open only):**

- One screen appears before the system camera permission dialog on first open.
- Content: app identity (logo + name) + three short statements that set expectations + a single CTA ("Get Started") that triggers the camera permission request. The three statements are: (1) Snap any cigar for instant ID and a magazine-quality share card; (2) Ask for a pairing: food and drink that match what you're smoking; (3) Everything you snap saves to your Journal.
- One-time only. Never shown again after the first session.
- Purpose: prevents the system permission dialog from appearing with no context immediately after install.

**Photo capture:**

- Camera as the default state on app open (after welcome/permission on first session).
- Gallery import also supported for users who want to use an existing photo.
- Camera flip supported: user can take a selfie-style photo with a cigar or point the camera at one.
- Flexible aspect ratio handling: photos arriving from the gallery may not be square. The app handles portrait, landscape, and square without cropping the subject.
- Photos with people are allowed. The identification pipeline focuses on the cigar in frame regardless of other subjects.

**Filter pipeline:**

- Exactly 3 cigar-specific filters developed with a photographer contractor.
- Core filter effect: soft peripheral blur (bokeh) to isolate the cigar visually, keeping it sharp while the background softens.
- Automatic brand and line overlay composited onto the photo as a visual element (not a caption).
- The overlay is a semi-transparent strip at the bottom of the image carrying: brand logo, brand name, line, subtle Vitolero mark. It should look like something from a cigar magazine, not a screenshot from an app.
- Overlay is on by default. User can remove it by tapping the image (toggles off).
- Filter selection: user picks from the 3 available overlays before sharing.
- The original photo is always preserved; the filtered version is the shareable artifact.

**Brand and line identification pipeline:**

- Three identification levels: brand, line, and specific size (vitola). Brand and line surface quickly (under 10 seconds). Specific size may load slightly later and surfaces in the Cigar Detail screen (§4.4).
- For quick sharing, brand and line are sufficient for 90%+ of users.
- Confidence threshold: 80% minimum for a result to surface.
- Candidates: up to 3 per cigar when confidence is below threshold or the result is ambiguous.
- Latency target: under 10 seconds from photo capture to identification result (brand and line).
- Accuracy on well-known cigars must be high at launch. This is reputation-critical because Carlos-type users will test it in Facebook groups and post results publicly.

**Cancel during identification:**

- A visible cancel action is available on the processing/sommelier screen.
- Tapping cancel returns the user to the camera to retake or abandon the session.
- This handles the case where the user photographed the wrong cigar or wants to start over.

**Share composition:**

- Photo with auto overlay (brand name, line, subtle Vitolero mark) composited directly onto the image.
- The composited image is the shareable artifact, not a link preview.

**Share handoff:**

- Facebook: deep link via sharer.php. The Vitolero domain is visible under the preview. No Facebook API (tobacco restriction).
- All other platforms (Instagram, WhatsApp, etc.): image file shared directly via Web Share API. No link, no domain exposure, just the image.
- One platform at a time. No simultaneous multi-platform share.
- After sharing, the user leaves the app. Reacquisition is an open problem (see Section 12).

**Local storage:**

- Photos persist locally before account creation.
- Local storage is not 100% reliable across all devices. Account creation (triggered by Journal) is the durable storage path.

**Returning user behavior:**

- On reopen, the app displays the last photo taken with action buttons available.
- The camera view only appears on a fresh first open, not on every return visit.

---

### 4.2 Pairing

Pairing is a separate journey from filters and overlays: photo quality is irrelevant once identification has happened, and the user does not need to re-photograph to access pairing.

**Input:**

- Cigar line, derived from the identification result or entered manually by the user.

**Output:**

- Exactly 6 items in two groups.
- Food: 3 options categorized as snack, meal, and dessert.
- Drink: 3 options categorized as hard liquor or wine, cocktail, and coffee or tea.
- Latency target: 10 to 15 seconds.

**Screen layout:**

- Split-panel presentation: a large vertical cigar (~80 to 90% of screen height, recognizable by the band) sits on the left; the 6-item pairing list sits beside it on the right. The cigar carries its name and a one-line flavour note.
- Each suggestion shows only the item name. No per-item category tags (Snack, Meal, Dessert / Liquor, Cocktail, Coffee) and no food or drink icons. The Food and Drink group dividers are present but visually de-emphasized.
- Exactly one suggestion across the whole result is highlighted as the featured pairing (star + label). One featured per result, not per group.
- The pairing screen is not a dead end. Forward actions are always visible: "New Snap" (camera) and "Journal" so the user can continue without friction.

**Text-only display (rationale):**

- Pairings render as text only, not as images.
- Reasons: (1) speed: no image fetch within the 10 to 15s latency budget; (2) no licensing or AI-image-quality risk on food and drink imagery; (3) the visual budget for the product is already spent on the share card and filtered photo, which is the differentiator; (4) Dave reads the pairing for the answer, not for visual delight.
- Future option (post-MVP): small flat category icons (🥃 ☕ 🍫) if the pairing screen becomes a destination on its own. Not in MVP.

**Directionality:**

- One-directional only: cigar to food and drink. No reverse direction (drink to cigar) in MVP.

**Edge case: multiple cigars in photo:**

- The pairing feature requires a single cigar as input. If the photo contains multiple cigars, prompt the user to select one or retake with one cigar in frame.
- This is the MVP handling. Scale-level solutions are a post-MVP problem (see Section 12).

---

### 4.3 Journal

A persistent, visual gallery of the user's cigar photos. This is where the product becomes personal.

**Entry point:**

- Journal is visible in the app from the start, but accessing it triggers account creation.
- Account creation trigger: first attempt to open the Journal.
- Social login: Google or Apple ID at launch. One-tap, no email/password form. Both options presented at the sign-in sheet.

**Gallery design:**

- Pinterest-style masonry layout.
- Each entry shows the filtered photo and a cigar card with product information.
- Cigar card (product information) and user photos are related but distinct concepts. A user might have multiple photos of the same cigar line. The card is stable; the photos are personal.

**Functionality:**

- Favorites: user can mark entries.
- Collection views: open design question whether multiple view options (by brand, by date, by rating) are needed at launch or post-MVP.

**Schema note:**

- Journal data should be structured from day one to support future recommendations. No recommendation UI in MVP, no recommendation logic in MVP. Just a schema that does not require a rebuild when recommendations ship. Recommendations can arrive weeks after MVP rather than months if the data shape is right from the start.

---

### 4.4 Cigar Detail Screen

A full-detail view of a single cigar, accessible from two entry points: the identification result (via a "Details" button on the cigar card) and any Journal entry (tap the cigar card). This is the "deep info" layer. The identification result card stays lean. The detail screen is the destination for users who want the complete picture.

The screen has two zones: a first fold that leads with the cigar image and the headline attributes, and a below-the-fold block with the full specs.

**First fold:**

- Large vertical cigar image on the left (~80 to 90% of screen height, recognizable by the band). A scaled product shot in the build.
- Key attributes alongside it on the right:
  - Customer rating (star rating + review count, from the cigar database)
  - Brand logo and brand name
  - Line (and vitola/size when available)
  - Taste-match indicator (e.g. "92% taste match"). **Post-MVP.** Shown as a placeholder/preview in the wireframe only. It depends on the taste profile, which is out of scope for MVP (see §4.3 and §5), so it is not active at launch.
- A "scroll for specs" affordance hints at the content below the fold.

**Below the fold (full specs, in display order):**

- Date smoked
- Wrapper
- Binder
- Filler
- Strength (label + visual indicator)
- Smoke time (in minutes)
- Flavours: first 3 shown as chips; a "+ more" pill expands the cluster inline to reveal the rest (up to 10 in the database). No new screen, no modal.
- Description paragraph (one paragraph, editorial tone)

**Behaviour:**

- The screen is scrollable. All fields are read-only in MVP.
- If specific size (vitola) has not yet resolved, that field shows a loading state or is omitted until available.
- Back navigation returns the user to the identification result or Journal entry they came from. The header back arrow label reflects the origin ("← Retake" from identification, "← Journal" from a Journal entry).

---

### 4.5 Install to Home Screen (PWA)

A lightweight install prompt that turns first-time visitors into returning users without ever blocking the camera-first flow. This addresses the reacquisition gap from §6.3: an installed PWA on the home screen is the most durable surface Vitolero has after share.

**Trigger condition:**

- Show only after the user has completed at least one successful identification. Never on first open. The user must have experienced value before being asked to install.
- Show at most twice. After two declines, do not show again in MVP.

**iOS (Safari):**

- Safari does not expose `beforeinstallprompt`. Add-to-Home-Screen is manual on iOS.
- Show a custom in-app explainer card after the trigger condition is met: "Add Vitolero to your home screen: tap the Share icon below, then Add to Home Screen." Include a small illustration of the iOS Share icon to make the action visually obvious.
- Dismissable with "Not now."

**Android (Chrome and Chromium-based browsers):**

- Use the browser-native `beforeinstallprompt` event. Capture and defer it until the trigger condition is met.
- When the user dismisses or installs, store the state locally to avoid re-prompting.

**Placement:**

- Show as a bottom-sheet card from the identification result screen (after the first share or after the first save to Journal, whichever comes first).
- Never block the camera or the share flow.

**Out of scope for MVP:**

- Desktop install prompts.
- Custom badges or notification permissions tied to the install state.
- Push notifications after install (PWA push on iOS is still too limited per Section 7).

---

## 5. Out of Scope for MVP

| Feature | Status | Note |
|---|---|---|
| Vitola identification | Post-MVP | Speed trade-off. Brand and line is sufficient for Dave. |
| Taste profile (active) | Post-MVP | Journal data passively shapes future recommendations. No UI in MVP. |
| In-store recommendations | Post-MVP | Requires a taste profile. No profile = no recommendations. |
| Discovery feed | Post-MVP | Same dependency as in-store rec. |
| Bi-directional pairing | Post-MVP | Drink-to-cigar direction removed from MVP. |
| Menu-aware pairing | Post-MVP | Photo of a drinks menu + cigar = complex multi-input. Future. |
| Cigar Doctor | Post-MVP | Infrequent, pro-level. Strong future paywall candidate. |
| Photo import (from gallery or Facebook) | Post-MVP | Meta API restrictions make FB import impractical. Camera roll import valuable but not MVP. |
| Cigar authentication | Removed | Not technically feasible. Deep, multi-layered process. Removed permanently from v1 scope. |
| Tablet and desktop support | Post-MVP | Smartphones only for v1. Use cases (lounge, porch, shop) are phone scenarios. |
| Offline mode | Post-MVP | All AI features require connectivity. Stated assumption for v1. |
| Non-English content | Post-MVP | US-first launch. Other regions and languages after MVP validation. |

---

## 6. User Flows

### 6.1 First-time user flow

| Step | Screen / State | What happens |
|---|---|---|
| 0 | Welcome screen | App opens to a welcome screen with three statements explaining what Vitolero does, plus why camera access is needed. Single CTA ("Get Started") triggers the system permission dialog. One-time only. |
| 1 | Camera permission | System dialog. User grants camera access. |
| 2 | Camera state | Full-screen camera. Minimal hint: "Frame a cigar." No sign-up wall. |
| 3 | Camera state | User points camera at a cigar and taps the shutter. |
| 4 | Processing state | Photo dims. Sommelier-style narrative streams: "I see a dark wrapper with a gold band... Checking against our database..." Latency budget: under 10 seconds. A cancel action is visible throughout, and tapping it returns the user to the camera. |
| 5 | Identification result | Brand and line displayed prominently. Strength and one-line flavor summary. Filter previews shown below. "Details" button available for the full Cigar Detail screen (§4.4). |
| 6 | Filter selection | User selects a filter overlay. Composited preview shown before share. Overlay on by default; tapping the image toggles it off. |
| 7 | Share screen | Share to Facebook (primary button). Web Share API for other platforms. User can skip sharing and just save. Back navigation available. |
| 8 | Post-share | User exits the app to the platform they shared to. App has no control over what happens next. |
| 9 | Pairing prompt | Available from the share screen or identification result. User can trigger pairing before or after sharing. |
| 10 | Journal discovery | User notices Journal icon. Taps it. Account creation triggered (Google or Apple sign-in). |
| 11 | Journal | First photo logged. Cigar card and user photo appear together. |

**Note:** Sharing is the primary CTA after identification. Journal access is secondary and deferred to when the user is ready.

---

### 6.2 Returning user flow

| Step | Screen / State | What happens |
|---|---|---|
| 1 | Last photo state | App opens showing the last photo taken. Action buttons: Share, Pairing, Journal. No camera on reopen. |
| 2 | Options | User chooses to snap a new cigar (camera button), access a previous result, or open Journal. |
| 3 | New snap | Camera opens. Flow from Step 2 of first-time flow. |
| 4 | Pairing (returning) | Pairing result available from any previous identification result in Journal. |

---

### 6.3 Share abandonment path

After the user taps share and leaves the app, there is currently no mechanism to bring them back. This is an acknowledged open problem.

The app has no post-share hook because:
- Facebook deep links do not return the user to the app after sharing.
- Web Share API for image files has no callback.
- PWA push notifications are severely limited on iOS.

**Current state:** No solution. Fabio is investigating technical options.
**Impact:** The user's next session depends entirely on voluntary return. Snap frequency is the leading indicator to watch.

**Mitigation in progress:** Journal activation creates a more durable relationship. A user who creates an account and builds a Journal has a reason to return beyond the next smoke. This is part of why Journal is in MVP despite not being the hero feature.

---

## 7. Non-Functional Requirements

| Requirement | Specification |
|---|---|
| Platform | Progressive Web App (PWA). Installable on device. |
| Device support | Smartphones only. Android and iOS. No tablet, no desktop. |
| Connectivity | Internet required. All AI features (identification, pairing) need connectivity. Offline mode is not supported in v1. |
| Latency: identification | Under 10 seconds from capture to result. |
| Latency: pairing | 10 to 15 seconds from cigar line input to 6-item result. |
| Photo storage: pre-account | Local storage on device. Not 100% reliable. Risk acknowledged. |
| Photo storage: post-account | Cloud storage after Google sign-in via Journal. |
| Photo aspect ratio | Flexible handling. Portrait, landscape, and square all supported without forced cropping. |
| PWA push notifications | Severely limited on iOS. Not relied upon for reacquisition in MVP. |
| Identification confidence | Results surface only at 80%+ confidence. Up to 3 candidates when ambiguous. |

---

## 8. Technical Constraints

| Constraint | Detail |
|---|---|
| No Facebook API | Tobacco restriction. Deep links only (sharer.php). The Vitolero domain is visible under link preview. |
| No simultaneous multi-platform share | Each share is a separate user action. One platform at a time. |
| No post-share user control | Once the user leaves the app to share, the session is effectively over. No callback, no redirect back to app. Fabio to investigate solutions. |
| Cigar authentication | Not feasible. Deep, multi-layered verification process that current technology cannot support. Removed from scope. |
| Image quality dependency | Identification accuracy depends on photo quality and lighting. Well-lit, in-focus photos of the cigar band produce better results. User guidance on capture quality is a UX responsibility. |
| Non-deterministic AI | Identical inputs can produce slightly different results due to confidence scoring variance. Results may vary between attempts. |
| Second-pass verification disabled | A refinement step exists in the pipeline that increases accuracy but pushes latency from ~10 seconds to ~30 seconds. Disabled in MVP. Speed takes priority. |

---

## 9. GTM Summary

Full strategy in `strategy/gtm.md`.

**Primary channel:** Facebook cigar groups. Combined membership in the top groups runs into the hundreds of thousands. Share cards that answer "what are you smoking?" are native, high-value content in these groups.

**Admin partnership model:** Reach out to group admins and moderators. Offer them a role as advisors (with compensation, whether flat fee, revenue share, or equity). Involve them in feedback and iteration. Position them as part of the product, not as promotion vectors. Structure TBD (see Section 12).

**Timing gate (critical):** Do not approach admins until a working MVP is ready. First impressions in these communities are hard to recover from. A broken or unimpressive product shown to a group admin is a permanent reputational cost in that community.

**Secondary channels:** Instagram (#BOTL, #cigarlife, #cigarsofinstagram), Discord (bot opportunity), Reddit (r/cigars, r/cubancigars), YouTube (credibility via independent creator mentions). These channels receive share cards organically as Dave-type users post their photos.

**Distribution model:** The share card is the distribution mechanism. Every user who shares a photo extends the product's reach into communities Vitolero cannot access through paid acquisition (which does not exist for tobacco products on any major platform).

---

## 10. Post-MVP Roadmap

### Phase 2: Recommendations from taste profile

**Timing:** Weeks after MVP, not months. The Journal schema is designed from day one to support this. No rebuild needed, just the recommendation logic and UI on top of existing data.

**What it requires:** Journal data reaching a meaningful volume per user (approximately 5 to 10 logged cigars as a minimum). No UI additions during MVP.

**Features unlocked:** In-store recommendation (photo of humidor, ranked results against user profile), discovery feed (personalized cigar recommendations based on past snaps), advanced taste profile UI for Carlos-type users.

---

### Phase 3: Advanced pairing scenarios

**What it adds:** Multiple cigars in a single photo with individual pairings. Social context pairing (what pairs well for 4 people with different preferences?). Reverse pairing (drink to cigar). Menu-aware pairing (photo of a drinks menu and cigar).

**Dependency:** Core pairing must work reliably at scale before adding complexity.

---

### Phase 4: Dedicated cigar social network

**Funding gate:** $500K to $1M required. US legal requirements for a dedicated social platform handling tobacco content at scale introduce compliance costs that a bootstrapped team cannot absorb.

**What it enables:** Users publish their Journals publicly. Follows, likes, and comments between users. Community-level content that is not subject to Meta or Google content restrictions. Vitolero owns the distribution layer instead of depending on Facebook groups to tolerate its presence.

**Strategic context:** Facebook and Instagram are increasing restrictions on tobacco content. The communities that live there are looking for a native home. The Journal, built from MVP, is already the personal layer of what this social network will become. The social layer adds the public dimension.

---

## 11. Success Criteria (MVP)

| Metric | Definition | Target |
|---|---|---|
| Share rate | Percentage of identification sessions that result in a share | 40%+ (from `strategy/gtm.md`) |
| Post-share return rate | Percentage of users who return to the app after sharing | Baseline to establish. Currently an open problem. |
| Journal activation rate | Percentage of users who trigger account creation by opening Journal | Track from week one. |
| Pairing usage rate | Percentage of identification sessions where pairing is also used | Track from week one. No target set yet. |
| 7-day return | Percentage of users who return within 7 days of first session | Target to define based on early data. |
| 30-day return | Percentage of users active in month 1 who return in month 2 | Target to define based on early data. |
| Brand and line ID accuracy | Accuracy on well-known cigars (Padron, Arturo Fuente, Oliva, Romeo y Julieta, Liga Privada) | Tracked separately from overall accuracy. Reputation-critical for Facebook GTM. |

**Note on ID accuracy:** Overall accuracy (80%+) is the pipeline threshold. But reputation in the Facebook community depends on accuracy on well-known, frequently photographed cigars. Carlos will test the app with a Padron 1926 or an Oliva Serie V before he forms a judgment. If the app misidentifies a cigar that every enthusiast in the group recognizes, that failure travels faster than a correct identification ever would.

---

## 12. Open Questions

| Question | Status | Owner |
|---|---|---|
| Are photo filters alone enough value if users do not actually care about photo quality? | Live debate within the team. The MVP tests this assumption directly. Instagram's success via effortless enhancement is the counter-argument. | Answered by launch data. |
| Post-share reacquisition: does the user come back after sharing? | Open. No current mechanism. PWA push notification limits on iOS make this hard. | Fabio investigating. |
| How to handle multiple cigars in a photo at scale? | MVP handling: ask the user to retake. Long-term solution needed for a realistic share flow (users often photograph their humidor or a group of cigars, not a single stick). | Post-MVP design problem. |
| Admin partnership incentive structure: flat fee, revenue share, or equity? | Not decided. Approach admins only after MVP is working. | Dimitar and Fabio to decide before outreach begins. |
| Journal visual design: Pinterest masonry vs. Instagram grid vs. something else? | **Resolved:** Pinterest-style masonry. | Closed. |
| Should collection views (by brand, by date, by rating) be in MVP Journal or post-MVP? | Not decided. Minimal version (chronological only) is sufficient for MVP. | Dimitar and Fabio to scope. |

---

## 13. Key Assumptions

| Assumption | Basis | Risk if wrong |
|---|---|---|
| Dave's share behavior transfers to the in-app flow despite the added step vs. native camera sharing. | Dimitar identified this as the "make or break detail." The extra step (app vs. native share) must be justified by filter quality and the identification overlay. | If users default to native camera and bypass the app, the entire distribution model fails. Share rate is the early indicator. |
| 3 to 5 filter overlays is enough variety to feel personalized without being overwhelming. | Qualitative judgment. Instagram's early filter adoption supports the idea that a small, high-quality set beats a large, mediocre one. | If filters feel generic or limited, users won't prefer the in-app share flow over native. |
| Brand and line granularity is sufficient for Dave. He does not care about vitola. | Behavioral observation from Facebook groups: posts almost never reference vitola. Brand and line are the vocabulary most users have. | Carlos-type users will notice the missing vitola. This is acceptable because Carlos is post-MVP. |
| Facebook group admins will accept a partnership model when approached with a working MVP. | No validation yet. The model is plausible (admins already have informal influence; formalizing it with compensation makes sense). | If admins are unwilling, the primary acquisition channel requires a different approach. The timing gate (working MVP first) reduces but does not eliminate this risk. |
| Journal schema designed in MVP can support future recommendations without a rebuild. | Engineering assumption requiring confirmation from Dimitar and Fabio before build. | If the schema does not support recommendations, Phase 2 requires a rebuild. This delays recommendations from weeks to months. |

---

## 14. Related Documents

| Document | Location |
|---|---|
| Concept Framework | `strategy/concept.md` |
| Go-to-Market Strategy | `strategy/gtm.md` |
| Personas (6 profiles, 3 tiers, ritual framing) | `research/personas.md` |
| Jobs to Be Done | `research/jtbd.md` |
| Feature drilldown | `research/feature-drilldown.md` |
| Onboarding angles | `research/onboarding-angles.md` |
| Market research | `research/market-research.md` |
| Navigation plan | `navigation-plan.md` |
| Wireframes | `wireframes/` |
