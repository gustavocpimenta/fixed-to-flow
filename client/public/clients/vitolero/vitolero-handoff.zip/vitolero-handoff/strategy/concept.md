# Vitolero: Concept Framework

---

## 1. Business Context

Vitolero is an AI-powered cigar companion app. It pairs a comprehensive cigar database with an LLM backend to deliver identification, pairings, and a photo-first sharing experience. The product runs as a Progressive Web App, sidestepping App Store dependency entirely.

**Distribution constraint.** Paid advertising is not an option. The EU tobacco directive and platform-level restrictions across Meta, Google, and TikTok close every conventional digital channel. The PWA approach sidesteps App Store gatekeeping but introduces a different problem: no discovery layer. There is no channel that does the work of getting users to the front door. See `strategy/gtm.md` for the full analysis and strategy.

**The core value proposition.** Take a photo of your cigar, apply a filter that makes it look great, get the brand and line identified, and share it to Facebook in seconds. That is the MVP. The filter does the work: it applies a soft peripheral blur (bokeh) that isolates the cigar visually, keeping the cigar sharp while the background softens. A semi-transparent strip at the bottom carries the brand logo, brand name, line, and a subtle Vitolero mark. The overlay is on by default; the user can toggle it off by tapping the image. The original photo is always preserved and the filtered version is the shareable artifact. There are exactly 3 cigar-specific filters. Together they produce something that looks magazine-quality rather than a phone snapshot. The share card carries the Vitolero domain to an audience the app could never buy its way to.

**Snap & Share is the distribution engine.** When a user photographs a cigar, applies a cigar-specific filter, and shares the result to a Facebook group, that card reaches thousands of members the app could never target directly. Identification and pairing deepen the value. The filter is the hook.

**MVP scope.** The MVP contains exactly three features: Snap & Share (with cigar-specific filters and brand-plus-line identification), Pairing (cigar line to 3 food items and 3 drink items, one-directional), and Journal (Pinterest-style gallery with deferred account creation). Identification operates at three levels: brand and line surface fast (under 10 seconds) and are sufficient for quick sharing; specific size (vitola) may resolve slightly later and surfaces in the Cigar Detail screen. The taste-profile flywheel, in-store recommendation, discovery feed, Cigar Doctor, photo import, and full vitola detection are all deferred. This scope is intentional. A pre-seed team needs a launchable product, not a feature-complete one.

**Monetization strategy: free first, charge later.**

This is a deliberate learning phase.

Phase 1: Launch with everything free. No feature limitations, no trial periods, no premium tier. The goal is to attract users, build the community, and observe real behavior at scale.

Phase 2: Watch what happens. Which features drive return visits? What creates switching costs? Where do users spend time? Where do they drop off?

Phase 3: Introduce a paid tier based on observed value, not assumptions. Pricing starts very low ($2.99 to $4.99 per month). At that price, the subscription is a trivial expense for someone already spending $800+ per year on cigars. Premium candidates will emerge from usage data.

Forcing a monetization decision before usage data exists increases churn risk and reduces the signal quality needed to design the right premium offer.

**Platform constraints (v1).**

- **Smartphones only.** Target phones exclusively. Exclude tablets and desktop. The cigar use cases (on the porch, at the lounge, in the backyard) are phone scenarios.
- **No offline support.** AI-driven features require internet connectivity. Designing a meaningful offline experience around ML-based identification adds significant complexity with limited return.
- **PWA push notification limits.** Restrictions on iOS limit what can be done with push notifications. Partial mitigation: if social sign-in is implemented, the app gains an alternate notification channel through those platforms.
- **Cigar authentication not yet possible.** The system cannot verify whether a cigar is genuine. Removed from v1 scope entirely.
- **Facebook API not available.** Meta's tobacco restrictions prevent use of the Facebook API. Distribution into Facebook groups uses deep links only. Each share is a separate action. No simultaneous multi-platform sharing.
- **No user reacquisition control post-share.** Once the user taps share, they leave the app. The team is investigating reacquisition mechanisms (Fabio to follow up).
- **Variable gallery aspect ratios.** Photos arriving from the gallery come in multiple aspect ratios. The interface must handle this gracefully.

This document establishes the MVP rules that all design decisions will follow. It is a compass, not a blueprint. The framework sets the conceptual direction. It does not prescribe pixels, layouts, or implementation details.

---

## 2. Personas

Six distinct user types emerge from community research. For the MVP, one persona leads: Dave, the Weekend Ritualist.

### MVP Persona: Build for Dave

| | Weekend Ritualist |
|---|---|
| **Name** | Dave |
| **Profile** | 47, Austin TX. Marketing director. 2 to 4 cigars per week, 3 to 5 years in. Desktop humidor, 15 to 40 cigars. Middle-aged, smokes solo, shares photos individually on Facebook. |
| **Core JTBD** | "Help me enjoy my ritual without making it homework." |
| **Entry scenario** | Sees a friend's share card on Facebook, opens the app, takes a photo of the cigar he's currently smoking. |
| **Success metric** | Snapping and sharing becomes part of the weekly ritual. |
| **Churn risk** | Medium. If the app demands too much input, it feels like work instead of ritual enhancement. |
| **MVP priority** | Primary. Every design decision is optimized for Dave. |

**Operational principle: build for Dave, design for Dave's Saturday-night solo smoke.**

Dave is the largest addressable audience and maps directly to the Snap & Share core loop. He photographs cigars anyway. The app gives that behavior a filtered, shareable output. He is the target user the MVP must delight.

### All Six Personas: MVP vs Post-MVP Priority

| Persona | Name | Profile | MVP Priority | Post-MVP |
|---|---|---|---|---|
| **Weekend Ritualist** | Dave, 47 | 2 to 4 cigars/week. Ritual-focused. Smokes alone, shares photos. | **Primary** | Served fully |
| **Deepening Enthusiast** | Carlos, 34 | 3 to 5 cigars/week. Follows blenders, buys boxes, values precision. | Served (reduced depth) | Full features, recommendations |
| **Celebratory Occasional** | Mark, 38 | 4 to 8 cigars/year. Event-driven. The share card IS the value for him. | Served (share only) | Expanded occasion features |
| **Curious Newcomer** | Tyler, 28 | 1 to 2 cigars/month. Just started. Photo-first sidesteps the vocabulary gap. | Served (share + pairing) | Onboarding depth |
| **Lounge Social** | Jerome, 42 | 1 to 3 cigars/week at lounges. Social confidence is the core need. | Served (share only) | Community features |
| **Collector-Connoisseur** | Richard, 58 | 5 to 7 cigars/week. Won or lost on data quality. | Not targeted | Journal depth, analytics |

**On Carlos and the MVP.** Carlos (Deepening Enthusiast) is explicitly deferred as a primary design target. However, he will find the app through Facebook groups and judge it publicly on identification accuracy. Brand-plus-line identification accuracy on well-known cigars is a reputation-critical metric in MVP, not only a post-MVP concern. An inaccurate result on a cigar Carlos knows well is a public failure. Design for Dave. Protect against Carlos.

---

## 3. Journey Stages

Four stages describe the user's relationship with Vitolero. These are not expertise levels. Two personas can be at Stage 1 simultaneously.

| Stage | Definition | Progression trigger |
|---|---|---|
| **First Encounter** | Never used the app, or just opened it for the first time. | Completes first snap and gets a useful result. |
| **Early Use** | 1 to 3 sessions. Testing whether the app delivers. | Returns voluntarily for a second distinct use case. |
| **Regular Use** | Weekly or monthly usage. The app is part of the cigar routine. | Begins using features beyond identification and sharing. |
| **Power Use** | Deeply invested. Uses multiple features. The app holds meaningful personal data. | Terminal stage. |

### Persona Activity by Stage

| Stage | Dave (Ritualist) | Carlos (Enthusiast) | Mark (Occasional) | Tyler (Newcomer) | Jerome (Social) | Richard (Collector) |
|---|---|---|---|---|---|---|
| First Encounter | **Primary** | **Primary** | **Primary** | **Primary** | **Primary** | **Primary** |
| Early Use | **Primary** | **Primary** | Active | **Primary** | Active | Active |
| Regular Use | **Primary** | **Primary** | Rare | Active | Active | Active |
| Power Use | Active | **Primary** | Rare | Rare | Rare | **Primary** |

The highest churn risk sits at First Encounter and Early Use. Retention investment should focus almost entirely on the First Encounter to Early Use transition. For the MVP, that means: take photo, get filter, see identification, share. That sequence must be effortless.

---

## 4. Jobs to Be Done

### MVP-Active Jobs

These are the jobs the MVP serves. They map directly to the three features.

| Job | Statement | Feature alignment | MVP status |
|---|---|---|---|
| **Identify** | "Tell me what this is." Brand and line only. Fast. | Cigar Identification | Active |
| **Enhance via filter** | "Make my photo look worth sharing." Cigar-specific filters with automatic overlay. | Snap & Share (filters) | Active |
| **Share** | "Show what I'm smoking." Prompted after the filter is applied and identification is shown. | Snap & Share | Active |
| **Pair** | "What goes with this cigar?" One-directional: cigar line to food and drink. | Pairing | Active |
| **Remember** | "Keep a gallery of what I've smoked." Pinterest-style journal. Account created only on access. | Journal | Active (partial) |

### Post-MVP Jobs

These jobs are understood but not served in v1.

| Job | Statement | Feature | Notes |
|---|---|---|---|
| **Choose** | "Help me choose in-store." | In-store Recommendation | Needs taste profile. Deferred. |
| **Discover** | "Find great cigars for me." | Discovery / Recommendation Feed | Needs taste profile. Deferred. |
| **Remember (full)** | "Remember my palate. Recommend based on what I like." | Signature Taste Profile | Passive, hidden engine. Post-MVP. |
| **Identify (vitola)** | "Tell me exactly what vitola this is." | Vitola-level ID | 40 to 50 second processing. Not v1. |
| **Pair (bi-directional)** | "I have a drink. Suggest a cigar." | Bi-directional Pairing | Reverse direction deferred. |
| **Pair (menu-aware)** | "I have this cigar and this drinks menu." | Menu-aware Pairing | Requires OCR on menus. Deferred. |

### Persona-Specific Jobs

| Job | Primary Persona | Why it's specific |
|---|---|---|
| "Make my Saturday ritual worth photographing" | Dave (Weekend Ritualist) | The ritual itself is the product. The filter makes it shareable. |
| "Share photos from my solo smoke" | Dave (Weekend Ritualist) | Smokes alone. Shares individually on Facebook. Not group events. |
| "Enhance my ritual with better pairings and tools" | Dave (Weekend Ritualist) | After sharing, pairing is the next value layer. |
| "Improve precision. Account for what I dislike." | Carlos (Deepening Enthusiast) | Post-MVP. Requires taste profile. |
| "Tell me what I'm smoking so I look knowledgeable" | Mark (Celebratory Occasional) | The share card is the entire value for him. |
| "Guide me without making me feel stupid" | Tyler (Curious Newcomer) | Photo-first sidesteps the vocabulary gap entirely. |

---

## 5. Main Features (v1)

### Overview

The MVP contains three features. Everything else is deferred. No exceptions.

| Feature | Priority | MVP status | Personas served |
|---|---|---|---|
| **Snap & Share** (with filters + brand-line ID + overlay) | Core | Active | All |
| **Pairing** (one-directional, cigar line to 6 items) | Core | Active | Dave, Mark, Tyler |
| **Journal** (Pinterest-style gallery, deferred account creation) | Core | Active | Dave, Carlos, Richard |

---

### 5.1 Snap & Share

The hero feature. The growth engine. The reason new users find the app.

The core loop: photograph a cigar, see the brand and line identified, apply a cigar-specific filter, share to Facebook or another platform. Every snap is simultaneously an identification moment and a distribution opportunity.

**How it works.**

1. User opens the app. Camera is the default state on a fresh open.
2. User captures the cigar.
3. Identification result appears: brand and line, no vitola. Target: sub-10 seconds. 80%+ confidence. Up to 3 candidates returned if confidence is below threshold. A cancel action is available during processing and returns the user to the camera.
4. Filters apply. The default filter applies a soft peripheral blur (bokeh) that keeps the cigar sharp while the background softens, so it pops visually. A semi-transparent strip at the bottom carries the brand logo, brand name, line, and a subtle Vitolero mark, now available from the identification step. The overlay is on by default; the user can toggle it off by tapping the image. Exactly 3 cigar-specific filters are available.
5. Share prompt appears. User taps "Share to Facebook." Deep link opens the Facebook share dialog. The Vitolero domain is visible under the image in the link preview. For other platforms, the image file is shared directly.
6. After sharing, the user leaves the app. Reacquisition is a known open problem (Fabio to investigate).
7. The photo is added to the Journal (local storage pre-account, synced to account post-creation).

**On filters as the value proposition.**

There is an open internal debate: are filters alone enough value if users do not care about photo quality? The honest answer is: it is an assumption the MVP will test. The counter-argument is strong. Instagram succeeded because photo enhancement was effortless. The filter removes friction from a behavior users already do (photographing their cigars). Whether that is sufficient is a question the market will answer. The filter-as-value-driver is named here as an assumption, not a settled fact.

**On multiple cigars in one photo.**

If the photo contains more than one cigar, ask the user to retake with a single cigar. Multi-cigar identification for pairing purposes is not in scope for MVP.

**Share mechanics.**

Facebook: deep link to Facebook sharer. No Facebook API (tobacco restrictions). One share at a time. No simultaneous multi-platform sharing.

Other platforms: Web Share API. Image file delivered directly.

Landing page: each share can generate a unique URL showing the photo and cigar details on a clean page. No CTAs, no download banners. The domain in the URL bar is the only branding.

---

### 5.2 Identification

Photo in, identification out. The universal entry point, embedded in every flow.

**Three-level model.** Identification operates at three levels: brand, line, and specific size (vitola). Brand and line surface fast (under 10 seconds) and are sufficient for the quick share loop. Specific size may load slightly later and surfaces in the Cigar Detail screen when the pipeline resolves it. For quick sharing, brand and line cover 90%+ of users.

**Second-pass verification disabled in MVP.** A refinement step exists in the pipeline that increases accuracy but pushes latency from around 10 seconds to around 30 seconds. This step is disabled in MVP. Speed takes priority over marginal accuracy gains.

**Target specs.**

- Processing time: sub-10 seconds target (brand and line)
- Confidence threshold: 80%+
- Results: up to 3 candidates per identification attempt
- A cancel action is visible throughout processing and returns the user to the camera

**What happens during processing.**

A brief narrative keeps the user engaged: "I see a dark wrapper with a gold band... Checking the database... This looks like a Padron..." The narrative starts within 2 seconds of capture. The full result arrives within 10 seconds. The user is engaged, not waiting.

**Why accuracy matters even in MVP.**

Carlos (Deepening Enthusiast) will find the app through Facebook groups. If the identification is wrong on a cigar he knows, he will say so publicly. Brand-plus-line accuracy on well-known cigars is a reputation metric from day one. The current accuracy sits at around 80%. Production target is 95%+.

---

### 5.3 Pairing

One-directional: cigar to food and drink. No reverse direction in MVP.

**How it works.**

Input: the identified cigar (brand and line).
Processing target: 10 to 15 seconds.
Output: exactly 6 items.

- 3 food options: one snack, one meal, one dessert.
- 3 drink options: one hard liquor or wine, one cocktail, one coffee or tea.

The pairing is based on the cigar line. Not the vitola, not the user's taste profile. The line is enough signal for a first-version pairing.

**Screen layout.** The pairing screen places a large vertical cigar (about 80 to 90% of screen height, recognizable by the band) on the left, with the 6-item pairing list beside it on the right. The cigar carries its name and a one-line flavour note. Each suggestion shows only the item name: no per-item category tags (Snack, Meal, Dessert / Liquor, Cocktail, Coffee) and no food or drink icons. The Food and Drink group dividers are present but visually de-emphasized. Exactly one suggestion across the whole result is highlighted as the featured pairing, marked with a star and label. One featured per result, not one per group.

**Text-only display.** Pairings render as text only, not as images. The reasons: speed (no image fetch in the 10 to 15 second budget), no licensing or AI-image-quality risk on food and drink imagery, the visual budget is already spent on the share card and filtered photo, and Dave reads the pairing for the answer rather than for visual delight. A future post-MVP option is small flat category icons if the pairing screen becomes a destination in its own right.

**The pairing screen is not a dead end.** Forward actions are always visible: "New Snap" (camera) and "Journal." The user can continue without friction.

**What is deferred.**

Bi-directional pairing (drink to cigar) is post-MVP. Menu-aware pairing (photo of a drinks menu) requires OCR on menus and is post-MVP.

---

### 5.4 Journal

A Pinterest-style gallery of the user's cigar photos. A visual record of what they've smoked.

**How it works.**

Photos taken through the app are stored in the Journal. The gallery is browsable, filterable, and supports favorites. Photos persist in local storage before account creation. Local storage is not 100% reliable: this is a known limitation and should be surfaced somewhere in the UX.

**Account creation is deferred to Journal access.**

The user does not create an account to use Snap & Share or Pairing. Account creation is triggered the first time the user tries to access the Journal. Social login accepts Google or Apple ID (one-tap, both options at the sign-in sheet) to minimize friction.

**Gallery layout.** Pinterest-style masonry. This gives each photo the space its aspect ratio deserves and creates a visually rich browsing experience without forcing uniform crops.

**Two distinct concepts inside the Journal.**

A cigar card (product information: brand, line, flavor notes, origin from the database) is not the same thing as a user photo. Both appear in the Journal view but they are related, not identical. A user can have a photo with no matching cigar card (unidentified photo). A cigar card can exist without a user photo (if pairing is triggered by text input).

**Future-proofing.**

The Journal data schema should be designed from day one to support future recommendations. No UI, no logic beyond what is needed for v1. Just the schema. This costs nothing now and avoids a rebuild later.

---

### 5.5 Cigar Detail Screen

A full-detail view of a single cigar. This is the deep-info destination. The identification result card stays lean; users who want the complete picture come here.

**Two entry points.** A "Details" button on the cigar card from the identification result screen, and any Journal entry (tap the cigar card). The Cigar Detail screen serves both paths.

**Layout.** The screen has two zones: a first fold that leads with the cigar image and the headline attributes, and a below-the-fold block with the full specs.

First fold:

- Large vertical cigar image on the left (about 80 to 90% of screen height, recognizable by the band). A scaled product shot in the build.
- Key attributes alongside it on the right: customer rating (star rating plus review count, from the cigar database), brand logo and brand name, line (and vitola/size when available), and a taste-match indicator (for example "92% taste match"). The taste-match indicator is **post-MVP**: it is shown as a placeholder/preview in the wireframe only, depends on the taste profile (out of scope for MVP, see §5.4 and §5.8), and is not active at launch.
- A "scroll for specs" affordance hints at the content below the fold.

Below the fold, in display order:

- Date smoked
- Wrapper, binder, filler
- Strength: label plus a visual indicator
- Smoke time in minutes
- Flavours: first 3 shown as chips, with a "+ more" pill that expands the cluster inline to reveal the rest (up to 10 in the database). No new screen, no modal.
- Description paragraph: one paragraph, editorial tone

**Behaviour.** The screen is scrollable. All fields are read-only in MVP. If specific size (vitola) has not yet resolved, that field shows a loading state or is omitted until available. Back navigation returns the user to wherever they came from. The back arrow label reflects the origin: "Retake" from identification, "Journal" from a Journal entry.

---

### 5.6 Install to Home Screen (PWA)

A lightweight install prompt that converts first-time visitors into returning users without ever blocking the camera-first flow. It addresses the post-share reacquisition gap: an installed PWA on the home screen is the most durable surface Vitolero has after a share.

**Trigger condition.** Show only after the user has completed at least one successful identification. Never on first open. Show at most twice. After two declines, do not show again in MVP.

**iOS and Safari.** Safari does not expose the native install prompt. Show a custom in-app explainer card: "Add Vitolero to your home screen: tap the Share icon, then Add to Home Screen." Include a small illustration of the iOS Share icon to make the action visually obvious. Dismissable with "Not now."

**Android and Chrome.** Use the native browser install prompt event, deferred until the trigger condition is met. Store dismiss or install state locally to avoid re-prompting.

**Placement.** A bottom-sheet card from the identification result screen, shown after the first share or first save to Journal, whichever comes first. Never blocks the camera or the share flow.

**Out of scope for MVP.** Desktop install prompts, custom notification badges, push notifications after install.

---

### 5.7 Onboarding

The first 30 seconds of the experience. This is the most important design problem in the MVP.

**Welcome screen (first open only).** Before the system camera permission dialog appears, one screen shows the app identity (logo and name), three short statements that set expectations, and a single CTA ("Get Started") that triggers the camera permission request. The three statements are: (1) Snap any cigar for instant ID and a magazine-quality share card; (2) Ask for a pairing: food and drink that match what you're smoking; (3) Everything you snap saves to your Journal. This screen is one-time only. It never appears again after the first session. Its purpose is to prevent the system permission dialog from appearing with no context immediately after install.

**First-time user flow.**

1. Welcome screen (first open only, see above).
2. Camera permission dialog.
3. Camera active. User takes a photo of a cigar.
4. Processing. A cancel action is visible throughout and returns the user to the camera.
5. Identification result appears (brand and line).
6. Filter applies. The user picks from 3 looks; the brand and line overlay is on by default and toggles off by tapping the image.
7. Share prompt appears.
8. Pairing and other features are visible from this screen so the user knows more exists.

No sign-up. No wizard. No quiz. No "snap 3 cigars to unlock your profile." The experience is: photo, filter, ID, share. That is the complete first-time loop.

**Returning user flow.**

The app does not open to the camera for returning users. It opens to the last photo taken. Action buttons are available from that state. The camera is accessible but not the default. The returning user is continuing, not starting.

**Account creation moment.**

Account creation is not part of onboarding. It happens the first time the user taps Journal. Social login accepts Google or Apple ID.

**Design principle for onboarding.**

If the user has to make a decision in the first 30 seconds that is not "take a photo," something has gone wrong. Every choice before the share moment is friction. Remove it.

---

### 5.8 Deferred to Post-MVP

These features are understood, prioritized in principle, and explicitly out of scope for v1. They are listed here so the team does not relitigate them.

| Feature | Why deferred |
|---|---|
| **Signature Taste Profile** (passive, hidden) | Requires critical mass of snaps. Powers recommendations and advanced pairing. Post-MVP engine. |
| **In-store Recommendation** | Depends on taste profile. Photo of humidor display, ranked against preferences. |
| **Discovery Feed** | Depends on taste profile. "Find great cigars for me." |
| **Bi-directional Pairing** | "I have a drink, suggest a cigar." Reverse direction adds complexity without expanding the primary use case. |
| **Menu-aware Pairing** | Photo of a drinks menu + cigar = suggested pairing. Requires menu OCR. |
| **Cigar Doctor** | Photo of damaged cigar, analysis and repair suggestions. Infrequent use case. Strong paywall candidate. |
| **Photo Import** | Camera roll import to accelerate taste profile building. No profile in MVP, so no need yet. |
| **Full vitola-level identification** | The pipeline surfaces size (vitola) in the Cigar Detail screen when it resolves. Precise vitola detection at main identification speed is deferred. The current pipeline runs at 40 to 50 seconds for full vitola accuracy, which is unacceptable latency for the share flow. |
| **Instagram browsing** | Low-priority engagement feature. |
| **Browser extension (Facebook import)** | Meta API restrictions make this impractical. Revisit post-funding. |

---

## 6. Design Principles

### Six Principles

These are testable. Each includes its own failure condition.

**1. Camera is the front door.**

Every core task starts with a photo. The camera is not a feature inside the app. It IS the app's primary interface on a fresh open. If a user has to navigate to find a camera, the design failed.

**2. Perceived value in 10 seconds.**

The identification narrative starts within 2 seconds of capture. The full result arrives within 10 seconds. The user sees the AI working from the first moment: "I see a dark wrapper with a gold band... Checking the database..." This keeps the user engaged rather than waiting. The filter result is visible even faster, before identification completes. If the user sees nothing happening for more than 2 seconds after capture, the design failed.

Note: brand-plus-line identification is fast. The narrative exists as engagement during processing, but it does not need to perform depth it cannot yet deliver. The overlay tells the story.

**3. The app reads you.**

In MVP, "reading you" means: the returning user opens to their last photo, not a blank camera. The app remembers what you were doing. Profile building (in the full sense) is post-MVP, but the principle of continuity applies from day one. If the app treats every session like a fresh start, the design failed.

**4. One answer, scaled to depth.**

The same interaction produces different output depth depending on who is asking. A Celebratory Occasional sees the share card and that is enough. A Deepening Enthusiast sees the same card but will look for accuracy. The filter and overlay serve the casual user immediately. Depth is available for those who want it. If all users see the same undifferentiated output, the design failed.

**5. Companion over time, tool in the moment.**

Two interaction patterns coexist. Quick Mode for right-now moments: snap, filter, share, pair. Reflective Mode for at-home browsing: Journal, favorites, history. The app should make Quick Mode instant and Reflective Mode available but never in the way. If the app forces reflective engagement on someone who just wants to snap and share, the design failed.

**6. Every photo is marketing.**

The filter is the growth engine. The product must make sharing feel natural, not transactional. No CTAs that say "download our app." The domain does the attribution. The filtered photo with the brand overlay should look like something a cigar magazine produced, not like a screenshot of an app. If a user hesitates before sharing because the card looks generic or cheap, the design failed.

### Design Implications

These operational rules emerge from the persona and JTBD analysis.

- **The first 30 seconds are everything.** Photo, filter, identification, share. That sequence must be effortless for Dave.
- **Returning users get continuity.** The app opens to the last photo, not the camera.
- **Two modes, not six personas.** Jobs cluster into Quick (snap and share, pair) and Reflective (journal, browse). The interface should make Quick Mode instant.
- **Share card quality is a product priority.** If the card is generic, Dave will not share. If it looks great, sharing is self-motivated. The filter earns its place in the design hierarchy.
- **Churn follows a predictable pattern.** First Encounter and Early Use are the danger zones. All retention investment goes to these two stages.

---

## 7. UI Kit: Reference States

Ten reference states cover the complete MVP experience. These are building blocks, not final designs. A designer uses these to build screens. An engineer uses these to understand expected behavior.

### State 1: Welcome State (First Open Only)

The first screen a new user sees, before any system permission dialog.

**What appears:** App identity (logo and name). Three short statements that set expectations (instant ID and share card, pairing, Journal). A single CTA button ("Get Started") that triggers the camera permission request. No navigation chrome, no secondary actions.

**What the user can do:** Tap the CTA to proceed (primary). This is the only action on this screen.

**What varies by persona:** Nothing. This screen is universal. It disappears permanently after the first session.

### State 2: Camera State (Fresh Open)

The default state when the app is opened for the first time or by a new session.

**What appears:** Full-screen camera viewfinder. Corner brackets frame the cigar. One line of instruction: "Photograph any cigar." Shutter button at bottom center. No menu, no tabs, no navigation chrome.

**Two-pip navigation rule.** Vitolero uses two corner pips, not a tab bar:

- **Camera pip** (bottom-right). Visible on every screen except the camera viewfinder itself and screens where the camera is the implicit next action: sommelier processing, identification result, filter preview, share screen.
- **Journal pip** (top-right). Hidden on the very first session. Unlocks the moment the first identification auto-saves, then stays visible. Seek-style progressive reveal: the pip appears only when there is something to journal about.
- **Account creation** stays deferred. The first tap on the Journal pip triggers Google or Apple sign-in (per §5.4). No upfront wall.

The pip rule is gated by a single boolean (`hasIdentifiedAtLeastOnce`) persisted in local storage. Pattern lineage: Seek (journal-after-first-capture), Yuka (anonymous-first), Snapchat (camera-as-home).

**What the user can do on Camera State:** Take a photo (primary). On a fresh first-open, nothing else. The screen is intentionally empty. On returning sessions, access the Journal via the top-right pip (secondary).

**What varies by persona:** Nothing. This state is universal. Differentiation happens after the photo.

### State 3: Identification Result

Brand and line identified.

**What appears:** The captured photo, brand and line identified. Brand and line name prominent. Below or alongside: a brief flavor summary, strength indicator, origin. Two primary actions: "Share" and "Pair with food and drink." A "Details" button is available on the cigar card for users who want the full Cigar Detail screen.

**What the user can do:** Share the photo (primary). Access pairing. Tap "Details" to open the Cigar Detail screen. Save to journal.

**What varies by persona:** A casual user sees the name and a plain-language summary. A more experienced user sees richer specifications, checks identification accuracy, and will use the Details button.

### State 4: Filter Preview State

The step between identification and share.

**What appears:** The captured photo with the filter applied in real time. A soft peripheral blur (bokeh) keeps the cigar sharp while the background softens. A semi-transparent strip at the bottom of the image carries the brand logo, brand name, line, and a subtle Vitolero mark. The overlay is on by default. Tapping the image toggles the overlay off. The user can choose from 3 available filters before sharing.

**What the user can do:** Accept the filter and proceed to share (primary). Change the filter. Toggle the overlay on or off by tapping the image. Save to journal without sharing. Access pairing from this screen.

**What varies by persona:** Dave accepts the default filter and shares. Carlos may switch filters before sharing.

### State 5: Pairing Result

6 items returned: 3 food, 3 drink.

**What appears:** A large vertical cigar (about 80 to 90% of screen height) on the left with its name and a one-line flavour note; the 6-item list beside it on the right. Suggestions show item names only, with no per-item category tags or icons. The Food and Drink group dividers are de-emphasized. Exactly one suggestion across the whole result is highlighted as the featured pairing (star + label). Forward actions "New Snap" and "Journal" are always visible.

**What the user can do:** View pairings. Proceed to a new snap (primary forward action). Open the Journal. Return to the photo to share.

**What varies by persona:** Dave sees the pairings and picks one. Carlos notes whether the rationale holds up.

### State 6: Journal State (Reflective Mode)

Pinterest-style masonry gallery of the user's cigar photos.

**What appears:** A masonry layout of photos taken through the app. Each photo shows the brand and line overlay. Favorites are flagged. Browseable by recency. Tapping a cigar card opens the Cigar Detail screen. Search or filter is a post-MVP enhancement.

**What the user can do:** Browse photos. Tap a cigar card to open Cigar Detail. Favorite a photo. Return to camera.

**Account creation gate:** Accessing the Journal for the first time triggers Google or Apple ID sign-in.

**What varies by persona:** Dave browses his recent snaps. Richard (post-MVP) will want far deeper analytics than this state provides.

### State 7: Share Card State

The moment before publishing.

**What appears:** Final preview of the filtered photo as it will appear when shared. Brand overlay visible. A brief confirmation of the destination platform. Share button prominent. Optional: add a caption before sharing.

**What the user can do:** Confirm and share (primary). Change platform. Save to camera roll instead. Cancel.

**What varies by persona:** Dave taps share immediately. Carlos checks the identification one more time.

### State 8: Cigar Detail State

The full-detail view for a single cigar.

**What appears:** Brand logo, brand name, line (and vitola when available), date smoked, wrapper, binder, filler, strength (label + visual indicator), smoke time in minutes, flavour chips (first 3 visible, "+ more" pill expands inline), description paragraph. Scrollable. All fields read-only in MVP. If vitola has not resolved, that field shows a loading state or is omitted. Back arrow in the header labelled to reflect the origin ("Retake" or "Journal").

**What the user can do:** Scroll to read full specs. Tap "+ more" to expand the flavour cluster inline. Tap the back arrow to return to the identification result or Journal entry.

**What varies by persona:** Carlos uses this screen most. Dave may glance at it. Richard (post-MVP) will want export options not available in MVP.

### State 9: PWA Install State

The bottom-sheet install prompt.

**What appears:** A bottom-sheet card from the identification result screen. On iOS: an explainer card with a small illustration of the iOS Share icon and instructions to add to the home screen. On Android: the native browser install prompt triggered after at least one successful identification. Dismissable with "Not now."

**What the user can do:** Follow the install instructions (primary). Dismiss with "Not now." The prompt will appear at most once more after dismissal, then never again in MVP.

**What varies by persona:** Nothing. The prompt is universal once the trigger condition is met.

### State 10: Empty State

What happens if the user opens the app and the Journal is empty.

**What appears:** A friendly, non-intimidating prompt: "Your cigar world starts with one photo." A camera icon. No empty lists, no blank dashboards. Everything points toward that first action.

**What the user can do:** Take a photo (primary). Browse without a profile (secondary).

**What varies by persona:** Nothing. Everyone starts here.

---

## 8. User Flow Sketches

Three flows demonstrate the app's grammar. The hero flow shows why new people discover the app. The retention flow shows why they come back. The third flow shows how a returning user goes deeper through the Journal.

### Flow 1: Snap, Filter, Share (Hero Flow)

**Scenario:** Dave is on his back porch on a Saturday evening with a cigar. He wants to capture the moment and share it to his Facebook cigar group.

**Step 1: Welcome Screen (first open only).** On his very first open, Dave sees the app identity and three short statements about what Vitolero does. He taps "Get Started." The camera permission dialog appears.

**Step 2: Camera State.** Camera is active.

**Step 3: Capture.** Dave taps the shutter. The processing screen appears with a brief narrative. A cancel pill is visible throughout. He waits under 10 seconds.

**Step 4: Identification Result.** Brand and line appear: "Padron 1926 No. 9 Maduro." A "Details" button is visible on the cigar card. Dave ignores it for now.

**Step 5: Filter Preview State.** The filter applies. A soft blur isolates the cigar while the background softens. The brand strip appears at the bottom. Dave picks one of the 3 filters.

**Step 6: Share Card State.** Dave sees the final preview. He taps "Share to Facebook." Deep link opens the Facebook share dialog. His cigar group sees the branded photo with the identification overlay and the Vitolero domain under the image. Three members ask where the card came from.

**Step 7: Return.** The photo is saved to Dave's Journal. He never created an account. Local storage holds it until he accesses the Journal. The PWA install prompt appears as a bottom-sheet card.

**Why this flow matters.** Dave shared because the photo looked great, not because the app told him to. Three friends now know about the app. The identification happened as a byproduct of behavior Dave already does. If this flow is not effortless, or if the filtered photo does not look impressive enough to share, the product has not worked.

### Flow 2: Reopen, Continue, Pair (Retention Flow)

**Scenario:** Dave opens the app later that same evening. He wants to see what he was smoking and find something to pair with the bourbon he just poured.

**Step 1: Returning User State.** The app opens to the last photo taken. The Padron 1926 is on screen. Action buttons are visible.

**Step 2: Tap Pairing.** Dave taps the pairing button. The app generates 6 suggestions based on the Padron 1926 line.

**Step 3: Pairing Result.** 3 food options and 3 drink options appear. "Maker's Mark Bourbon" is among the drink suggestions. The rationale: "The chocolate and leather notes in the 1926 complement the vanilla and caramel in Maker's Mark."

**Step 4: Journal.** Dave taps the journal icon. A sign-in sheet appears with Google and Apple ID options. He taps one. His photo is now saved to his account.

**Why this flow matters.** Dave returned to the app without a prompt or notification. The value was immediate. The pairing gave him something useful for the moment he was already in. The Journal trigger created the account with minimal friction. This is how casual use becomes regular use.

### Flow 3: Journal to Cigar Detail (Depth Flow)

**Scenario:** Dave opens the app a few days later. He is curious about the tobacco composition of the Padron 1926 he smoked.

**Step 1: Last Photo State.** The app opens to the last photo taken. Dave taps the Journal pip.

**Step 2: Journal State.** The masonry gallery shows his recent cigars. He taps the Padron 1926 card.

**Step 3: Cigar Detail Screen.** The full detail view loads. A large vertical cigar fills the first fold, with the customer rating, brand, and line alongside it. Dave scrolls past the fold to the specs: wrapper (Maduro), binder, filler, strength indicator, smoke time, flavour chips. He taps "+ more" to expand the full flavour cluster inline. He reads the description paragraph.

**Step 4: Back.** Dave taps the back arrow, labelled "Journal." He returns to the masonry gallery.

**Why this flow matters.** The Journal is not just a photo album. It is the entry point to the depth layer. The Cigar Detail screen gives Carlos-type users what they came for without cluttering the share flow that Dave needs. One app, two depths, no conflict.

---

## 9. Business Model and Growth

Full strategy in `strategy/gtm.md`. Summary here.

**Distribution constraint.** Paid advertising is not available. EU tobacco directive and platform restrictions close every conventional digital channel. See `strategy/gtm.md` for full analysis.

**Growth is the only goal for v1.** Monetization and data flywheels are secondary. The singular focus is getting users in, getting them to snap, and getting the share loop spinning. Everything else follows from growth.

**Growth engine: filter-powered shares.** The front wheel spins on two features that feed each other: Snap & Share and the filter that makes sharing feel worthwhile. Every share that reaches a Facebook group is a distribution event. The quality of the filter determines whether shares happen organically or require prompting. The back wheel (pairing, journal, future recommendations) extends engagement after the user is already hooked.

**GTM timing gate.** The primary acquisition channel is Facebook cigar groups, approached via admin partnerships. Admins are involved as advisors and, potentially, paid promoters. The timing rule is absolute: approach admins only once a working MVP is ready. The first impression inside these groups is a one-shot opportunity. A product that does not work on the first impression has no second chance with that community.

**Admin partnership model.** Partner with group admins and moderators. Involve them in feedback and iteration. Position them as part of the creative process, not as distribution channels. This is a relationship, not a broadcast.

**Launch model: free.** All features, no limitations. Observe what users value before introducing a paid tier.

**Future monetization.** Start at a low price point ($2.99 to $4.99 per month). Premium candidates based on power user behavior: advanced analytics, AI-powered recommendations, collection export, priority identification speed. Cigar Doctor is a strong future paywall candidate.

**Data flywheel (post-MVP).** Every snap is a labeled training pair for Phase 2 automated band recognition. Users build the ML corpus through normal usage. The product improves as it grows.

**Key metrics for MVP.** Share rate (target: 40%+), viral coefficient (target: 0.1+), filter adoption rate (how often users apply a filter vs. sharing unfiltered), return rate within 7 days.

---

## 10. Social Network Strategy

Full channel analysis in `strategy/gtm.md`. This section captures the strategic insights that inform product decisions.

### Long-Term Vision: A Cigar Social Network

The long-term product vision (post-MVP, post-funding) is a dedicated social network for cigar enthusiasts. Facebook and Instagram are increasingly restricting tobacco-related content. A platform built specifically for the cigar community is a structural gap in the market.

This phase is funding-gated at $500K to $1M, driven by US legal requirements. It is not on the near-term roadmap. It is named here because it shapes decisions made in MVP. The Journal, the user identity model, and the photo data schema should all be designed with the social network phase in mind. Nothing in MVP forecloses that future. Nothing in the social network vision requires the MVP to be over-engineered.

The MVP builds the user base and the content library. The social network is what that user base migrates to.

### Key Channel Insights

**1. Facebook cigar groups are the primary acquisition surface.** These groups have thousands of active members. The admin-partnership model is the right entry. The timing gate (MVP ready before any outreach) is non-negotiable.

**2. Tobacco ad bans are a structural advantage.** Meta, TikTok, and Google all ban paid tobacco promotion. This means the filter-powered organic share model is not a workaround. It is the only legal growth model. Competitors cannot outspend Vitolero on paid acquisition because paid acquisition does not exist.

**3. Instagram is underweighted in current positioning.** Cigar photo-sharing behavior already lives on Instagram at scale (#cigarlife, #BOTL, #SOTL, #cigarsofinstagram, #nowsmoking, #cigaroftheday). The Web Share API image approach bypasses link preview restrictions entirely. Top cigar influencers reach 100K to 210K followers.

**4. YouTube is the credibility unlock.** Top cigar YouTube creators are independent and reachable (Cigars Daily, Cigar Vixen, The Cigar Authority, halfwheel, Cigar Dojo). A genuine mention from a mid-tier channel delivers concentrated, high-intent reach.

**5. Discord as an underexplored surface.** The Cigar Page Discord server (approximately 9,700 members) and similar communities are underexplored. A Vitolero bot that responds to cigar photos with identification would be genuinely useful to the community, not perceived as marketing.

**6. Community language matters.** "BOTL" (Brothers of the Leaf) and "SOTL" (Sisters of the Leaf) are trust signals across Instagram, forums, and X. Using them naturally signals genuine membership.

### Community Infiltration Warning

Most Facebook cigar groups ban promotions. Share cards must read as organic content (a cigar enthusiast sharing their smoke) rather than as app advertisements. The threshold varies by group. Navigating this landscape requires someone who knows the community. The admin-partnership model mitigates this by having trusted insiders introduce the product, not an unknown brand.

### Research Still Needed

This section needs expansion with research not yet covered:

- WhatsApp cigar groups (size, behavior, sharing mechanics)
- Telegram cigar communities
- TikTok cigar subcommunity (#cigartok) deeper analysis
- Bluesky and Threads as emerging platforms
- Regional platforms (VK for Eastern European market, WeChat for Chinese market)

This research should feed back into both this section and `strategy/gtm.md`.
